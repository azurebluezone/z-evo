@extends('backEnd.layouts.app')
@section('title','Edit Variant')

@section('content')
<div class="container-fluid">
  <div class="row">
    <div class="col-12">
      <div class="page-title-box d-flex align-items-center justify-content-between">
        <h4 class="page-title mb-0">Edit Variant</h4>
        <a href="{{ route('admin.variants.index') }}" class="btn btn-sm btn-secondary">Back</a>
      </div>
    </div>
  </div>

  <div class="row">
    <div class="col-12">
      <div class="card">
        <div class="card-body">
          <form method="POST" action="{{ route('admin.variants.update', $variant->id) }}">
            @csrf

            <div class="row">
              <div class="col-md-6 mb-3">
                <label class="form-label">Product</label>
                <select name="product_id" class="form-control @error('product_id') is-invalid @enderror" required>
                  <option value="">Select product</option>
                  @foreach($products as $p)
                    <option value="{{ $p->id }}" {{ (string)old('product_id', $variant->product_id) === (string)$p->id ? 'selected' : '' }}>
                      #{{ $p->id }} — {{ $p->name }} {{ $p->product_code ? '(' . $p->product_code . ')' : '' }}
                    </option>
                  @endforeach
                </select>
                @error('product_id')
                  <div class="invalid-feedback">{{ $message }}</div>
                @enderror
              </div>

              <div class="col-md-6 mb-3">
                <label class="form-label">SKU</label>
                <input type="text" name="sku" class="form-control @error('sku') is-invalid @enderror" value="{{ old('sku', $variant->sku) }}" required />
                @error('sku')
                  <div class="invalid-feedback">{{ $message }}</div>
                @enderror
              </div>

              <div class="col-md-6 mb-3">
                <label class="form-label">Title (Optional)</label>
                <input type="text" name="title" class="form-control @error('title') is-invalid @enderror" value="{{ old('title', $variant->title) }}" />
                @error('title')
                  <div class="invalid-feedback">{{ $message }}</div>
                @enderror
              </div>

              <div class="col-md-3 mb-3">
                <label class="form-label">Price Override (Optional)</label>
                <input type="number" name="price_override" class="form-control @error('price_override') is-invalid @enderror" value="{{ old('price_override', $variant->price_override) }}" min="0" />
                @error('price_override')
                  <div class="invalid-feedback">{{ $message }}</div>
                @enderror
              </div>

              <div class="col-md-3 mb-3">
                <label class="form-label">Weight (gram) (Optional)</label>
                <input type="number" name="weight_gram" class="form-control @error('weight_gram') is-invalid @enderror" value="{{ old('weight_gram', $variant->weight_gram) }}" min="0" />
                @error('weight_gram')
                  <div class="invalid-feedback">{{ $message }}</div>
                @enderror
              </div>

              <div class="col-md-3 mb-3">
                <label class="form-label">Status</label>
                <select name="status" class="form-control @error('status') is-invalid @enderror">
                  <option value="1" {{ (string)old('status', $variant->status) === '1' ? 'selected' : '' }}>Active</option>
                  <option value="0" {{ (string)old('status', $variant->status) === '0' ? 'selected' : '' }}>Inactive</option>
                </select>
                @error('status')
                  <div class="invalid-feedback">{{ $message }}</div>
                @enderror
              </div>
            </div>

            <div class="mt-2">
              <button type="submit" class="btn btn-success">Save</button>
            </div>
          </form>

          <div class="card mt-3">
            <div class="card-body text-muted">
              Attributes UI is coming soon. This screen manages core variant fields used by inventory ledger.
            </div>
          </div>

        </div>
      </div>
    </div>
  </div>
</div>
@endsection
