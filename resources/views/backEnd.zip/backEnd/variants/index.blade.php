@extends('backEnd.layouts.app')
@section('title','Variants')

@section('content')
<div class="container-fluid">
  <div class="row">
    <div class="col-12">
      <div class="page-title-box d-flex align-items-center justify-content-between">
        <h4 class="page-title mb-0">Variants</h4>
        <a href="{{ route('admin.variants.create') }}" class="btn btn-sm btn-primary">Create Variant</a>
      </div>
    </div>
  </div>

  <div class="row">
    <div class="col-12">
      <div class="card">
        <div class="card-body">
          <div class="card-datatable table-responsive">
            <table class="table table-striped table-bordered mb-0">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>SKU</th>
                  <th>Title</th>
                  <th>Product</th>
                  <th>Status</th>
                  <th class="text-end">Action</th>
                </tr>
              </thead>
              <tbody>
                @foreach($variants as $v)
                <tr>
                  <td>{{ $v->id }}</td>
                  <td>{{ $v->sku }}</td>
                  <td>{{ $v->title }}</td>
                  <td>{{ $v->product_name }}</td>
                  <td>
                    @if((int)$v->status === 1)
                      <span class="badge bg-success">Active</span>
                    @else
                      <span class="badge bg-secondary">Inactive</span>
                    @endif
                  </td>
                  <td class="text-end">
                    <a href="{{ route('admin.variants.edit', $v->id) }}" class="btn btn-sm btn-outline-primary">Edit</a>
                  </td>
                </tr>
                @endforeach
              </tbody>
            </table>
          </div>

          <div class="mt-3">
            {{ $variants->links() }}
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
@endsection
