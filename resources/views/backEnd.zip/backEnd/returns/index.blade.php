@extends('backEnd.layouts.app')
@section('title','Returns')

@section('content')
<div class="row">
  <div class="col-12">
    <div class="d-flex flex-wrap align-items-center justify-content-between gap-2 mb-3">
      <h4 class="mb-0">Returns</h4>
      <div class="d-flex flex-wrap align-items-center gap-2">
        <a href="{{ route('admin.orders', ['slug' => 'all']) }}" class="btn btn-outline-secondary btn-sm">Orders</a>
        <a href="{{ route('admin.refunds.index') }}" class="btn btn-outline-secondary btn-sm">Refunds</a>
      </div>
    </div>

    <div class="card">
      <div class="card-body">
        <div class="sticky-top bg-white" style="top: 0; z-index: 9;">
          <div class="py-2">
            <div class="alert alert-info mb-0">Delivered orders list. Approve return will restock inventory (legacy + ledger/cache).</div>
          </div>
          <hr class="my-0">
        </div>

        <div class="card-datatable table-responsive">
          <table class="table table-striped w-100 align-middle">
              <thead>
                <tr>
                  <th>Order</th>
                  <th>Invoice</th>
                  <th>Customer</th>
                  <th>Phone</th>
                  <th class="text-end">Amount</th>
                  <th>Return Status</th>
                  <th class="text-end">Action</th>
                </tr>
              </thead>
              <tbody>
                @forelse($orders as $o)
                  @php
                    $r = $returnRows[$o->id] ?? null;
                  @endphp
                  <tr>
                    <td>#{{ $o->id }}</td>
                    <td>{{ $o->invoice_id }}</td>
                    <td>{{ optional($o->customer)->name }}</td>
                    <td>{{ optional($o->shipping)->phone }}</td>
                    <td class="text-end">{{ $o->amount }}</td>
                    <td>
                      @if($r)
                        <span class="badge text-bg-secondary">{{ $r->status }}</span>
                        @if($r->restocked)
                          <span class="badge text-bg-success">Restocked</span>
                        @endif
                      @else
                        <span class="badge text-bg-light">None</span>
                      @endif
                    </td>
                    <td class="text-end">
                      @if(!$r || !$r->restocked)
                        <form method="POST" action="{{ route('admin.returns.approve', $o->id) }}" class="d-inline">
                          @csrf
                          <input type="hidden" name="reason" value="Admin approved" />
                          <button type="submit" class="btn btn-sm btn-primary">Approve Return</button>
                        </form>
                      @else
                        <button class="btn btn-sm btn-outline-secondary" disabled>Done</button>
                      @endif
                    </td>
                  </tr>
                @empty
                  <tr>
                    <td colspan="7" class="text-center text-muted">No delivered orders found</td>
                  </tr>
                @endforelse
              </tbody>
          </table>
        </div>

        <div class="custom-paginate">
          {{ $orders->links('pagination::bootstrap-4') }}
        </div>
      </div>
    </div>
  </div>
</div>
@endsection
