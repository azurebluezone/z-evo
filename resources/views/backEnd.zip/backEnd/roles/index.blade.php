@extends('backEnd.layouts.app')
@section('title','Roles Manage')

@section('content')
<div class="row">
    <div class="col-12">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center mb-3 gap-2">
            <h4 class="mb-0">Roles Manage</h4>

            <a href="{{route('roles.create')}}" class="btn btn-primary btn-sm">
                <i class="icon-base ri ri-add-line me-1"></i> Create
            </a>
        </div>

        <div class="card">
            <div class="card-body">
                <div class="card-datatable table-responsive">
                    <table class="table table-striped w-100 align-middle">
                        <thead>
                            <tr>
                                <th style="width:8%">SL</th>
                                <th>Name</th>
                                <th style="width:18%">Action</th>
                            </tr>
                        </thead>

                        <tbody>
                            @foreach($show_data as $key=>$value)
                            <tr>
                                <td>{{$loop->iteration}}</td>
                                <td>{{$value->name}}</td>
                                <td>
                                    <div class="d-flex align-items-center gap-2">
                                        <a href="{{route('roles.show',$value->id)}}" class="btn btn-icon btn-text-secondary btn-sm" title="View" data-bs-toggle="tooltip" data-bs-title="View">
                                            <i class="icon-base ri ri-eye-line icon-22px"></i>
                                        </a>
                                        <a href="{{route('roles.edit',$value->id)}}" class="btn btn-icon btn-text-secondary btn-sm" title="Edit" data-bs-toggle="tooltip" data-bs-title="Edit">
                                            <i class="icon-base ri ri-edit-box-line icon-22px"></i>
                                        </a>

                                        <form method="post" action="{{route('roles.destroy')}}" class="d-inline">
                                            @csrf
                                            <input type="hidden" value="{{$value->id}}" name="hidden_id">
                                            <button type="submit" title="Delete" class="btn btn-icon btn-text-secondary btn-sm delete-confirm" data-bs-toggle="tooltip" data-bs-title="Delete">
                                                <i class="icon-base ri ri-delete-bin-7-line icon-22px"></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection