@extends('backEnd.layouts.app')
@section('title','Coupon Manage')
@section('content')
<div class="row">
    <div class="col-12">
        <div class="d-flex flex-wrap align-items-center justify-content-between gap-2 mb-3">
            <h4 class="mb-0">Coupon Manage</h4>
            <a href="{{ route('coupons.create') }}" class="btn btn-primary"><i class="icon-base ri ri-add-line me-1"></i> Add New</a>
        </div>

        <div class="card">
            <div class="card-body">
                <div class="card-datatable table-responsive">
                    <table class="table table-striped w-100 align-middle">
                        <thead>
                            <tr>
                                <th>SL</th>
                                <th>Code</th>
                                <th>Type</th>
                                <th>Value</th>
                                <th>Min</th>
                                <th>Max</th>
                                <th>Start</th>
                                <th>End</th>
                                <th>Status</th>
                                <th class="text-end">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($coupons as $coupon)
                                <tr>
                                    <td>{{ $loop->iteration }}</td>
                                    <td><span class="fw-medium">{{ $coupon->code }}</span></td>
                                    <td>{{ strtoupper($coupon->type) }}</td>
                                    <td>{{ $coupon->value }}</td>
                                    <td>{{ $coupon->min_amount }}</td>
                                    <td>{{ $coupon->max_discount }}</td>
                                    <td>{{ $coupon->start_at ? $coupon->start_at->format('Y-m-d H:i') : '' }}</td>
                                    <td>{{ $coupon->end_at ? $coupon->end_at->format('Y-m-d H:i') : '' }}</td>
                                    <td>
                                        @if($coupon->status)
                                            <span class="badge bg-label-success">Active</span>
                                        @else
                                            <span class="badge bg-label-secondary">Inactive</span>
                                        @endif
                                    </td>
                                    <td class="text-end">
                                        <div class="d-inline-flex align-items-center gap-2">
                                            <a href="{{ route('coupons.edit', $coupon->id) }}" class="btn btn-icon btn-text-secondary btn-sm" data-bs-toggle="tooltip" data-bs-title="Edit">
                                                <i class="icon-base ri ri-edit-box-line icon-22px"></i>
                                            </a>

                                            @if($coupon->status)
                                                <form method="post" action="{{ route('coupons.inactive') }}" class="d-inline">
                                                    @csrf
                                                    <input type="hidden" name="hidden_id" value="{{ $coupon->id }}">
                                                    <button type="submit" class="btn btn-icon btn-text-secondary btn-sm change-confirm" data-bs-toggle="tooltip" data-bs-title="Inactive">
                                                        <i class="icon-base ri ri-eye-off-line icon-22px"></i>
                                                    </button>
                                                </form>
                                            @else
                                                <form method="post" action="{{ route('coupons.active') }}" class="d-inline">
                                                    @csrf
                                                    <input type="hidden" name="hidden_id" value="{{ $coupon->id }}">
                                                    <button type="submit" class="btn btn-icon btn-text-secondary btn-sm change-confirm" data-bs-toggle="tooltip" data-bs-title="Active">
                                                        <i class="icon-base ri ri-eye-line icon-22px"></i>
                                                    </button>
                                                </form>
                                            @endif

                                            <form method="post" action="{{ route('coupons.destroy') }}" class="d-inline">
                                                @csrf
                                                <input type="hidden" name="hidden_id" value="{{ $coupon->id }}">
                                                <button type="submit" class="btn btn-icon btn-text-secondary btn-sm delete-confirm" data-bs-toggle="tooltip" data-bs-title="Delete">
                                                    <i class="icon-base ri ri-delete-bin-7-line icon-22px"></i>
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
