@extends('backEnd.layouts.app')
@section('title','Coupon Create')
@section('content')
<div class="row">
    <div class="col-12">
        <div class="d-flex flex-wrap align-items-center justify-content-between gap-2 mb-3">
            <h4 class="mb-0">Coupon Create</h4>
            <a href="{{ route('coupons.index') }}" class="btn btn-outline-secondary">Manage</a>
        </div>

        <div class="card">
            <div class="card-body">
                <form action="{{ route('coupons.store') }}" method="post" class="row g-3">
                    @csrf

                    <div class="col-md-4">
                        <label class="form-label">Code *</label>
                        <input type="text" name="code" value="{{ old('code') }}" class="form-control @error('code') is-invalid @enderror" required>
                        @error('code')<div class="invalid-feedback">{{ $message }}</div>@enderror
                    </div>

                    <div class="col-md-4">
                        <label class="form-label">Type *</label>
                        <select name="type" class="form-select @error('type') is-invalid @enderror" required>
                            <option value="fixed" {{ old('type') === 'fixed' ? 'selected' : '' }}>Fixed</option>
                            <option value="percent" {{ old('type') === 'percent' ? 'selected' : '' }}>Percent</option>
                        </select>
                        @error('type')<div class="invalid-feedback">{{ $message }}</div>@enderror
                    </div>

                    <div class="col-md-4">
                        <label class="form-label">Value *</label>
                        <input type="number" step="0.01" name="value" value="{{ old('value') }}" class="form-control @error('value') is-invalid @enderror" required>
                        @error('value')<div class="invalid-feedback">{{ $message }}</div>@enderror
                    </div>

                    <div class="col-md-4">
                        <label class="form-label">Min Amount</label>
                        <input type="number" step="0.01" name="min_amount" value="{{ old('min_amount') }}" class="form-control @error('min_amount') is-invalid @enderror">
                        @error('min_amount')<div class="invalid-feedback">{{ $message }}</div>@enderror
                    </div>

                    <div class="col-md-4">
                        <label class="form-label">Max Discount</label>
                        <input type="number" step="0.01" name="max_discount" value="{{ old('max_discount') }}" class="form-control @error('max_discount') is-invalid @enderror">
                        @error('max_discount')<div class="invalid-feedback">{{ $message }}</div>@enderror
                    </div>

                    <div class="col-md-4">
                        <label class="form-label">Usage Limit</label>
                        <input type="number" name="usage_limit" value="{{ old('usage_limit') }}" class="form-control @error('usage_limit') is-invalid @enderror">
                        @error('usage_limit')<div class="invalid-feedback">{{ $message }}</div>@enderror
                    </div>

                    <div class="col-md-6">
                        <label class="form-label">Start At</label>
                        <input type="datetime-local" name="start_at" value="{{ old('start_at') }}" class="form-control @error('start_at') is-invalid @enderror">
                        @error('start_at')<div class="invalid-feedback">{{ $message }}</div>@enderror
                    </div>

                    <div class="col-md-6">
                        <label class="form-label">End At</label>
                        <input type="datetime-local" name="end_at" value="{{ old('end_at') }}" class="form-control @error('end_at') is-invalid @enderror">
                        @error('end_at')<div class="invalid-feedback">{{ $message }}</div>@enderror
                    </div>

                    <div class="col-12">
                        <label class="form-label">Products (Optional)</label>
                        <select name="product_ids[]" class="form-select js-select2" multiple size="6">
                            @foreach($products as $p)
                                @if($p->status == 1 && !str_contains(strtolower($p->name), 'test'))
                                    <option value="{{ $p->id }}">{{ $p->name }}</option>
                                @endif
                            @endforeach
                        </select>
                        <small class="text-muted d-block mt-1">Hold Ctrl/Cmd to select multiple products</small>
                        <div class="form-text">If you select products, this coupon will apply only to those products. Leave empty for all products.</div>
                    </div>

                    <div class="col-12">
                        <label class="form-label d-block">Status</label>
                        <label class="switch switch-square">
                            <input type="checkbox" class="switch-input" name="status" value="1" checked>
                            <span class="switch-toggle-slider">
                                <span class="switch-on"><i class="icon-base ri ri-check-line"></i></span>
                                <span class="switch-off"><i class="icon-base ri ri-close-line"></i></span>
                            </span>
                        </label>
                    </div>

                    <div class="col-12">
                        <button type="submit" class="btn btn-success">Submit</button>
                    </div>
                </form>
            </div>
        </div>

    </div>
</div>
@endsection
