@extends('backEnd.layouts.app')
@section('title','Social Event Manager')

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <h4 class="page-title">Social Event Manager</h4>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <form action="{{ route('admin.social-events.update') }}" method="POST">
                        @csrf

                        <ul class="nav nav-tabs" role="tablist">
                            <li class="nav-item" role="presentation">
                                <button class="nav-link active" data-bs-toggle="tab" data-bs-target="#tab-facebook" type="button" role="tab">Facebook</button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-google" type="button" role="tab">Google (GTM)</button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-tiktok" type="button" role="tab">TikTok</button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-contact" type="button" role="tab">Contact CTA</button>
                            </li>
                        </ul>

                        <div class="tab-content pt-3">
                            <div class="tab-pane fade show active" id="tab-facebook" role="tabpanel">
                                @include('backEnd.social-events.partials.facebook')
                            </div>
                            <div class="tab-pane fade" id="tab-google" role="tabpanel">
                                @include('backEnd.social-events.partials.google')
                            </div>
                            <div class="tab-pane fade" id="tab-tiktok" role="tabpanel">
                                @include('backEnd.social-events.partials.tiktok')
                            </div>
                            <div class="tab-pane fade" id="tab-contact" role="tabpanel">
                                @include('backEnd.social-events.partials.contact')
                            </div>
                        </div>

                        <div class="mt-4">
                            <button type="submit" class="btn btn-primary">Save</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@section('script')
<script>
(function() {
    function toggleInputVisibility(btn) {
        var targetId = btn.getAttribute('data-target');
        if (!targetId) return;
        var input = document.getElementById(targetId);
        if (!input) return;
        var nextType = input.type === 'password' ? 'text' : 'password';
        input.type = nextType;

        var icon = btn.querySelector('i');
        if (icon) {
            if (nextType === 'text') {
                icon.classList.remove('ri-eye-line');
                icon.classList.add('ri-eye-off-line');
            } else {
                icon.classList.remove('ri-eye-off-line');
                icon.classList.add('ri-eye-line');
            }
        }
    }

    document.addEventListener('click', function(e) {
        var btn = e.target.closest('.toggle-visibility');
        if (btn) {
            e.preventDefault();
            toggleInputVisibility(btn);
        }
    });
})();
</script>
@endsection
