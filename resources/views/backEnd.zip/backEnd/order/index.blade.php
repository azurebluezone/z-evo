@extends('backEnd.layouts.app')
@section('title',$order_status->name.' Order')
@section('content')
<div class="row">
    <div class="col-12">
        <div class="d-flex flex-wrap align-items-center justify-content-between gap-2 mb-3">
            <h4 class="mb-0">{{$order_status->name}} Order ({{$order_status->orders_count}})</h4>
            <a href="{{route('admin.order.create')}}" class="btn btn-primary"><i class="icon-base ri ri-shopping-cart-2-line me-1"></i> Add New</a>
        </div>

        <div class="card mb-3">
            <div class="card-widget-separator-wrapper">
                <div class="card-body card-widget-separator">
                    <div class="row gy-4 gy-sm-1">
                        <div class="col-sm-6 col-lg-3">
                            <div class="d-flex justify-content-between align-items-start card-widget-1 border-end pb-4 pb-sm-0">
                                <div>
                                    <h4 class="mb-0">{{ isset($order_kpis) ? $order_kpis->total : 0 }}</h4>
                                    <p class="mb-0">Total Orders</p>
                                </div>
                                <div class="avatar me-sm-6">
                                    <span class="avatar-initial rounded-3 text-heading">
                                        <i class="icon-base ri ri-file-list-3-line icon-26px"></i>
                                    </span>
                                </div>
                            </div>
                            <hr class="d-none d-sm-block d-lg-none me-6">
                        </div>
                        <div class="col-sm-6 col-lg-3">
                            <div class="d-flex justify-content-between align-items-start card-widget-2 border-end pb-4 pb-sm-0">
                                <div>
                                    <h4 class="mb-0">{{ isset($order_kpis) ? $order_kpis->today : 0 }}</h4>
                                    <p class="mb-0">Today</p>
                                </div>
                                <div class="avatar me-lg-6">
                                    <span class="avatar-initial rounded-3 text-heading">
                                        <i class="icon-base ri ri-calendar-todo-line icon-26px"></i>
                                    </span>
                                </div>
                            </div>
                            <hr class="d-none d-sm-block d-lg-none">
                        </div>
                        <div class="col-sm-6 col-lg-3">
                            <div class="d-flex justify-content-between align-items-start border-end pb-4 pb-sm-0 card-widget-3">
                                <div>
                                    <h4 class="mb-0">{{ isset($order_kpis) ? $order_kpis->pending : 0 }}</h4>
                                    <p class="mb-0">Pending</p>
                                </div>
                                <div class="avatar me-sm-6">
                                    <span class="avatar-initial rounded-3 text-heading">
                                        <i class="icon-base ri ri-time-line icon-26px"></i>
                                    </span>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6 col-lg-3">
                            <div class="d-flex justify-content-between align-items-start">
                                <div>
                                    <h4 class="mb-0">{{ isset($order_kpis) ? $order_kpis->delivered : 0 }}</h4>
                                    <p class="mb-0">Delivered</p>
                                </div>
                                <div class="avatar">
                                    <span class="avatar-initial rounded-3 text-heading">
                                        <i class="icon-base ri ri-truck-line icon-26px"></i>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="card-body">
                <div class="sticky-top bg-white" style="top: 0; z-index: 9;">
                    <div class="d-flex flex-wrap align-items-center justify-content-between gap-2 py-2">
                        <div class="d-flex flex-wrap align-items-center gap-2">
                            <div class="dropdown">
                                <button class="btn btn-outline-secondary btn-sm dropdown-toggle" type="button" id="orderBulkActionsDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                                    Actions
                                </button>
                                <ul class="dropdown-menu" aria-labelledby="orderBulkActionsDropdown">
                                    <li><a class="dropdown-item" data-bs-toggle="modal" data-bs-target="#asignUser" href="javascript:void(0)">Assign User</a></li>
                                    <li><a class="dropdown-item" data-bs-toggle="modal" data-bs-target="#changeStatus" href="javascript:void(0)">Change Status</a></li>
                                    <li><hr class="dropdown-divider"></li>
                                    <li><a class="dropdown-item order_delete" href="{{route('admin.order.bulk_destroy')}}">Delete Selected</a></li>
                                    <li><a class="dropdown-item multi_order_print" href="{{route('admin.order.order_print')}}">Print Selected</a></li>
                                    @if($steadfast)
                                    <li><a class="dropdown-item multi_order_courier" href="{{route('admin.bulk_courier', 'steadfast')}}">Courier (Steadfast)</a></li>
                                    @endif
                                    <li><a class="dropdown-item" data-bs-toggle="modal" data-bs-target="#pathao" href="javascript:void(0)">Pathao</a></li>
                                </ul>
                            </div>

                            <button type="button" class="btn btn-outline-secondary btn-sm" data-bs-toggle="offcanvas" data-bs-target="#orderFilters" aria-controls="orderFilters">
                                Filters
                            </button>

                            @if($steadfast)
                            <button type="button" class="btn btn-outline-primary btn-sm individual-courier-btn" data-courier="steadfast" data-bs-toggle="tooltip" title="Send to SteadFast Courier">
                                <i class="ri ri-truck-line me-1"></i> SteadFast
                            </button>
                            @endif

                            @if(isset($pathaostore) && !empty($pathaostore))
                            <button type="button" class="btn btn-outline-success btn-sm individual-courier-btn" data-courier="pathao-auto" data-url="{{ route('admin.order.pathao.auto') }}" title="Auto-send to Pathao Courier">
                                <i class="ri ri-road-map-line me-1"></i> Pathao
                            </button>
                            @endif
                        </div>

                        <form class="d-flex align-items-center gap-2" method="get" action="{{ route('admin.orders', ['slug' => request()->route('slug') ?? 'all']) }}">
                            <input type="text" name="keyword" class="form-control form-control-sm" placeholder="Search invoice/phone" value="{{ request('keyword') }}" style="min-width: 0; width: 100%; max-width: 320px;">
                            <button class="btn btn-info btn-sm" type="submit">Search</button>
                        </form>
                    </div>
                    <hr class="my-0">
                </div>

                <div class="offcanvas offcanvas-end" tabindex="-1" id="orderFilters" aria-labelledby="orderFiltersLabel">
                    <div class="offcanvas-header">
                        <h5 id="orderFiltersLabel" class="offcanvas-title">Filters</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
                    </div>
                    <div class="offcanvas-body">
                        <form method="get" action="{{ route('admin.orders', ['slug' => request()->route('slug') ?? 'all']) }}">
                            <div class="mb-3">
                                <label class="form-label">Status</label>
                                <select class="form-select" name="status">
                                    <option value="">All</option>
                                    @foreach($orderstatus as $st)
                                        <option value="{{ $st->id }}" @if((string)request('status') === (string)$st->id) selected @endif>{{ $st->name }}</option>
                                    @endforeach
                                </select>
                            </div>

                            <div class="mb-3">
                                <input type="hidden" name="keyword" value="{{ request('keyword') }}">
                            </div>

                            <div class="d-flex gap-2">
                                <button type="submit" class="btn btn-primary">Apply</button>
                                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="offcanvas">Close</button>
                            </div>
                        </form>
                    </div>
                </div>

                <div class="card-datatable table-responsive">
                    <table id="datatable-buttons" class="table table-striped table-sm w-100 align-middle">
                        <thead>
                            <tr>
                                <th style="width:40px" class="text-center">
                                    <div class="form-check m-0">
                                        <input type="checkbox" class="form-check-input checkall" value="">
                                    </div>
                                </th>
                                <th style="width:12%">Invoice</th>
                                <th style="width:24%">Name</th>
                                <th style="width:14%" class="d-none d-md-table-cell">Phone</th>
                                <th style="width:12%" class="d-none d-md-table-cell">Amount</th>
                                <th style="width:18%">Status</th>
                                <th style="width:56px" class="text-end"></th>
                            </tr>
                        </thead>

                        <tbody>
                        @foreach($show_data as $key=>$value)
                        @php
                            $rawPhone = (string) ($value->shipping ? ($value->shipping->phone ?? '') : '');
                        @endphp
                        <tr @if(isset($value->risk_label) && $value->risk_label === 'high_risk') style="background: #fee2e2;" @endif>
                            <td class="text-center"><input type="checkbox" class="checkbox" value="{{$value->id}}"></td>
                            <td>
                                <div class="fw-medium">{{$value->invoice_id}}</div>
                                <div class="text-muted small">{{date('d-m-Y', strtotime($value->updated_at))}}</div>
                                <div class="text-muted small d-md-none">৳{{$value->amount}}</div>
                            </td>
                            <td>
                                <strong>{{$value->shipping?$value->shipping->name:''}}</strong>
                                <div class="text-muted small d-md-none">{{$rawPhone}}</div>
                                <p>{{$value->shipping?$value->shipping->address:''}}</p>
                            </td>
                            <td class="d-none d-md-table-cell">
                                <div class="d-flex flex-column">
                                    <div>
                                        {{$rawPhone}}

                                        @if(isset($value->risk_label) && $value->risk_label === 'high_risk')
                                            <span class="badge bg-danger ms-1">High Risk</span>
                                        @elseif(isset($value->risk_label) && $value->risk_label === 'risky')
                                            <span class="badge bg-warning text-dark ms-1">Risky</span>
                                        @elseif(isset($value->risk_label) && $value->risk_label === 'normal')
                                            <span class="badge bg-success ms-1">Normal</span>
                                        @elseif(isset($value->risk_label) && $value->risk_label === 'unknown')
                                            <span class="badge bg-secondary ms-1">Unknown</span>
                                        @endif
                                    </div>
                                    @if(isset($value->risk_score_percent) && $value->risk_score_percent !== null)
                                        <small class="text-muted">Score: {{$value->risk_score_percent}}%</small>
                                    @endif
                                </div>
                            </td>
                            <td class="d-none d-md-table-cell">৳{{$value->amount}}</td>
                            <td>
                                @php
                                    $currentStatusName = $value->status ? ($value->status->name ?? '') : '';
                                @endphp
                                <div class="dropdown d-inline-block">
                                    <button class="btn btn-sm btn-outline-secondary dropdown-toggle js-order-status-dropdown" type="button" data-bs-toggle="dropdown" aria-expanded="false" data-order-id="{{$value->id}}">
                                        {{$currentStatusName}}
                                    </button>
                                    <ul class="dropdown-menu">
                                        @foreach($orderstatus as $st)
                                            <li>
                                                <a class="dropdown-item js-order-status-option" href="javascript:void(0)" data-order-id="{{$value->id}}" data-order-status="{{$st->id}}">{{$st->name}}</a>
                                            </li>
                                        @endforeach
                                    </ul>
                                </div>
                            </td>
                            <td class="text-end">
                                <div class="dropdown">
                                    <button type="button" class="btn btn-icon btn-text-secondary btn-sm dropdown-toggle hide-arrow" style="padding: .25rem; width: 32px; height: 32px;" data-bs-toggle="dropdown" aria-expanded="false" title="Actions">
                                        <i class="icon-base ri ri-more-2-fill"></i>
                                    </button>
                                    <div class="dropdown-menu dropdown-menu-end">
                                        <a class="dropdown-item" href="{{route('admin.order.invoice',['invoice_id'=>$value->invoice_id])}}">
                                            <i class="ri-eye-line me-2"></i>Invoice
                                        </a>
                                        <a class="dropdown-item" href="{{route('admin.order.process',['invoice_id'=>$value->invoice_id])}}">
                                            <i class="ri-settings-3-line me-2"></i>Process
                                        </a>
                                        <a class="dropdown-item" href="{{route('admin.order.edit',['invoice_id'=>$value->invoice_id])}}">
                                            <i class="ri-edit-box-line me-2"></i>Edit
                                        </a>

                                        <div class="dropdown-divider"></div>

                                        <form method="post" action="{{route('admin.order.destroy')}}" class="d-inline">
                                            @csrf
                                            <input type="hidden" value="{{$value->id}}" name="id">
                                            <button type="submit" class="dropdown-item text-danger delete-confirm">
                                                <i class="ri-delete-bin-7-line me-2"></i>Delete
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>

                <div class="custom-paginate">
                    {{$show_data->links('pagination::bootstrap-4')}}
                </div>
            </div> <!-- end card body-->

        </div> <!-- end card -->
    </div><!-- end col-->
   </div>
</div>
<!-- Assign User End -->
<div class="modal fade" id="asignUser" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Assign User</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form action="{{route('admin.order.assign')}}" id="order_assign">
      <div class="modal-body">
        <div class="form-group">
            <select name="user_id" id="user_id" class="form-control">
                <option value="">Select..</option>
                @foreach($users as $key=>$value)
                <option value="{{$value->id}}">{{$value->name}}</option>
                @endforeach
            </select>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-success">Submit</button>
      </div>
      </form>
    </div>
  </div>
</div>
<!-- Assign User End-->

<!-- Assign User End -->
<div class="modal fade" id="changeStatus" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Assign User</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form action="{{route('admin.order.status')}}" id="order_status_form">
      <div class="modal-body">
        <div class="form-group">
            <select name="order_status" id="order_status" class="form-control">
                <option value="">Select..</option>
                @foreach($orderstatus as $key=>$value)
                <option value="{{$value->id}}">{{$value->name}}</option>
                @endforeach
            </select>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-success">Submit</button>
      </div>
      </form>
    </div>
  </div>
</div>

<!-- Assign User End-->
<!-- pathao coureir start -->
<div class="modal fade" id="pathao" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Pathao Courier</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form action="{{route('admin.order.pathao')}}" id="order_sendto_pathao">

      <div class="modal-body">
        <div class="form-group">
            <label for="pathaostore" class="form-label">Store</label>
           <select name="pathaostore" id="pathaostore" class="pathaostore form-control" >
             <option value="">Select Store...</option>
             @if(isset($pathaostore['data']['data']))
             @foreach($pathaostore['data']['data'] as $key=>$store)
             <option value="{{$store['store_id']}}">{{$store['store_name']}}</option>
             @endforeach
             @else
             @endif
           </select>
            @if ($errors->has('pathaostore'))
              <span class="invalid-feedback" role="alert">
                <strong>{{ $errors->first('pathaostore') }}</strong>
              </span>
              @endif
        </div>
        <!-- form group end -->
        <div class="form-group mt-3">
          <label for="pathaocity" class="form-label">City</label>
           <select name="pathaocity" id="pathaocity" class="chosen-select pathaocity form-control" style="width:100%" >
             <option value="">Select City...</option>
             @if(isset($pathaocities['data']['data']))
             @foreach($pathaocities['data']['data'] as $key=>$city)
             <option value="{{$city['city_id']}}">{{$city['city_name']}}</option>
             @endforeach
             @else
             @endif
           </select>
            @if ($errors->has('pathaocity'))
              <span class="invalid-feedback" role="alert">
                <strong>{{ $errors->first('pathaocity') }}</strong>
              </span>
              @endif
        </div>
        <!-- form group end -->
        <div class="form-group mt-3">
          <label for="" class="form-label">Zone</label>
             <select name="pathaozone" id="pathaozone" class="pathaozone chosen-select form-control  {{ $errors->has('pathaozone') ? ' is-invalid' : '' }}" value="{{ old('pathaozone') }}"  style="width:100%">
            </select>
             @if ($errors->has('pathaozone'))
              <span class="invalid-feedback" role="alert">
                <strong>{{ $errors->first('pathaozone') }}</strong>
              </span>
              @endif
        </div>
        <!-- form group end -->
        <div class="form-group mt-3">
          <label for="" class="form-label">Area</label>
             <select name="pathaoarea" id="pathaoarea" class="pathaoarea chosen-select form-control  {{ $errors->has('pathaoarea') ? ' is-invalid' : '' }}" value="{{ old('pathaoarea') }}"  style="width:100%">
            </select>
             @if ($errors->has('pathaoarea'))
              <span class="invalid-feedback" role="alert">
                <strong>{{ $errors->first('pathaoarea') }}</strong>
              </span>
              @endif
        </div>
        <!-- form group end -->
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-success">Submit</button>
      </div>
      </form>
    </div>
  </div>
</div>
<!-- pathao courier  End-->

@push('script')
<script>
(function () {
    if (!window.jQuery) return;
    var $ = window.jQuery;

    $(document).ready(function(){
        $(".checkall").on('change',function(){
          $(".checkbox").prop('checked',$(this).is(":checked"));
        });

        // order assign
        $(document).on('submit', 'form#order_assign', function(e){
            e.preventDefault();
            var url = $(this).attr('action');
            var method = $(this).attr('method');
            let user_id=$(document).find('select#user_id').val();
        
            var order = $('input.checkbox:checked').map(function(){
              return $(this).val();
            });
            var order_ids=order.get();
            
            if(order_ids.length ==0){
                toastr.error('Please Select An Order First !');
                return ;
            }
            
            $.ajax({
               type:'GET',
               url:url,
               data:{user_id,order_ids},
               success:function(res){
                   if(res.status=='success'){
                    toastr.success(res.message);
                    window.location.reload();
                    
                }else{
                    toastr.error('Failed something wrong');
                }
               }
            });
        
        });

        // order status change 
        $(document).on('submit', 'form#order_status_form', function(e){
            e.preventDefault();
            var url = $(this).attr('action');
            var method = $(this).attr('method');
            let order_status=$(document).find('select#order_status').val();
        
            var order = $('input.checkbox:checked').map(function(){
              return $(this).val();
            });
            var order_ids=order.get();
            
            if(order_ids.length ==0){
                toastr.error('Please Select An Order First !');
                return ;
            }
            
            $.ajax({
               type:'GET',
               url:url,
               data:{order_status,order_ids},
               success:function(res){
                   if(res.status=='success'){
                    toastr.success(res.message);
                    window.location.reload();
                    
                }else{
                    toastr.error('Failed something wrong');
                }
               }
            });
        
        });

        // single order status change (inline dropdown)
        $(document).on('click', '.js-order-status-option', function(e){
            e.preventDefault();
            var $option = $(this);
            var orderId = $option.data('order-id');
            var orderStatus = $option.data('order-status');
            var nextStatusText = ($option.text() || '').trim();
            var url = "{{ route('admin.order.status') }}";

            $.ajax({
               type:'GET',
               url:url,
               data:{order_status: orderStatus, order_ids: [orderId]},
               success:function(res){
                   if(res.status=='success'){
                       toastr.success(res.message);

                       var $btn = $('.js-order-status-dropdown[data-order-id="' + orderId + '"]');
                       if ($btn.length) {
                           $btn.text(nextStatusText);
                       }

                       // close dropdown
                       try {
                           var dd = bootstrap.Dropdown.getInstance($btn[0]);
                           if (dd) dd.hide();
                       } catch (e) {}
                   }else{
                       toastr.error('Failed something wrong');
                   }
               }
            });
        });

        // order delete
        $(document).on('click', '.order_delete', function(e){
            e.preventDefault();
            var url = $(this).attr('href');
            var order = $('input.checkbox:checked').map(function(){
              return $(this).val();
            });
            var order_ids=order.get();
            
            if(order_ids.length ==0){
                toastr.error('Please Select An Order First !');
                return ;
            }
            
            $.ajax({
               type:'GET',
               url:url,
               data:{order_ids},
               success:function(res){
                   if(res.status=='success'){
                    toastr.success(res.message);
                    window.location.reload();
                    
                }else{
                    toastr.error('Failed something wrong');
                }
               }
            });
        
        });
        
        // multiple print
        $(document).on('click', '.multi_order_print', function(e){
            e.preventDefault();
            var url = $(this).attr('href');
            var order = $('input.checkbox:checked').map(function(){
              return $(this).val();
            });
            var order_ids=order.get();
            
            if(order_ids.length ==0){
                toastr.error('Please Select Atleast One Order!');
                return ;
            }
            $.ajax({
               type:'GET',
               url,
               data:{order_ids},
               success:function(res){
                   if(res.status=='success'){
                       console.log(res.items, res.info);                          
                       var myWindow = window.open("", "_blank");                   
                       myWindow.document.write(res.view);
                }else{
                    toastr.error('Failed something wrong');
                }
               }
            });
        });
        // individual courier buttons (SteadFast and Pathao Auto)
        $(document).on('click', '.individual-courier-btn', function(e){
            e.preventDefault();
            var courierType = $(this).data('courier');
            var url = $(this).data('url') || "{{ route('admin.bulk_courier', 'steadfast') }}";
            
            var order = $('input.checkbox:checked').map(function(){
              return $(this).val();
            });
            var order_ids = order.get();
            
            if(order_ids.length == 0){
                toastr.error('Please Select At Least One Order!');
                return;
            }
            
            // Show loading message
            toastr.info('Sending orders to ' + (courierType === 'pathao-auto' ? 'Pathao' : 'SteadFast') + '...', 'Please wait');
            
            $.ajax({
               type:'GET',
               url:url,
               data:{order_ids: order_ids},
               success:function(res){
                   if(res.status === 'success' || res.status === 'completed'){
                       var successCount = 0;
                       var failCount = 0;
                       
                       if (res.results && Array.isArray(res.results)) {
                           res.results.forEach(function(result) {
                               if(result.status === 'success') successCount++;
                               else failCount++;
                           });
                           
                           if(successCount > 0) {
                               toastr.success(successCount + ' order(s) sent successfully!', 'Success');
                           }
                           if(failCount > 0) {
                               toastr.error(failCount + ' order(s) failed!', 'Error');
                           }
                       } else {
                           toastr.success(res.message || 'Orders sent successfully!');
                       }
                       
                       // Reload page after a short delay to show updated status
                       setTimeout(function() {
                           window.location.reload();
                       }, 1500);
                    } else {
                        toastr.error(res.message || 'Failed to send orders');
                    }
               },
               error: function(xhr, status, error) {
                   toastr.error('Failed to send orders: ' + error);
               }
            });
        });
        
        // multiple courier
        $(document).on('click', '.multi_order_courier', function(e){
            e.preventDefault();
            var url = $(this).attr('href');
            var order = $('input.checkbox:checked').map(function(){
              return $(this).val();
            });
            var order_ids=order.get();
            
            if(order_ids.length ==0){
                toastr.error('Please Select An Order First !');
                return ;
            }
            
            $.ajax({
               type:'GET',
               url:url,
               data:{order_ids},
               success:function(res){
                   if(res.status=='success'){
                    toastr.success(res.message);
                    window.location.reload();
                    
                }else{
                    toastr.error('Failed something wrong');
                }
               }
            });
        
        });
    })
})();
</script>
@endpush
@endsection