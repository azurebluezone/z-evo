@php
    $product_discount = 0;
@endphp
@foreach($cartinfo as $key=>$value)
<tr>
    <td><img height="30" src="{{ asset(preg_replace('/^public\//', '', $value->options->image)) }}"></td>
    <td>{{$value->name}}</td>
    <td>
        <div class="qty-cart vcart-qty">
            <div class="quantity">
                <button type="button" class="minus cart_decrement btn btn-sm btn-outline-secondary" value="{{$value->qty}}" data-id="{{$value->rowId}}">-</button>
                <input type="text" value="{{$value->qty}}" readonly style="width:40px;text-align:center;" />
                <button type="button" class="plus cart_increment btn btn-sm btn-outline-secondary" value="{{$value->qty}}" data-id="{{$value->rowId}}">+</button>
            </div>
        </div>
    </td>
    <td>{{$value->price}}</td>
    <td class="discount">
        <input type="number" class="product_discount form-control form-control-sm" value="{{$value->options->product_discount}}" placeholder="0.00" data-id="{{$value->rowId}}" style="width:80px;">
    </td>
    <td>{{($value->price - $value->options->product_discount)*$value->qty}}</td>
    <td>
        <button type="button" class="btn btn-danger btn-sm cart_remove" data-id="{{$value->rowId}}" aria-label="Remove">
            <span aria-hidden="true">&times;</span>
        </button>
    </td>
</tr>
@php
    $product_discount += $value->options->product_discount * $value->qty;
    Session::put('product_discount', $product_discount);
@endphp
@endforeach
