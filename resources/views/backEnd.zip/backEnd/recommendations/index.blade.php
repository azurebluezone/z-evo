@extends('backEnd.layouts.app')
@section('title','Product Recommendations')

@section('content')
<div class="row">
    <div class="col-12">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center mb-3 gap-2">
            <h4 class="mb-0">Product Recommendations</h4>

            <form class="d-flex align-items-center gap-2" method="get" action="{{ route('admin.recommendations.index') }}">
                <input type="text" name="keyword" class="form-control form-control-sm" placeholder="Search name" value="{{ request('keyword') }}" style="min-width: 220px;">
                <button class="btn btn-info btn-sm" type="submit">Search</button>
            </form>
        </div>

        <div class="card">
            <div class="card-body">
                <form method="post" action="{{ route('admin.recommendations.update') }}" class="mb-3">
                    @csrf
                    <input type="hidden" name="is_recommended" value="1">
                    <div class="row g-2 align-items-end">
                        <div class="col-12 col-md-8">
                            <label class="form-label">Add Product (Search by Name or ID)</label>
                            <div class="input-group">
                                <input type="text" name="product_search" class="form-control" placeholder="Type product name..." id="productSearchInput" autocomplete="off">
                                <input type="hidden" name="id" id="selectedProductId">
                                <button type="button" class="btn btn-outline-secondary" id="searchProductBtn">Search</button>
                            </div>
                            <div id="searchResults" class="list-group mt-1" style="max-height: 200px; overflow-y: auto; display: none;"></div>
                        </div>
                        <div class="col-6 col-md-2">
                            <label class="form-label">Sort Order</label>
                            <input type="number" min="0" name="recommended_sort_order" class="form-control" value="0">
                        </div>
                        <div class="col-6 col-md-2">
                            <button type="submit" class="btn btn-primary w-100">Add</button>
                        </div>
                    </div>
                </form>

                <div class="card-datatable table-responsive">
                    <table class="table table-striped w-100 align-middle">
                        <thead>
                            <tr>
                                <th style="width:5%">SL</th>
                                <th style="width:10%">Image</th>
                                <th>Name</th>
                                <th style="width:12%">Category</th>
                                <th style="width:12%">Sort Order</th>
                                <th style="width:10%">Status</th>
                                <th style="width:16%">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($data as $key=>$value)
                            <tr>
                                <td>{{$loop->iteration}}</td>
                                <td>
                                    @php
                                        $recImg = $value->image && $value->image->image ? $value->image->image : null;
                                        $recImgPath = $recImg ? preg_replace('~^public/~', '', $recImg) : null;
                                        $recImgPath = $recImgPath ? ltrim($recImgPath, '/') : null;
                                        $fallbackImg = $generalsetting->frontend_empty_image ?? 'assets/images/empty.png';
                                        $fallbackImg = preg_replace('~^public/~', '', $fallbackImg);
                                        $fallbackImg = ltrim($fallbackImg, '/');
                                    @endphp
                                    <img
                                        src="{{ $recImgPath && file_exists(public_path($recImgPath)) ? asset($recImgPath) : asset($fallbackImg) }}"
                                        class="backend-image"
                                        alt=""
                                        onerror="this.src='{{ asset('assets/images/empty.png') }}'">
                                </td>
                                <td>{{$value->name}}</td>
                                <td>{{$value->category?$value->category->name:''}}</td>
                                <td>
                                    <form method="post" action="{{ route('admin.recommendations.update') }}" class="d-flex align-items-center gap-2">
                                        @csrf
                                        <input type="hidden" name="id" value="{{ $value->id }}">
                                        <input type="number" min="0" name="recommended_sort_order" class="form-control form-control-sm" value="{{ $value->recommended_sort_order ?? 0 }}" style="max-width: 120px;">
                                        <button type="submit" class="btn btn-outline-primary btn-sm">Save</button>
                                    </form>
                                </td>
                                <td>
                                    @if($value->is_recommended==1)
                                        <span class="badge bg-soft-success text-success">On</span>
                                    @else
                                        <span class="badge bg-soft-danger text-danger">Off</span>
                                    @endif
                                </td>
                                <td>
                                    <div class="d-flex align-items-center gap-2">
                                        <form method="post" action="{{ route('admin.recommendations.update') }}" class="d-inline">
                                            @csrf
                                            <input type="hidden" name="id" value="{{ $value->id }}">
                                            <input type="hidden" name="is_recommended" value="0">
                                            <button type="submit" class="btn btn-icon btn-text-secondary btn-sm" title="Remove" data-bs-toggle="tooltip" data-bs-title="Remove">
                                                <i class="icon-base ri ri-close-line icon-22px"></i>
                                            </button>
                                        </form>

                                        <a class="btn btn-icon btn-text-secondary btn-sm" href="{{route('products.edit',$value->id)}}" title="Edit" data-bs-toggle="tooltip" data-bs-title="Edit">
                                            <i class="icon-base ri ri-edit-box-line icon-22px"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>

                <div class="custom-paginate">
                    {{$data->links('pagination::bootstrap-4')}}
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
    (function () {
        var searchInput = document.getElementById('productSearchInput');
        var searchBtn = document.getElementById('searchProductBtn');
        var resultsDiv = document.getElementById('searchResults');
        var selectedIdInput = document.getElementById('selectedProductId');
        var searchUrl = @json(route('admin.recommendations.search'));
        
        function performSearch() {
            var term = searchInput.value.trim();
            if (!term) return;
            
            fetch(searchUrl + '?q=' + encodeURIComponent(term))
                .then(function(r) { return r.json(); })
                .then(function(data) {
                    resultsDiv.innerHTML = '';
                    resultsDiv.style.display = 'block';
                    
                    if (data.results && data.results.length) {
                        data.results.forEach(function(item) {
                            var btn = document.createElement('button');
                            btn.type = 'button';
                            btn.className = 'list-group-item list-group-item-action';
                            btn.textContent = item.text;
                            btn.onclick = function() {
                                searchInput.value = item.text;
                                selectedIdInput.value = item.id;
                                resultsDiv.style.display = 'none';
                            };
                            resultsDiv.appendChild(btn);
                        });
                    } else {
                        resultsDiv.innerHTML = '<div class="list-group-item text-muted">No products found</div>';
                    }
                })
                .catch(function() {
                    resultsDiv.innerHTML = '<div class="list-group-item text-danger">Search failed</div>';
                });
        }
        
        if (searchBtn) searchBtn.addEventListener('click', performSearch);
        if (searchInput) {
            searchInput.addEventListener('keyup', function(e) {
                if (e.key === 'Enter') performSearch();
            });
        }
        
        // Hide results when clicking outside
        document.addEventListener('click', function(e) {
            if (!e.target.closest('#searchResults') && !e.target.closest('.input-group')) {
                resultsDiv.style.display = 'none';
            }
        });
    })();
</script>
@endpush
