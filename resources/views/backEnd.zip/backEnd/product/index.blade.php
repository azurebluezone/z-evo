@extends('backEnd.layouts.app')
@section('title','Product Manage')
@push('css')
<style>
    img.backend-image {
        width: 56px;
        height: 56px;
        object-fit: cover;
        border-radius: 8px;
        background: #f3f4f6;
        display: inline-block;
    }

    #productsTable td {
        vertical-align: middle;
    }
</style>
@endpush
@section('content')
<div class="row">
    <div class="col-12">
        <div class="d-flex flex-wrap align-items-center justify-content-between gap-2 mb-3">
            <h4 class="mb-0">Product Manage</h4>
            <div class="d-flex flex-wrap align-items-center gap-2">
                @if(isset($generalSetting) && $generalSetting->home_page_hot_deal_section == 1)
                    <form method="post" action="{{route('settings.toggle-hot-deal-section')}}" class="d-inline">
                        @csrf
                        <button type="button" class="btn btn-success change-confirm" title="Hot Deal section is visible on home page">
                            Hide Hot Deal Section
                        </button>
                    </form>
                @else
                    <form method="post" action="{{route('settings.toggle-hot-deal-section')}}" class="d-inline">
                        @csrf
                        <button type="button" class="btn btn-warning change-confirm" title="Hot Deal section is hidden from home page">
                            Show Hot Deal Section
                        </button>
                    </form>
                @endif
                <a href="{{route('products.create')}}" class="btn btn-primary">Add Product</a>
            </div>
        </div>

        <div class="card mb-3">
            <div class="card-widget-separator-wrapper">
                <div class="card-body card-widget-separator">
                    <div class="row gy-4 gy-sm-1">
                        <div class="col-sm-6 col-lg-3">
                            <div class="d-flex justify-content-between align-items-start card-widget-1 border-end pb-4 pb-sm-0">
                                <div>
                                    <h4 class="mb-0">{{ isset($product_kpis) ? $product_kpis->total : 0 }}</h4>
                                    <p class="mb-0">Total Products</p>
                                </div>
                                <div class="avatar me-sm-6">
                                    <span class="avatar-initial rounded-3 text-heading">
                                        <i class="icon-base ri ri-box-3-line icon-26px"></i>
                                    </span>
                                </div>
                            </div>
                            <hr class="d-none d-sm-block d-lg-none me-6">
                        </div>
                        <div class="col-sm-6 col-lg-3">
                            <div class="d-flex justify-content-between align-items-start card-widget-2 border-end pb-4 pb-sm-0">
                                <div>
                                    <h4 class="mb-0">{{ isset($product_kpis) ? $product_kpis->active : 0 }}</h4>
                                    <p class="mb-0">Active</p>
                                </div>
                                <div class="avatar me-lg-6">
                                    <span class="avatar-initial rounded-3 text-heading">
                                        <i class="icon-base ri ri-check-double-line icon-26px"></i>
                                    </span>
                                </div>
                            </div>
                            <hr class="d-none d-sm-block d-lg-none">
                        </div>
                        <div class="col-sm-6 col-lg-3">
                            <div class="d-flex justify-content-between align-items-start border-end pb-4 pb-sm-0 card-widget-3">
                                <div>
                                    <h4 class="mb-0">{{ isset($product_kpis) ? $product_kpis->inactive : 0 }}</h4>
                                    <p class="mb-0">Inactive</p>
                                </div>
                                <div class="avatar me-sm-6">
                                    <span class="avatar-initial rounded-3 text-heading">
                                        <i class="icon-base ri ri-close-circle-line icon-26px"></i>
                                    </span>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6 col-lg-3">
                            <div class="d-flex justify-content-between align-items-start">
                                <div>
                                    <h4 class="mb-0">{{ isset($product_kpis) ? $product_kpis->hot_deals : 0 }}</h4>
                                    <p class="mb-0">Hot Deals</p>
                                </div>
                                <div class="avatar">
                                    <span class="avatar-initial rounded-3 text-heading">
                                        <i class="icon-base ri ri-fire-line icon-26px"></i>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="card-body">
                <div class="sticky-top bg-white" style="top: 0; z-index: 9;">
                    <div class="d-flex flex-wrap align-items-center justify-content-between gap-2 py-2">
                        <div class="d-flex flex-wrap align-items-center gap-2">
                            <div class="dropdown">
                                <button class="btn btn-outline-secondary dropdown-toggle" type="button" id="bulkActionsDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                                    Actions
                                </button>
                                <ul class="dropdown-menu" aria-labelledby="bulkActionsDropdown">
                                    <li><a class="dropdown-item hotdeal_update" href="{{route('products.update_deals',['status'=>1])}}">Mark as Hot Deal</a></li>
                                    <li><a class="dropdown-item hotdeal_update" href="{{route('products.update_deals',['status'=>0])}}">Remove Hot Deal</a></li>
                                    <li><hr class="dropdown-divider"></li>
                                    <li><a class="dropdown-item update_status" href="{{route('products.update_status',['status'=>1])}}">Set Active</a></li>
                                    <li><a class="dropdown-item update_status" href="{{route('products.update_status',['status'=>0])}}">Set Inactive</a></li>
                                </ul>
                            </div>

                            <button type="button" class="btn btn-outline-secondary" data-bs-toggle="offcanvas" data-bs-target="#productFilters" aria-controls="productFilters">
                                Filters
                            </button>
                        </div>

                        <form class="d-flex align-items-center gap-2" method="get" action="{{ route('products.index') }}">
                            <input type="text" name="keyword" class="form-control" placeholder="Search" value="{{ request('keyword') }}" style="min-width: 220px;">
                            <button class="btn btn-info" type="submit">Search</button>
                            <div class="dropdown">
                                <button type="button" class="btn btn-outline-secondary dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                                    Export
                                </button>
                                <ul class="dropdown-menu dropdown-menu-end">
                                    <li><a class="dropdown-item" href="javascript:void(0)">CSV</a></li>
                                    <li><a class="dropdown-item" href="javascript:void(0)">Excel</a></li>
                                    <li><a class="dropdown-item" href="javascript:void(0)">PDF</a></li>
                                </ul>
                            </div>
                        </form>
                    </div>
                    <hr class="my-0">
                </div>

                <div class="offcanvas offcanvas-end" tabindex="-1" id="productFilters" aria-labelledby="productFiltersLabel">
                    <div class="offcanvas-header">
                        <h5 id="productFiltersLabel" class="offcanvas-title">Filters</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
                    </div>
                    <div class="offcanvas-body">
                        <div class="mb-3">
                            <label class="form-label">Created Date</label>
                            <div class="d-flex gap-2 align-items-center">
                                <button type="button" class="btn btn-outline-secondary" data-bs-toggle="popover" data-bs-title="Created Date" data-bs-content="Select a range from the toolbar above.">
                                    <i class="icon-base ri ri-calendar-line"></i>
                                </button>
                                <input type="text" class="form-control js-flatpickr-range" placeholder="YYYY-MM-DD to YYYY-MM-DD">
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Status</label>
                            <select class="form-select">
                                <option value="">All</option>
                                <option value="1">Active</option>
                                <option value="0">Inactive</option>
                            </select>
                        </div>
                        <div class="d-flex gap-2">
                            <button type="button" class="btn btn-primary" data-bs-dismiss="offcanvas">Apply</button>
                            <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="offcanvas">Close</button>
                        </div>
                    </div>
                </div>

                <div class="card-datatable table-responsive">
                    <table id="productsTable" class="datatables-products table">
                    <thead>
                        <tr>
                            <th style="width:2%">
                                <div class="form-check">
                                    <input type="checkbox" class="form-check-input checkall" value="">
                                </div>
                            </th>
                            <th style="width:25%">Name</th>
                            <th style="width:10%" class="d-none d-md-table-cell">Category</th>
                            <th style="width:10%" class="d-none d-md-table-cell">Image</th>
                            <th style="width:10%" class="d-none d-sm-table-cell">Price</th>
                            <th style="width:8%" class="d-none d-sm-table-cell">Stock</th>
                            <th style="width:14%">Feature</th>
                            <th style="width:8%">Status</th>
                            <th style="width:10%">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($data as $key=>$value)
                        <tr>
                            <td><input type="checkbox" class="checkbox" value="{{$value->id}}"></td>
                            <td>{{$value->name}}</td>
                            <td class="d-none d-md-table-cell">{{$value->category?$value->category->name:''}}</td>
                            <td class="d-none d-md-table-cell">
                                @php
                                    $productImg = $value->image && $value->image->image ? $value->image->image : null;
                                    $productImgPath = $productImg ? preg_replace('~^public/~', '', $productImg) : null;
                                    $productImgPath = $productImgPath ? ltrim($productImgPath, '/') : null;
                                    $fallbackImg = $generalsetting->frontend_empty_image ?? 'assets/images/empty.png';
                                    $fallbackImg = preg_replace('~^public/~', '', $fallbackImg);
                                    $fallbackImg = ltrim($fallbackImg, '/');
                                @endphp
                                <img
                                    src="{{ $productImgPath && file_exists(public_path($productImgPath)) ? asset($productImgPath) : asset($fallbackImg) }}"
                                    class="backend-image"
                                    alt=""
                                    onerror="this.src='{{ asset('assets/images/empty.png') }}'">
                            </td>
                            <td class="d-none d-sm-table-cell">{{$value->new_price}}</td>

                            <td class="d-none d-sm-table-cell">{{$value->stock}}</td>
                            <td>
                                <div class="d-flex flex-wrap align-items-center gap-3">
                                    <div class="form-check form-switch m-0" title="Hot Deal">
                                        <input
                                            type="checkbox"
                                            class="form-check-input js-product-flag"
                                            data-url-on="{{ route('products.update_deals', ['status' => 1]) }}"
                                            data-url-off="{{ route('products.update_deals', ['status' => 0]) }}"
                                            data-product-id="{{ $value->id }}"
                                            {{ $value->topsale == 1 ? 'checked' : '' }}>
                                    </div>

                                    <div class="form-check form-switch m-0" title="Top Feature">
                                        <input
                                            type="checkbox"
                                            class="form-check-input js-product-flag"
                                            data-url-on="{{ route('products.update_feature', ['status' => 1]) }}"
                                            data-url-off="{{ route('products.update_feature', ['status' => 0]) }}"
                                            data-product-id="{{ $value->id }}"
                                            {{ $value->feature_product == 1 ? 'checked' : '' }}>
                                    </div>

                                    @if(($value->is_recommended ?? 0) == 1)
                                        <form method="post" action="{{ route('admin.recommendations.update') }}" class="d-inline">
                                            @csrf
                                            <input type="hidden" name="id" value="{{$value->id}}">
                                            <input type="hidden" name="is_recommended" value="0">
                                            <div class="form-check form-switch m-0" title="Recommended">
                                                <input type="checkbox" class="form-check-input js-auto-submit" checked>
                                            </div>
                                        </form>
                                    @else
                                        <form method="post" action="{{ route('admin.recommendations.update') }}" class="d-inline">
                                            @csrf
                                            <input type="hidden" name="id" value="{{$value->id}}">
                                            <input type="hidden" name="is_recommended" value="1">
                                            <div class="form-check form-switch m-0" title="Not Recommended">
                                                <input type="checkbox" class="form-check-input js-auto-submit">
                                            </div>
                                        </form>
                                    @endif
                                </div>
                            </td>
                            <td>
                                @if($value->status == 1)
                                    <form method="post" action="{{route('products.inactive')}}" class="d-inline">
                                        @csrf
                                        <input type="hidden" value="{{$value->id}}" name="hidden_id">
                                        <div class="form-check form-switch m-0">
                                            <input type="checkbox" class="form-check-input js-auto-submit" checked>
                                        </div>
                                    </form>
                                @else
                                    <form method="post" action="{{route('products.active')}}" class="d-inline">
                                        @csrf
                                        <input type="hidden" value="{{$value->id}}" name="hidden_id">
                                        <div class="form-check form-switch m-0">
                                            <input type="checkbox" class="form-check-input js-auto-submit">
                                        </div>
                                    </form>
                                @endif
                            </td>
                            <td>
                                <div class="d-flex align-items-center gap-2">
                                    <a class="btn btn-icon btn-text-secondary btn-sm" href="{{route('products.edit',$value->id)}}" title="Edit" data-bs-toggle="tooltip" data-bs-title="Edit">
                                        <i class="icon-base ri ri-edit-box-line icon-22px"></i>
                                    </a>

                                    <form method="post" action="{{route('products.destroy')}}" class="d-inline">
                                        @csrf
                                        <input type="hidden" value="{{$value->id}}" name="hidden_id">
                                        <button type="submit" class="btn btn-icon btn-text-secondary btn-sm delete-confirm" title="Delete" data-bs-toggle="tooltip" data-bs-title="Delete">
                                            <i class="icon-base ri ri-delete-bin-7-line icon-22px"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                        @endforeach
                     </tbody>
                    </table>
                </div>
                <div class="custom-paginate">
                    {{$data->links('pagination::bootstrap-4')}}
                </div>
            </div>
        </div>
    </div>
   </div>
@endsection

@push('script')
<script>
    document.addEventListener('DOMContentLoaded', function () {
        if (typeof window.$ === 'function' && window.$.fn && window.$.fn.DataTable && document.querySelectorAll('.custom-paginate').length === 0) {
            window.$('#productsTable').DataTable({
                responsive: true,
                pageLength: 25,
                order: [],
                columnDefs: [
                    { orderable: false, targets: [0] }
                ]
            });
        }

        function toastSuccess(message) {
            if (window.toastr && typeof window.toastr.success === 'function') {
                window.toastr.success(message);
            }
        }

        function toastError(message) {
            if (window.toastr && typeof window.toastr.error === 'function') {
                window.toastr.error(message);
            }
        }

        function getCsrfToken() {
            var meta = document.querySelector('meta[name="csrf-token"]');
            return meta ? meta.getAttribute('content') : '';
        }

        function getSelectedProductIds() {
            return Array.from(document.querySelectorAll('input.checkbox:checked')).map(function (el) {
                return el.value;
            });
        }

        var checkAll = document.querySelector('.checkall');
        if (checkAll) {
            checkAll.addEventListener('change', function (e) {
                var checked = !!e.target.checked;
                document.querySelectorAll('input.checkbox').forEach(function (cb) {
                    cb.checked = checked;
                });
            });
        }

        document.addEventListener('change', function (e) {
            var target = e.target;
            if (!(target instanceof HTMLElement)) return;

            if (target.classList.contains('js-auto-submit')) {
                var form = target.closest('form');
                if (form) {
                    form.submit();
                }
            }
        });

        document.addEventListener('change', function (e) {
            var el = e.target;
            if (!(el instanceof HTMLInputElement)) return;
            if (!el.classList.contains('js-product-flag')) return;

            var isOn = el.checked;
            var url = isOn ? el.getAttribute('data-url-on') : el.getAttribute('data-url-off');
            var productId = el.getAttribute('data-product-id');
            if (!url || !productId) return;

            var u = new URL(url, window.location.origin);
            u.searchParams.append('product_ids[]', productId);

            fetch(u.toString(), {
                method: 'GET',
                headers: {
                    'X-Requested-With': 'XMLHttpRequest',
                    'X-CSRF-TOKEN': getCsrfToken(),
                    'Accept': 'application/json'
                }
            })
                .then(function (r) { return r.json(); })
                .then(function (res) {
                    if (res && res.status === 'success') {
                        toastSuccess(res.message || 'Updated');
                    } else {
                        toastError('Failed something wrong');
                        el.checked = !isOn;
                    }
                })
                .catch(function () {
                    toastError('Failed something wrong');
                    el.checked = !isOn;
                });
        });

        document.addEventListener('click', function (e) {
            var a = e.target && (e.target.closest ? e.target.closest('a.hotdeal_update, a.update_status') : null);
            if (!a) return;

            e.preventDefault();

            var url = a.getAttribute('href');
            var productIds = getSelectedProductIds();
            if (!productIds.length) {
                toastError('Please Select A Product First !');
                return;
            }

            var u = new URL(url, window.location.origin);
            productIds.forEach(function (id) {
                u.searchParams.append('product_ids[]', id);
            });

            fetch(u.toString(), {
                method: 'GET',
                headers: {
                    'X-Requested-With': 'XMLHttpRequest',
                    'X-CSRF-TOKEN': getCsrfToken(),
                    'Accept': 'application/json'
                }
            })
                .then(function (r) { return r.json(); })
                .then(function (res) {
                    if (res && res.status === 'success') {
                        toastSuccess(res.message || 'Updated');
                        window.location.reload();
                    } else {
                        toastError('Failed something wrong');
                    }
                })
                .catch(function () {
                    toastError('Failed something wrong');
                });
        });
    });
</script>
@endpush
