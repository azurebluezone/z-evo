@extends('backEnd.layouts.app')

@section('title','Product Create')

@section('content')
  <div class="row">
    <div class="col-12">
      <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3 no-print">
        <div class="d-flex flex-wrap align-items-center gap-2">
          <a href="{{ route('products.index') }}" class="btn btn-outline-secondary btn-sm">All Products</a>
        </div>
        <div class="d-flex align-items-center gap-2">
          <button type="button" class="btn btn-outline-primary btn-sm">Save draft</button>
          <button type="submit" form="productForm" class="btn btn-primary btn-sm">Publish product</button>
        </div>
      </div>

      <div class="app-ecommerce">
        <form action="{{route('products.store')}}" method="POST" class="row" enctype="multipart/form-data" id="productForm">
        @csrf

      <div class="col-12">
        <div class="card mb-3">
          <div class="card-header">
            <h5 class="card-title mb-0">Product information</h5>
          </div>
          <div class="card-body">

            <div class="row">

            <div class="col-12 col-sm-6">
              <div class="form-group mb-3">
                <label for="name" class="form-label">Product Name *</label>
                <input type="text" class="form-control @error('name') is-invalid @enderror" name="name" value="{{ old('name') }}" id="name" required="" />
                @error('name')
                <span class="invalid-feedback" role="alert">
                  <strong>{{ $message }}</strong>
                </span>
                @enderror
              </div>
            </div>

            <div class="col-12 col-sm-6">
              <div class="form-group mb-3">
                <label for="category_id" class="form-label">Categories *</label>
                <select class="form-select @error('category_id') is-invalid @enderror" name="category_id" id="category_id" required>
                  <option value="">Select..</option>
                  @foreach($categories as $category)
                  <option value="{{$category->id}}" @if(old('category_id')==$category->id) selected @endif>{{$category->name}}</option>
                  @endforeach
                </select>
                @error('category_id')
                <span class="invalid-feedback" role="alert">
                  <strong>{{ $message }}</strong>
                </span>
                @enderror
              </div>
            </div>

            <div class="col-12 col-sm-6">
              <div class="form-group mb-3">
                <label for="subcategory_id" class="form-label">SubCategories (Optional)</label>
                <select class="form-select @error('subcategory_id') is-invalid @enderror" id="subcategory_id" name="subcategory_id">
                  <optgroup>
                    <option value="">Select..</option>
                  </optgroup>
                </select>
                @error('subcategory_id')
                <span class="invalid-feedback" role="alert">
                  <strong>{{ $message }}</strong>
                </span>
                @enderror
              </div>
            </div>

            <div class="col-12 col-sm-6">
              <div class="form-group mb-3">
                <label for="childcategory_id" class="form-label">Child Categories (Optional)</label>
                <select class="form-select @error('childcategory_id') is-invalid @enderror" id="childcategory_id" name="childcategory_id">
                  <optgroup>
                    <option value="">Select..</option>
                  </optgroup>
                </select>
                @error('childcategory_id')
                <span class="invalid-feedback" role="alert">
                  <strong>{{ $message }}</strong>
                </span>
                @enderror
              </div>
            </div>

            <div class="col-12 col-sm-6 mb-3">
              <label for="image" class="form-label">Main Image *</label>
              <input type="file" name="image[]" class="form-control" />
              @error('image')
              <span class="invalid-feedback" role="alert">
                <strong>{{ $message }}</strong>
              </span>
              @enderror
            </div>


            <div class="col-12 col-sm-6 mb-3">
              <label for="gallery_images" class="form-label">Gallery Images</label>
              <input type="file" name="image[]" class="form-control" multiple />
            </div>

            <div class="col-12 col-sm-6">
              <div class="form-group mb-3">
                <label for="pro_unit" class="form-label">Product Unit (Optional)</label>
                <input type="text" class="form-control @error('pro_unit') is-invalid @enderror" name="pro_unit" value="{{ old('pro_unit') }}" id="pro_unit" />
                @error('pro_unit')
                <span class="invalid-feedback" role="alert">
                  <strong>{{ $message }}</strong>
                </span>
                @enderror
              </div>
            </div>

            <div class="col-12 col-sm-6">
              <div class="form-group mb-3">
                <label for="pro_video" class="form-label">Product Video (Optional)</label>
                <input type="text" class="form-control @error('pro_video') is-invalid @enderror" name="pro_video" value="{{ old('pro_video') }}" id="pro_video" />
                @error('pro_video')
                <span class="invalid-feedback" role="alert">
                  <strong>{{ $message }}</strong>
                </span>
                @enderror
              </div>
            </div>

            <div class="col-12 col-sm-6">
              <div class="form-group mb-3">
                <label for="document" class="form-label">Document (Optional)</label>
                <input type="file" class="form-control @error('document') is-invalid @enderror" name="document" id="document" />
                @error('document')
                <span class="invalid-feedback" role="alert">
                  <strong>{{ $message }}</strong>
                </span>
                @enderror
              </div>
            </div>

            <div class="col-sm-12 mb-3">
              <div class="card border">
                <div class="card-header d-flex align-items-center justify-content-between">
                  <div class="fw-semibold">Description *</div>
                </div>
                <div class="card-body">
                  <textarea name="description" id="description" class="form-control @error('description') is-invalid @enderror" rows="6" placeholder="Write product description..." style="display:none;">{{ old('description') }}</textarea>
                  <div id="full-editor" class="border rounded" style="min-height: 260px;"></div>
                  @error('description')
                  <div class="text-danger mt-1">{{ $message }}</div>
                  @enderror
                </div>
              </div>
            </div>

            <div class="col-sm-12 mb-3">
              <div class="card">
                <div class="card-header">
                  <h5 class="card-title mb-0">Attributes / Variants</h5>
                </div>
                <div class="card-body">
                  <div class="row g-3">
                    <div class="col-12 col-lg-6">
                      <label class="form-label">Attributes</label>
                      <select class="form-select" id="variant_attributes" multiple size="6">
                        @if(isset($attributes) && count($attributes) > 0)
                          @foreach($attributes as $a)
                            <option value="{{ $a->id }}" data-slug="{{ $a->slug }}">{{ $a->name }}</option>
                          @endforeach
                        @else
                          <option value="" disabled>No attributes available</option>
                        @endif
                      </select>
                      <small class="text-muted d-block mt-1">Hold Ctrl/Cmd to select multiple</small>
                    </div>
                    <div class="col-12 col-lg-6 d-flex align-items-end">
                      <button type="button" class="btn btn-outline-primary" id="btn_generate_variants">Generate Variants</button>
                    </div>
                  </div>

                  <textarea class="d-none" id="variant_attributes_json">@json(isset($attributes) ? $attributes : [])</textarea>
                  <textarea class="d-none" id="variant_attribute_values_json">@json(isset($attributeValues) ? $attributeValues : [])</textarea>

                  <div class="row mt-3">
                    <div class="col-12" id="variant_attribute_values_container"></div>
                  </div>

                  <div class="row mt-3">
                    <div class="col-12">
                      <div id="variants_table" style="display:none;">
                        <div class="table-responsive">
                          <table class="table table-bordered align-middle mb-0">
                            <thead class="table-light">
                              <tr>
                                <th style="min-width:220px;">Variant</th>
                                <th style="min-width:140px;">Purchase</th>
                                <th style="min-width:140px;">Sale</th>
                                <th style="min-width:140px;">Discount</th>
                                <th style="min-width:220px;">Image</th>
                                <th style="min-width:140px;">Stock</th>
                              </tr>
                            </thead>
                            <tbody id="variants_container"></tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

        

      <div class="col-12">
        <div class="card mb-3">
          <div class="card-header">
            <h5 class="card-title mb-0">Pricing</h5>
          </div>
          <div class="card-body">
                <div class="mb-3">
                  <label for="purchase_price" class="form-label">Purchase Price *</label>
                  <input type="text" class="form-control @error('purchase_price') is-invalid @enderror" name="purchase_price" value="{{ old('purchase_price') }}" id="purchase_price" required />
                  @error('purchase_price')
                  <span class="invalid-feedback" role="alert">
                    <strong>{{ $message }}</strong>
                  </span>
                  @enderror
                </div>

                <div class="mb-3">
                  <label for="new_price" class="form-label">Best Price *</label>
                  <input type="text" class="form-control @error('new_price') is-invalid @enderror" name="new_price" value="{{ old('new_price') }}" id="new_price" required />
                  @error('new_price')
                  <span class="invalid-feedback" role="alert">
                    <strong>{{ $message }}</strong>
                  </span>
                  @enderror
                </div>

                <div class="mb-3">
                  <label for="old_price" class="form-label">Discounted Price</label>
                  <input type="text" class="form-control @error('old_price') is-invalid @enderror" name="old_price" value="{{ old('old_price') }}" id="old_price" />
                  @error('old_price')
                  <span class="invalid-feedback" role="alert">
                    <strong>{{ $message }}</strong>
                  </span>
                  @enderror
                </div>

                <div class="mb-0">
                  <label for="stock" class="form-label">Stock *</label>
                  <input type="text" class="form-control @error('stock') is-invalid @enderror" name="stock" value="{{ old('stock', 0) }}" id="stock" />
                  @error('stock')
                  <span class="invalid-feedback" role="alert">
                    <strong>{{ $message }}</strong>
                  </span>
                  @enderror
                </div>
              </div>
            </div>

            <div class="card mb-3">
              <div class="card-header">
                <h5 class="card-title mb-0">Organize</h5>
              </div>
              <div class="card-body">
                <div class="mb-3">
                  <label class="form-label">Coupons (Optional)</label>
                  <select class="form-select" name="coupon_ids[]" multiple size="4">
                    @if(isset($coupons) && count($coupons) > 0)
                      @foreach($coupons as $coupon)
                        <option value="{{ $coupon->id }}">{{ $coupon->code }}</option>
                      @endforeach
                    @else
                      <option value="" disabled>No coupons available</option>
                    @endif
                  </select>
                  <small class="text-muted d-block mt-1">Hold Ctrl/Cmd to select multiple</small>
                </div>

                <div class="mb-3">
                  <label class="form-label">Brands</label>
                  <select class="form-select @error('brand_id') is-invalid @enderror" name="brand_id">
                    <option value="">Select Brand..</option>
                    @if(isset($brands) && count($brands) > 0)
                      @foreach($brands as $value)
                      <option value="{{$value->id}}" @if(old('brand_id')==$value->id) selected @endif>{{$value->name}}</option>
                      @endforeach
                    @else
                      <option value="" disabled>No brands available</option>
                    @endif
                  </select>
                  @error('brand_id')
                  <span class="invalid-feedback" role="alert">
                    <strong>{{ $message }}</strong>
                  </span>
                  @enderror
                </div>

                <div class="mb-3">
                  <label class="form-label">Status</label>
                  <label class="switch switch-square">
                    <input type="checkbox" class="switch-input" name="status" value="1" checked>
                    <span class="switch-toggle-slider">
                      <span class="switch-on"><i class="icon-base ri ri-check-line"></i></span>
                      <span class="switch-off"><i class="icon-base ri ri-close-line"></i></span>
                    </span>
                    <span class="switch-label">Active</span>
                  </label>
                </div>

                <div class="mb-0">
                  <label class="form-label">Hot Deals</label>
                  <label class="switch switch-square">
                    <input type="checkbox" class="switch-input" name="topsale" value="1">
                    <span class="switch-toggle-slider">
                      <span class="switch-on"><i class="icon-base ri ri-check-line"></i></span>
                      <span class="switch-off"><i class="icon-base ri ri-close-line"></i></span>
                    </span>
                    <span class="switch-label">Enable</span>
                  </label>
                </div>

                <div class="mt-3 mb-0">
                  <label class="form-label">Recommendation</label>
                  <label class="switch switch-square">
                    <input type="checkbox" class="switch-input" name="is_recommended" value="1">
                    <span class="switch-toggle-slider">
                      <span class="switch-on"><i class="icon-base ri ri-check-line"></i></span>
                      <span class="switch-off"><i class="icon-base ri ri-close-line"></i></span>
                    </span>
                    <span class="switch-label">Enable</span>
                  </label>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>

      <div class="col-12">
          <div class="card">
            <div class="card-header">
              <h5 class="card-title mb-0">SEO Meta Tags</h5>
            </div>
            <div class="card-body">
            @include('backEnd.layouts.partials.seo-fields')
            </div>
          </div>
        </div>

        </form>
      </div>
    </div>
  </div>
@endsection
