@extends('backEnd.layouts.app') 
@section('title','Product Edit') 

@section('content')
<div class="row">
  <div class="col-12">
    <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3 no-print">
      <div class="d-flex flex-wrap align-items-center gap-2">
        <a href="{{ route('products.index') }}" class="btn btn-outline-secondary btn-sm">All Products</a>
      </div>
      <div class="d-flex align-items-center gap-2">
        <button type="button" class="btn btn-outline-primary btn-sm">Save draft</button>
        <button type="submit" form="productEditForm" class="btn btn-primary btn-sm">Update product</button>
      </div>
    </div>

    <div class="app-ecommerce">
      <form action="{{route('products.update')}}" method="POST" class="row" enctype="multipart/form-data" name="editForm" id="productEditForm">
        @csrf
        <input type="hidden" value="{{$edit_data->id}}" name="id" />

      <div class="col-12">
        <div class="card mb-3">
          <div class="card-header">
            <h5 class="card-title mb-0">Product Information</h5>
          </div>
          <div class="card-body">
            <div class="row">
              <div class="col-12 col-sm-6">
                <div class="form-group mb-3">
                  <label for="name" class="form-label">Product Name *</label>
                  <input type="text" class="form-control @error('name') is-invalid @enderror" name="name" value="{{$edit_data->name }}" id="name" required="" />
                  @error('name')
                  <span class="invalid-feedback" role="alert">
                    <strong>{{ $message }}</strong>
                  </span>
                  @enderror
                </div>
              </div>

              <div class="col-12 col-sm-6">
                <div class="form-group mb-3">
                  <label for="category_id" class="form-label">Categories *</label>
                  <select class="form-select @error('category_id') is-invalid @enderror" name="category_id" id="category_id" required>
                    <option value="">Select..</option>
                    @foreach($categories as $category)
                      <option value="{{$category->id}}" @if($edit_data->category_id==$category->id) selected @endif>{{$category->name}}</option>
                    @endforeach
                  </select>
                  @error('category_id')
                  <span class="invalid-feedback" role="alert">
                    <strong>{{ $message }}</strong>
                  </span>
                  @enderror
                </div>
              </div>

              <div class="col-12 col-sm-6">
                <div class="form-group mb-3">
                  <label for="subcategory_id" class="form-label">SubCategories (Optional)</label>
                  <select class="form-select @error('subcategory_id') is-invalid @enderror" id="subcategory_id" name="subcategory_id">
                    <option value="">Select..</option>
                    @foreach($subcategory as $key=>$value)
                    <option value="{{$value->id}}" @if($edit_data->subcategory_id==$value->id) selected @endif>{{$value->subcategoryName}}</option>
                    @endforeach
                  </select>
                  @error('subcategory_id')
                <span class="invalid-feedback" role="alert">
                  <strong>{{ $message }}</strong>
                </span>
                @enderror
              </div>
            </div>

            <div class="col-12 col-sm-6">
              <div class="form-group mb-3">
                <label for="childcategory_id" class="form-label">Child Categories (Optional)</label>
                <select class="form-select @error('childcategory_id') is-invalid @enderror" id="childcategory_id" name="childcategory_id">
                  <optgroup>
                    <option value="">Select..</option>
                    @foreach($childcategory as $key=>$value)
                    <option value="{{$value->id}}" @if($edit_data->childcategory_id==$value->id) selected @endif>{{$value->childcategoryName}}</option>
                    @endforeach
                  </optgroup>
                </select>
                @error('childcategory_id')
                <span class="invalid-feedback" role="alert">
                  <strong>{{ $message }}</strong>
                </span>
                @enderror
              </div>
            </div>

            <div class="col-12 col-sm-4">
              <div class="form-group mb-3">
                <label for="brand_id" class="form-label">Brands</label>
                <select class="form-select @error('brand_id') is-invalid @enderror" name="brand_id">
                  <option value="">Select..</option>
                  @foreach($brands as $value)
                  <option value="{{$value->id}}" @if($edit_data->brand_id==$value->id) selected @endif>{{$value->name}}</option>
                  @endforeach
                </select>
                @error('brand_id')
                <span class="invalid-feedback" role="alert">
                  <strong>{{ $message }}</strong>
                </span>
                @enderror
              </div>
            </div>

            <div class="col-12 col-sm-4">
              <div class="form-group mb-3">
                <label class="form-label">Coupons (Optional)</label>
                <select class="form-select" name="coupon_ids[]" multiple size="4">
                  @if(isset($coupons))
                    @foreach($coupons as $coupon)
                      <option value="{{ $coupon->id }}" @if(isset($selected_coupon_ids) && in_array($coupon->id, $selected_coupon_ids)) selected @endif>{{ $coupon->code }}</option>
                    @endforeach
                  @endif
                </select>
                <small class="text-muted d-block mt-1">Hold Ctrl/Cmd to select multiple</small>
              </div>
            </div>

            <div class="col-12 col-sm-4">
              <div class="form-group mb-3">
                <label for="purchase_price" class="form-label">Purchase Price *</label>
                <input type="text" class="form-control @error('purchase_price') is-invalid @enderror" name="purchase_price" value="{{ $edit_data->purchase_price}}" id="purchase_price" required />
                @error('purchase_price')
                <span class="invalid-feedback" role="alert">
                  <strong>{{ $message }}</strong>
                </span>
                @enderror
              </div>
            </div>

            <div class="col-12 col-sm-4">
              <div class="form-group mb-3">
                <label for="new_price" class="form-label">New Price *</label>
                <input type="text" class="form-control @error('new_price') is-invalid @enderror" name="new_price" value="{{ $edit_data->new_price }}" id="new_price" required />
                @error('new_price')
                <span class="invalid-feedback" role="alert">
                  <strong>{{ $message }}</strong>
                </span>
                @enderror
              </div>
            </div>

            <div class="col-12 col-sm-4">
              <div class="form-group mb-3">
                <label for="old_price" class="form-label">Old Price *</label>
                <input type="text" class="form-control @error('old_price') is-invalid @enderror" name="old_price" value="{{ $edit_data->old_price }}" id="old_price" />
                @error('old_price')
                <span class="invalid-feedback" role="alert">
                  <strong>{{ $message }}</strong>
                </span>
                @enderror
              </div>
            </div>

            <div class="col-12 col-sm-4">
              <div class="form-group mb-3">
                <label for="stock" class="form-label">Stock *</label>
                <input type="text" class="form-control @error('stock') is-invalid @enderror" name="stock" value="{{ $edit_data->stock }}" id="stock" readonly />
                @error('stock')
                <span class="invalid-feedback" role="alert">
                  <strong>{{ $message }}</strong>
                </span>
                @enderror
                <div class="form-text">
                  Stock is ledger-based. Use
                  <a href="{{ route('admin.inventory.adjustment') }}">Inventory Adjustment</a>
                  to add/reduce stock.
                </div>
              </div>
            </div>

            <div class="col-sm-12 mb-3">
              <label class="form-label">Images</label>

              @foreach ($edit_data->images as $image)
              @php
                  $imgPath = preg_replace('~^public/~', '', (string) ($image->image ?? ''));
                  $imgPath = ltrim($imgPath, '/');
              @endphp
              @if($imgPath)
              <div class="input-group control-group">
                  <img src="{{ asset($imgPath) }}" alt="Product Image" style="height: 100px; width: auto;" onerror="this.style.display='none'">
                  <input type="text" name="title[]" class="form-control mt-2" value="{{ $image->title }}" placeholder="Image Title">
                  <input type="hidden" name="image[]" value="{{ $image->id }}">
                  <div class="input-group-btn">
                      <button class="btn btn-danger remove-image" type="button" data-image-id="{{ $image->id }}"><i class="iconify" data-icon="bx:trash"></i></button>
                  </div>
              </div>
              @endif
              @endforeach

              <div class="clone hide" style="display: none;">
                  <div class="control-group input-group" style="margin-top: 10px;">
                      <input type="file" name="image[]" class="form-control" />
                      <input type="text" name="title[]" class="form-control mt-2" placeholder="Image Title" />
                      <div class="input-group-btn">
                          <button class="btn btn-danger" type="button"><i class="iconify" data-icon="bx:trash"></i></button>
                      </div>
                  </div>
              </div>

              <div class="input-group control-group increment">
                  <input type="file" name="image[]" class="form-control @error('image') is-invalid @enderror" />
                  <input type="text" name="title[]" class="form-control mt-2" placeholder="Image Title" />
                  <div class="input-group-btn mt-2">
                      <button class="btn btn-success btn-increment" type="button"><i class="iconify" data-icon="bx:plus"></i></button>
                  </div>
                  @error('image')
                  <span class="invalid-feedback" role="alert">
                      <strong>{{ $message }}</strong>
                  </span>
                  @enderror
              </div>
            </div>

            <div class="col-12 col-sm-6">
              <div class="form-group mb-3">
                <label for="pro_unit" class="form-label">Product Unit (Optional)</label>
                <input type="text" class="form-control @error('pro_unit') is-invalid @enderror" name="pro_unit" value="{{ $edit_data->pro_unit }}" id="pro_unit" />
                @error('pro_unit')
                <span class="invalid-feedback" role="alert">
                  <strong>{{ $message }}</strong>
                </span>
                @enderror
              </div>
            </div>

            <div class="col-12 col-sm-6">
              <div class="form-group mb-3">
                <label for="pro_video" class="form-label">Product Video (Optional)</label>
                <input type="text" class="form-control @error('pro_video') is-invalid @enderror" name="pro_video" value="{{ $edit_data->pro_video }}" id="pro_video" />
                @error('pro_video')
                <span class="invalid-feedback" role="alert">
                  <strong>{{ $message }}</strong>
                </span>
                @enderror
              </div>
            </div>

            <div class="col-12 col-sm-6">
              <div class="form-group mb-3">
                <label for="document" class="form-label">Document (Optional)</label>
                <input type="file" class="form-control @error('document') is-invalid @enderror" name="document" id="document" />
                @php
                  $rawDoc = (string) ($edit_data->document ?? '');
                  $hasDocFile = $rawDoc !== '' && (str_starts_with($rawDoc, 'uploads/') || str_starts_with($rawDoc, 'public/uploads/') || str_starts_with($rawDoc, '/uploads/') || str_starts_with($rawDoc, '/public/uploads/'));
                @endphp
                @if($hasDocFile)
                  @php
                    $docPath = preg_replace('~^public/~', '', $rawDoc);
                    $docPath = ltrim($docPath, '/');
                  @endphp
                  <div class="form-text">
                    <a href="{{ asset($docPath) }}" target="_blank">View current document</a>
                  </div>
                @endif
                @error('document')
                <span class="invalid-feedback" role="alert">
                  <strong>{{ $message }}</strong>
                </span>
                @enderror
              </div>
            </div>

            <div class="col-12 mb-3">
              <div class="card border">
                <div class="card-header d-flex align-items-center justify-content-between">
                  <div class="fw-semibold">Description</div>
                </div>
                <div class="card-body">
                  <textarea name="description" id="description" class="form-control @error('description') is-invalid @enderror" rows="6" placeholder="Write product description..." style="display:none;">{{ old('description', $edit_data->description ?? '') }}</textarea>
                  <div id="full-editor" class="border rounded" style="min-height: 260px;"></div>
                  @error('description')
                  <div class="text-danger mt-1">{{ $message }}</div>
                  @enderror
                </div>
              </div>
            </div>

            <div class="col-6 col-sm-3 mb-3">
              <div class="form-group">
                <label class="d-block">Status</label>
                <div class="form-check form-switch">
                  <input class="form-check-input" type="checkbox" role="switch" value="1" name="status" @if($edit_data->status==1)checked @endif>
                </div>
                @error('status')
                <span class="invalid-feedback" role="alert">
                  <strong>{{ $message }}</strong>
                </span>
                @enderror
              </div>
            </div>

            <div class="col-6 col-sm-3 mb-3">
              <div class="form-group">
                <label class="d-block">Hot Deals</label>
                <div class="form-check form-switch">
                  <input class="form-check-input" type="checkbox" role="switch" value="1" name="topsale" @if($edit_data->topsale==1)checked @endif>
                </div>
                @error('topsale')
                <span class="invalid-feedback" role="alert">
                  <strong>{{ $message }}</strong>
                </span>
                @enderror
              </div>
            </div>

            <div class="col-6 col-sm-3 mb-3">
              <div class="form-group">
                <label class="d-block">Recommendation</label>
                <div class="form-check form-switch">
                  <input class="form-check-input" type="checkbox" role="switch" value="1" name="is_recommended" @if(($edit_data->is_recommended ?? 0)==1)checked @endif>
                </div>
                @error('is_recommended')
                <span class="invalid-feedback" role="alert">
                  <strong>{{ $message }}</strong>
                </span>
                @enderror
              </div>
            </div>

            </div>
          </div>
        </div>
      </div>

      <div class="col-12">
        <div class="card">
          <div class="card-header">
            <h5 class="card-title mb-0">SEO Meta Tags</h5>
          </div>
          <div class="card-body">
            @php
              $model = $edit_data;
            @endphp
            @include('backEnd.layouts.partials.seo-fields')
          </div>
        </div>
      </div>
  </form>
    </div>
  </div>
</div>
@endsection
