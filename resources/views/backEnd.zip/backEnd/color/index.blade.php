@extends('backEnd.layouts.murubbi')
@section('title','Color Manage')

@section('content')
<div class="card">
    <div class="card-body">
        <table id="datatable-buttons" class="table table-hover">
            <thead>
                <tr>
                    <th>SL</th>
                    <th>Color Name</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                @foreach($show_data as $key=>$value)
                <tr>
                    <td>{{$loop->iteration}}</td>
                    <td><span class="badge" style="background-color: {{ $value->color }}; color: #fff">{{$value->colorName}}</span></td>
                    <td>@if($value->status==1)<span class="badge bg-label-success rounded-pill">Active</span> @else <span class="badge bg-label-danger rounded-pill">Inactive</span> @endif</td>
                    <td>
                        <div class="d-flex gap-1">
                            @if($value->status == 1)
                            <form method="post" action="{{route('colors.inactive')}}" class="d-inline">
                                @csrf
                                <input type="hidden" value="{{$value->id}}" name="hidden_id">
                                <button type="button" class="btn btn-sm btn-icon btn-text-warning waves-effect waves-light change-confirm"><i class="icon-base ri ri-thumb-down-line"></i></button>
                            </form>
                            @else
                            <form method="post" action="{{route('colors.active')}}" class="d-inline">
                                @csrf
                                <input type="hidden" value="{{$value->id}}" name="hidden_id">
                                <button type="button" class="btn btn-sm btn-icon btn-text-success waves-effect waves-light change-confirm"><i class="icon-base ri ri-thumb-up-line"></i></button>
                            </form>
                            @endif

                            <a href="{{route('colors.edit',$value->id)}}" class="btn btn-sm btn-icon btn-text-primary waves-effect waves-light"><i class="icon-base ri ri-edit-line"></i></a>

                            <form method="post" action="{{route('colors.destroy')}}" class="d-inline">
                                @csrf
                                <input type="hidden" value="{{$value->id}}" name="hidden_id">
                                <button type="submit" class="btn btn-sm btn-icon btn-text-danger waves-effect waves-light delete-confirm"><i class="icon-base ri ri-delete-bin-line"></i></button>
                            </form>
                        </div>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</div>
@endsection