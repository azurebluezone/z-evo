@extends('backEnd.layouts.app')
@section('title','All Visitors')

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <h4 class="page-title">All Visitors</h4>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-12">
            <div class="card mb-3">
                <div class="card-body">
                    <form method="get" action="{{ route('admin.visitors.index') }}" class="row g-2 align-items-end">
                        <div class="col-sm-6 col-md-3">
                            <label class="form-label">Visitor ID</label>
                            <input type="text" name="visitor_id" class="form-control" value="{{ request()->get('visitor_id') }}" placeholder="UUID">
                        </div>
                        <div class="col-sm-6 col-md-3">
                            <label class="form-label">IP</label>
                            <input type="text" name="ip" class="form-control" value="{{ request()->get('ip') }}" placeholder="IP address">
                        </div>
                        <div class="col-sm-6 col-md-2">
                            <label class="form-label">Country</label>
                            <input type="text" name="country" class="form-control" value="{{ request()->get('country') }}">
                        </div>
                        <div class="col-sm-6 col-md-2">
                            <label class="form-label">City</label>
                            <input type="text" name="city" class="form-control" value="{{ request()->get('city') }}">
                        </div>
                        <div class="col-sm-6 col-md-2">
                            <label class="form-label">Status</label>
                            <select name="status" class="form-select">
                                <option value="">All</option>
                                <option value="1" {{ request()->get('status') === '1' ? 'selected' : '' }}>Active</option>
                                <option value="0" {{ request()->get('status') === '0' ? 'selected' : '' }}>Blocked</option>
                            </select>
                        </div>

                        <div class="col-sm-6 col-md-3">
                            <label class="form-label">ISP</label>
                            <input type="text" name="isp" class="form-control" value="{{ request()->get('isp') }}">
                        </div>
                        <div class="col-sm-6 col-md-3">
                            <label class="form-label">User Agent</label>
                            <input type="text" name="user_agent" class="form-control" value="{{ request()->get('user_agent') }}">
                        </div>
                        <div class="col-sm-6 col-md-2">
                            <label class="form-label">From</label>
                            <input type="date" name="from" class="form-control" value="{{ request()->get('from') }}">
                        </div>
                        <div class="col-sm-6 col-md-2">
                            <label class="form-label">To</label>
                            <input type="date" name="to" class="form-control" value="{{ request()->get('to') }}">
                        </div>
                        <div class="col-sm-12 col-md-2">
                            <button type="submit" class="btn btn-primary w-100">Search</button>
                        </div>
                    </form>
                </div>
            </div>

            <div class="card">
                <div class="card-body">
                    <form method="post" action="" id="bulkActionForm">
                        @csrf
                        <input type="hidden" name="_bulk_action" id="bulkAction" value="">

                        <div class="d-flex flex-wrap gap-2 justify-content-end mb-2">
                            <button type="button" class="btn btn-sm btn-danger" id="bulkBlockBtn" disabled>Block Selected</button>
                            <button type="button" class="btn btn-sm btn-primary" id="bulkUnblockBtn" disabled>Unblock Selected</button>
                        </div>

                    <div class="card-datatable table-responsive">
                        <table class="table table-striped w-100 align-middle">
                            <thead>
                                <tr>
                                    <th style="width:40px;">
                                        <input type="checkbox" id="selectAll">
                                    </th>
                                    <th>SL</th>
                                    <th>Visitor ID</th>
                                    <th>IP</th>
                                    <th>Country</th>
                                    <th>City</th>
                                    <th>ISP</th>
                                    <th>Status</th>
                                    <th>Created</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($visitors as $row)
                                    <tr>
                                        <td>
                                            <input type="checkbox" class="row-check" name="ids[]" value="{{ $row->id }}">
                                        </td>
                                        <td>{{ ($visitors->currentPage() - 1) * $visitors->perPage() + $loop->iteration }}</td>
                                        <td class="text-nowrap">
                                            <button
                                                type="button"
                                                class="btn btn-link p-0"
                                                data-bs-toggle="modal"
                                                data-bs-target="#visitorInfoModal"
                                                data-title="Visitor ID"
                                                data-value="{{ $row->visitor_id }}"
                                                title="View Visitor ID"
                                            ><i class="icon-base ri ri-eye-line icon-22px"></i></button>
                                        </td>
                                        <td class="text-nowrap">{{ $row->ip }}</td>
                                        <td>{{ $row->country ?? '' }}</td>
                                        <td>{{ $row->city ?? '' }}</td>
                                        <td>{{ $row->isp ?? '' }}</td>
                                        <td>
                                            @if((int) $row->status === 1)
                                                <span class="badge bg-soft-success text-success">Active</span>
                                            @else
                                                <span class="badge bg-soft-danger text-danger">Blocked</span>
                                            @endif
                                        </td>
                                        <td class="text-nowrap">
                                            <button
                                                type="button"
                                                class="btn btn-link p-0"
                                                data-bs-toggle="modal"
                                                data-bs-target="#visitorInfoModal"
                                                data-title="Created"
                                                data-value="{{ $row->created_at ? $row->created_at->format('d-m-Y h:i a') : '' }}"
                                                title="View Created"
                                            ><i class="icon-base ri ri-eye-line icon-22px"></i></button>
                                        </td>
                                        <td>
                                            <div class="button-list">
                                                @if((int) $row->status === 1)
                                                    <form method="post" action="{{ route('admin.visitors.block') }}" class="d-inline">
                                                        @csrf
                                                        <input type="hidden" value="{{ $row->id }}" name="hidden_id">
                                                        <label class="switch switch-square mb-0">
                                                            <input type="checkbox" class="switch-input js-auto-submit" checked>
                                                            <span class="switch-toggle-slider">
                                                                <span class="switch-on"><i class="icon-base ri ri-check-line"></i></span>
                                                                <span class="switch-off"><i class="icon-base ri ri-close-line"></i></span>
                                                            </span>
                                                        </label>
                                                    </form>
                                                @else
                                                    <form method="post" action="{{ route('admin.visitors.unblock') }}" class="d-inline">
                                                        @csrf
                                                        <input type="hidden" value="{{ $row->id }}" name="hidden_id">
                                                        <label class="switch switch-square mb-0">
                                                            <input type="checkbox" class="switch-input js-auto-submit">
                                                            <span class="switch-toggle-slider">
                                                                <span class="switch-on"><i class="icon-base ri ri-check-line"></i></span>
                                                                <span class="switch-off"><i class="icon-base ri ri-close-line"></i></span>
                                                            </span>
                                                        </label>
                                                    </form>
                                                @endif
                                            </div>
                                        </td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="10" class="text-center">No data</td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>

                    </form>

                    <div class="custom-paginate">
                        {{ $visitors->links('pagination::bootstrap-4') }}
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<div class="modal fade" id="visitorInfoModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="visitorInfoModalTitle">Info</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="p-2 bg-light rounded" style="word-break: break-all;">
                    <span id="visitorInfoModalValue"></span>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@section('script')
<script>
    (function () {
        function updateBulkButtons() {
            const checked = document.querySelectorAll('.row-check:checked').length;
            const blockBtn = document.getElementById('bulkBlockBtn');
            const unblockBtn = document.getElementById('bulkUnblockBtn');
            if (blockBtn) blockBtn.disabled = checked < 1;
            if (unblockBtn) unblockBtn.disabled = checked < 1;
        }

        const selectAll = document.getElementById('selectAll');
        if (selectAll) {
            selectAll.addEventListener('change', function () {
                document.querySelectorAll('.row-check').forEach(cb => {
                    cb.checked = selectAll.checked;
                });
                updateBulkButtons();
            });
        }

        document.querySelectorAll('.row-check').forEach(cb => {
            cb.addEventListener('change', function () {
                const all = document.querySelectorAll('.row-check').length;
                const checked = document.querySelectorAll('.row-check:checked').length;
                const selectAll = document.getElementById('selectAll');
                if (selectAll) {
                    selectAll.checked = all > 0 && checked === all;
                    selectAll.indeterminate = checked > 0 && checked < all;
                }
                updateBulkButtons();
            });
        });

        const bulkForm = document.getElementById('bulkActionForm');
        const bulkBlockBtn = document.getElementById('bulkBlockBtn');
        const bulkUnblockBtn = document.getElementById('bulkUnblockBtn');
        if (bulkForm && bulkBlockBtn) {
            bulkBlockBtn.addEventListener('click', function () {
                bulkForm.action = "{{ route('admin.visitors.bulk-block') }}";
                bulkForm.submit();
            });
        }
        if (bulkForm && bulkUnblockBtn) {
            bulkUnblockBtn.addEventListener('click', function () {
                bulkForm.action = "{{ route('admin.visitors.bulk-unblock') }}";
                bulkForm.submit();
            });
        }

        const modalEl = document.getElementById('visitorInfoModal');
        if (modalEl) {
            modalEl.addEventListener('show.bs.modal', function (event) {
                const button = event.relatedTarget;
                const title = button?.getAttribute('data-title') || 'Info';
                const value = button?.getAttribute('data-value') || '';
                const titleEl = document.getElementById('visitorInfoModalTitle');
                const valueEl = document.getElementById('visitorInfoModalValue');
                if (titleEl) titleEl.textContent = title;
                if (valueEl) valueEl.textContent = value;
            });
        }

        updateBulkButtons();
    })();
</script>
@endsection
