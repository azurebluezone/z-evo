@extends('backEnd.layouts.app')
@section('title','Dashboard')
@section('content')
<div class="row">
    <div class="col-12">
        <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3 no-print">
            <div class="d-flex flex-wrap align-items-center gap-2">
                <h4 class="mb-0">Dashboard</h4>
            </div>
            <div class="d-flex flex-wrap align-items-center gap-2">
                <a href="{{ route('admin.orders', ['slug' => 'all']) }}" class="btn btn-outline-secondary btn-sm">All Orders</a>
                <a href="{{ route('admin.invoices.index') }}" class="btn btn-outline-secondary btn-sm">Invoice List</a>
                <a href="{{ route('products.create') }}" class="btn btn-outline-secondary btn-sm">Create Product</a>
                <a href="{{ route('products.index') }}" class="btn btn-outline-secondary btn-sm">Manage Products</a>
                <a href="{{ route('coupons.create') }}" class="btn btn-outline-secondary btn-sm">Create Coupon</a>
            </div>
        </div>

        <div class="card mb-4">
            <div class="card-widget-separator-wrapper">
                <div class="card-body card-widget-separator">
                    <div class="row gy-4 gy-sm-1">
                        <div class="col-sm-6 col-lg-3">
                            <div class="d-flex justify-content-between align-items-start card-widget-1 border-end pb-4 pb-sm-0">
                                <div>
                                    <h4 class="mb-0">৳{{ number_format($total_revenue ?? 0) }}</h4>
                                    <p class="mb-0">Total Revenue (Delivered)</p>
                                </div>
                                <div class="avatar me-sm-6">
                                    <span class="avatar-initial rounded-3 text-heading">
                                        <i class="icon-base ri ri-money-dollar-circle-line icon-26px"></i>
                                    </span>
                                </div>
                            </div>
                            <hr class="d-none d-sm-block d-lg-none me-6">
                        </div>

                        <div class="col-sm-6 col-lg-3">
                            <div class="d-flex justify-content-between align-items-start card-widget-2 border-end pb-4 pb-sm-0">
                                <div>
                                    <h4 class="mb-0">{{ number_format($total_order ?? 0) }}</h4>
                                    <p class="mb-0">Total Orders</p>
                                </div>
                                <div class="avatar me-lg-6">
                                    <span class="avatar-initial rounded-3 text-heading">
                                        <i class="icon-base ri ri-file-list-3-line icon-26px"></i>
                                    </span>
                                </div>
                            </div>
                            <hr class="d-none d-sm-block d-lg-none">
                        </div>

                        <div class="col-sm-6 col-lg-3">
                            <div class="d-flex justify-content-between align-items-start border-end pb-4 pb-sm-0 card-widget-3">
                                <div>
                                    <h4 class="mb-0">{{ number_format($today_visitors ?? 0) }}</h4>
                                    <p class="mb-0">Today's Visitors</p>
                                </div>
                                <div class="avatar me-sm-6">
                                    <span class="avatar-initial rounded-3 text-heading">
                                        <i class="icon-base ri ri-eye-line icon-26px"></i>
                                    </span>
                                </div>
                            </div>
                        </div>

                        <div class="col-sm-6 col-lg-3">
                            <div class="d-flex justify-content-between align-items-start">
                                <div>
                                    <h4 class="mb-0">{{ number_format($social_event_count_today ?? 0) }}</h4>
                                    <p class="mb-0">Social Events Today</p>
                                </div>
                                <div class="avatar">
                                    <span class="avatar-initial rounded-3 text-heading">
                                        <i class="icon-base ri ri-notification-3-line icon-26px"></i>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row g-4">
            <div class="col-12 col-xl-8">
                <div class="card">
                    <div class="card-header d-flex align-items-center justify-content-between">
                        <h5 class="mb-0">Sales Trend (Last 7 Days)</h5>
                    </div>
                    <div class="card-body">
                        <div id="sales-analytics" style="min-height: 360px;"></div>
                    </div>
                </div>
            </div>

            <div class="col-lg-4 col-md-6 order-md-3 order-lg-0">
                <div class="card">
                    <div class="card-header">
                        @php
                            $liveVisitorsGrowth = (float) (($live_visitors_summary['growth_percent'] ?? 0));
                            $liveVisitorsGrowthUp = $liveVisitorsGrowth >= 0;
                            $liveVisitorsCount = (int) (($live_visitors_summary['live'] ?? 0));
                        @endphp
                        <div class="d-flex justify-content-between mb-1">
                            <h5 class="mb-0">Live Visitors</h5>
                            <div class="d-flex align-items-center {{ $liveVisitorsGrowthUp ? 'text-success' : 'text-danger' }}">
                                <p class="mb-0 me-2">{{ $liveVisitorsGrowthUp ? '+' : '' }}{{ number_format($liveVisitorsGrowth, 1) }}%</p>
                                <i class="icon-base ri {{ $liveVisitorsGrowthUp ? 'ri-arrow-up-s-line' : 'ri-arrow-down-s-line' }} mt-n1"></i>
                            </div>
                        </div>
                        <p class="card-subtitle mb-0">Total {{ number_format($liveVisitorsCount) }} Visitors Are Live</p>
                    </div>
                    <div class="card-body">
                        <div id="liveVisitors" style="min-height: 150px;"></div>
                    </div>
                </div>
            </div>

            <div class="col-12 col-xl-6">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">Social Event Feed</h5>
                    </div>
                    <div class="card-body">
                        <table class="table table-sm" id="social-event-feed-table">
                            <thead>
                                <tr>
                                    <th>Event</th>
                                    <th>When</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse(($social_event_feed ?? []) as $row)
                                    @php
                                        $eventName = (string) ($row['event_name'] ?? '');
                                        $url = (string) ($row['url'] ?? '');
                                        $createdAt = $row['created_at'] ?? null;
                                        $created = $createdAt ? \Carbon\Carbon::parse($createdAt)->diffForHumans() : '';
                                    @endphp
                                    <tr>
                                        <td style="white-space: normal; word-break: break-word;">
                                            <div class="fw-medium">{{ $eventName }}</div>
                                            @if($url)
                                                <div class="text-muted small">{{ $url }}</div>
                                            @endif
                                        </td>
                                        <td class="text-nowrap">{{ $created }}</td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="2" class="text-muted">No events found</td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div class="col-12 col-xxl-4 col-md-6">
                <div class="card h-100">
                    <div class="card-header">
                        <div class="d-flex justify-content-between">
                            <h5 class="mb-1">Weekly Sales</h5>
                            <div class="dropdown">
                                <button class="btn btn-text-secondary rounded-pill text-body-secondary border-0 p-1 waves-effect" type="button" id="weeklySalesDropdown" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <i class="icon-base ri ri-more-2-line"></i>
                                </button>
                                <div class="dropdown-menu dropdown-menu-end" aria-labelledby="weeklySalesDropdown">
                                    <a class="dropdown-item waves-effect" href="javascript:void(0);">Refresh</a>
                                    <a class="dropdown-item waves-effect" href="javascript:void(0);">Update</a>
                                    <a class="dropdown-item waves-effect" href="javascript:void(0);">Share</a>
                                </div>
                            </div>
                        </div>
                        <p class="mb-0 card-subtitle">Total ৳{{ number_format((float) ($weekly_sales_widget['total_revenue'] ?? 0)) }} Sales</p>
                    </div>
                    <div class="card-body">
                        <div class="row mb-7 mb-xl-12">
                            <div class="col-6 d-flex align-items-center">
                                <div class="avatar">
                                    <div class="avatar-initial bg-label-primary rounded">
                                        <i class="icon-base ri ri-funds-line icon-24px"></i>
                                    </div>
                                </div>
                                <div class="ms-3 d-flex flex-column">
                                    <p class="mb-0">Revenue</p>
                                    <h6 class="mb-0">৳{{ number_format((float) ($weekly_sales_widget['total_revenue'] ?? 0)) }}</h6>
                                </div>
                            </div>
                            <div class="col-6 d-flex align-items-center">
                                <div class="avatar">
                                    <div class="avatar-initial bg-label-warning rounded">
                                        <i class="icon-base ri ri-eye-line icon-24px"></i>
                                    </div>
                                </div>
                                <div class="ms-3 d-flex flex-column">
                                    <p class="mb-0">Visitors</p>
                                    <h6 class="mb-0">{{ number_format((int) ($weekly_sales_widget['total_visitors'] ?? 0)) }}</h6>
                                </div>
                            </div>
                        </div>
                        <div id="weeklySalesChart" style="min-height: 235px;"></div>
                    </div>
                </div>
            </div>

            <div class="col-12 col-xl-6">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">Latest 5 Orders</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table" id="latest-orders-table">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Invoice</th>
                                        <th>Amount</th>
                                        <th>Customer</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($latest_order as $order)
                                    <tr>
                                        <td>{{ $loop->iteration }}</td>
                                        <td>{{ $order->invoice_id }}</td>
                                        <td>{{ $order->amount }}</td>
                                        <td>{{ $order->customer ? $order->customer->name : '' }}</td>
                                    </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-12 col-xl-6">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">Latest Customers</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table" id="latest-customers-table">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Name</th>
                                        <th>Phone</th>
                                        <th>Date</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($latest_customer as $customer)
                                    <tr>
                                        <td>{{ $loop->iteration }}</td>
                                        <td>{{ $customer->name }}</td>
                                        <td>{{ $customer->phone }}</td>
                                        <td>{{ $customer->created_at->format('d-m-Y') }}</td>
                                    </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
@push('script')
    <script type="module" src="{{ asset('admin/build/dashboards-analytics-CVGa2SfZ.js') }}"></script>
    <script>
      (function () {
        var trend7 = @json($trend7 ?? ['labels' => [], 'series' => []]);
        var liveVisitorsTrend = @json($live_visitors_trend ?? ['series' => []]);
        var weeklySalesWidget = @json($weekly_sales_widget ?? ['labels' => [], 'revenue' => [], 'visitors' => []]);
        var salesChart = null;

        function renderSales() {
          var el = document.querySelector('#sales-analytics');
          if (!el || !window.ApexCharts) return;

          var d = trend7 || { labels: [], series: [] };
          var options = {
            chart: { height: 360, type: 'line', toolbar: { show: false } },
            series: [{ name: 'Revenue', data: d.series }],
            xaxis: { categories: d.labels },
            stroke: { curve: 'smooth', width: 3 },

            grid: { strokeDashArray: 4 },
            colors: ['#696cff']
          };

          salesChart = new window.ApexCharts(el, options);
          salesChart.render();
        }

        function renderLiveVisitors() {
          var el = document.querySelector('#liveVisitors');
          if (!el || !window.ApexCharts) return;

          var series = (liveVisitorsTrend && Array.isArray(liveVisitorsTrend.series)) ? liveVisitorsTrend.series : [];
          var options = {
            chart: {
              height: 150,
              type: 'bar',
              toolbar: { show: false },
              sparkline: { enabled: true }
            },
            series: [{ name: 'Live', data: series }],
            plotOptions: {
              bar: {
                borderRadius: 8,
                columnWidth: '55%'
              }
            },
            dataLabels: { enabled: false },
            grid: { show: false },
            xaxis: { labels: { show: false }, axisBorder: { show: false }, axisTicks: { show: false } },
            yaxis: { show: false },
            colors: ['var(--bs-success)']
          };

          var c = new window.ApexCharts(el, options);
          c.render();
        }

        function renderWeeklySales() {
          var el = document.querySelector('#weeklySalesChart');
          if (!el || !window.ApexCharts) return;

          var labels = (weeklySalesWidget && Array.isArray(weeklySalesWidget.labels)) ? weeklySalesWidget.labels : [];
          var revenue = (weeklySalesWidget && Array.isArray(weeklySalesWidget.revenue)) ? weeklySalesWidget.revenue : [];
          var visitors = (weeklySalesWidget && Array.isArray(weeklySalesWidget.visitors)) ? weeklySalesWidget.visitors : [];

          var options = {
            chart: {
              height: 235,
              type: 'line',
              stacked: false,
              toolbar: { show: false }
            },
            series: [
              { name: 'Revenue', type: 'column', data: revenue },
              { name: 'Visitors', type: 'line', data: visitors }
            ],
            stroke: { width: [0, 3], curve: 'smooth' },
            plotOptions: {
              bar: {
                borderRadius: 8,
                columnWidth: '45%'
              }
            },
            dataLabels: { enabled: false },
            xaxis: { categories: labels },
            yaxis: [
              { labels: { formatter: function (v) { return Math.round(v); } } },
              { opposite: true, labels: { formatter: function (v) { return Math.round(v); } } }
            ],
            grid: { strokeDashArray: 4 },
            colors: ['var(--bs-primary)', 'var(--bs-warning)']
          };

          var c = new window.ApexCharts(el, options);
          c.render();
        }

        document.addEventListener('DOMContentLoaded', function () {
          renderSales();
          renderLiveVisitors();
          renderWeeklySales();
        });
      })();
    </script>
@endpush