@extends('backEnd.layouts.app')
@section('title','Childcategory Edit')
@section('content')
<div class="row">
    <div class="col-12">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center mb-3 gap-2">
            <h4 class="mb-0">Childcategory Edit</h4>
            <a href="{{ route('childcategories.index') }}" class="btn btn-primary">Manage</a>
        </div>

        <div class="card">
            <div class="card-body">
                <form action="{{ route('childcategories.update') }}" method="POST" class="row g-3" data-parsley-validate="" enctype="multipart/form-data">
                    @csrf
                    <input type="hidden" value="{{ $edit_data->id }}" name="id">

                    <div class="col-12">
                        <label for="subcategory_id" class="form-label">Sub Category *</label>
                        <select class="form-control @error('subcategory_id') is-invalid @enderror" id="subcategory_id" name="subcategory_id" required>
                            <option value="">Choose..</option>
                            @foreach ($menucategories as $category)
                                <option value="" disabled>== == == {{ $category->name }} == == ==</option>
                                @foreach ($category->subcategories as $subcat)
                                    <option value="{{ $subcat->id }}" {{ ((int) $subcat->id === (int) $edit_data->subcategory_id) ? 'selected' : '' }}>{{ $subcat->subcategoryName }}</option>
                                @endforeach
                            @endforeach
                        </select>
                        @error('subcategory_id')
                            <span class="invalid-feedback" role="alert"><strong>{{ $message }}</strong></span>
                        @enderror
                    </div>

                    <div class="col-12">
                        <label for="childcategoryName" class="form-label">Childcategory Name *</label>
                        <input type="text" class="form-control @error('childcategoryName') is-invalid @enderror" name="childcategoryName" value="{{ $edit_data->childcategoryName }}" id="childcategoryName" required>
                        @error('childcategoryName')
                            <span class="invalid-feedback" role="alert"><strong>{{ $message }}</strong></span>
                        @enderror
                    </div>

                    @include('frontend.layouts.partials.seo-fields')

                    <div class="col-12 col-md-6">
                        <label class="form-label d-block">Status</label>
                        <label class="switch">
                            <input type="checkbox" value="1" name="status" {{ ((int) $edit_data->status === 1) ? 'checked' : '' }}>
                            <span class="switch-toggle-slider">
                                <span class="switch-on"></span>
                                <span class="switch-off"></span>
                            </span>
                        </label>
                        @error('status')
                            <span class="invalid-feedback" role="alert"><strong>{{ $message }}</strong></span>
                        @enderror
                    </div>

                    <div class="col-12">
                        <button type="submit" class="btn btn-success">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection