@extends('backEnd.layouts.app')
@section('title','Landing Page Manage')

@section('css')
<link href="{{asset('/public/backEnd/')}}/assets/libs/datatables.net-bs5/css/dataTables.bootstrap5.min.css" rel="stylesheet" type="text/css" />
<link href="{{asset('/public/backEnd/')}}/assets/libs/datatables.net-responsive-bs5/css/responsive.bootstrap5.min.css" rel="stylesheet" type="text/css" />
<link href="{{asset('/public/backEnd/')}}/assets/libs/datatables.net-buttons-bs5/css/buttons.bootstrap5.min.css" rel="stylesheet" type="text/css" />
<link href="{{asset('/public/backEnd/')}}/assets/libs/datatables.net-select-bs5/css/select.bootstrap5.min.css" rel="stylesheet" type="text/css" />
@endsection

@section('content')
<div class="container-xxl flex-grow-1 container-p-y">
    <div class="row">
        <div class="col-12">
            <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center mb-3 gap-2">
                <h4 class="mb-0">Landing Page Manage</h4>
                <a href="{{ route('campaign.create') }}" class="btn btn-primary">Create</a>
            </div>

            <div class="card">
                <div class="card-body">
                    <div class="card-datatable table-responsive mt-3">
                        <table id="datatable-buttons" class="table table-striped w-100 align-middle">
                            <thead>
                                <tr>
                                    <th style="width:90px;">SL</th>
                                    <th>Landing Page Title</th>
                                    <th style="width:120px;">Status</th>
                                    <th style="width:180px;" class="text-end">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($show_data as $key=>$value)
                                    <tr>
                                        <td>{{ $loop->iteration }}</td>
                                        <td>{{ $value->name }}</td>
                                        <td>
                                            @if($value->status==1)
                                                <span class="badge bg-success">Active</span>
                                            @else
                                                <span class="badge bg-danger">Inactive</span>
                                            @endif
                                        </td>
                                        <td class="text-end">
                                            <div class="d-inline-flex align-items-center gap-2">
                                                <a href="{{ url('campaign',$value->slug) }}" class="btn btn-icon btn-text-secondary btn-sm" target="_blank" title="View" data-bs-toggle="tooltip" data-bs-title="View">
                                                    <i class="icon-base ri ri-eye-line icon-22px"></i>
                                                </a>

                                                @if($value->status == 1)
                                                    <form method="post" action="{{ route('campaign.inactive') }}" class="d-inline">
                                                        @csrf
                                                        <input type="hidden" value="{{ $value->id }}" name="hidden_id">
                                                        <button type="button" class="btn btn-icon btn-text-secondary btn-sm change-confirm" title="Make Inactive" data-bs-toggle="tooltip" data-bs-title="Make Inactive">
                                                            <i class="icon-base ri ri-thumb-down-line icon-22px"></i>
                                                        </button>
                                                    </form>
                                                @else
                                                    <form method="post" action="{{ route('campaign.active') }}" class="d-inline">
                                                        @csrf
                                                        <input type="hidden" value="{{ $value->id }}" name="hidden_id">
                                                        <button type="button" class="btn btn-icon btn-text-secondary btn-sm change-confirm" title="Make Active" data-bs-toggle="tooltip" data-bs-title="Make Active">
                                                            <i class="icon-base ri ri-thumb-up-line icon-22px"></i>
                                                        </button>
                                                    </form>
                                                @endif

                                                <a href="{{ route('campaign.edit',$value->id) }}" class="btn btn-icon btn-text-secondary btn-sm" title="Edit" data-bs-toggle="tooltip" data-bs-title="Edit">
                                                    <i class="icon-base ri ri-edit-box-line icon-22px"></i>
                                                </a>

                                                <form method="post" action="{{ route('campaign.destroy') }}" class="d-inline">
                                                    @csrf
                                                    <input type="hidden" value="{{ $value->id }}" name="hidden_id">
                                                    <button type="submit" class="btn btn-icon btn-text-secondary btn-sm delete-confirm" title="Delete" data-bs-toggle="tooltip" data-bs-title="Delete">
                                                        <i class="icon-base ri ri-delete-bin-7-line icon-22px"></i>
                                                    </button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div> <!-- end card body-->
            </div> <!-- end card -->
        </div><!-- end col-->
    </div>
</div>
@endsection


@section('script')
<!-- third party js -->
<script src="{{asset('/public/backEnd/')}}/assets/libs/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="{{asset('/public/backEnd/')}}/assets/libs/datatables.net-bs5/js/dataTables.bootstrap5.min.js"></script>
<script src="{{asset('/public/backEnd/')}}/assets/libs/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
<script src="{{asset('/public/backEnd/')}}/assets/libs/datatables.net-responsive-bs5/js/responsive.bootstrap5.min.js"></script>
<script src="{{asset('/public/backEnd/')}}/assets/libs/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
<script src="{{asset('/public/backEnd/')}}/assets/libs/datatables.net-buttons-bs5/js/buttons.bootstrap5.min.js"></script>
<script src="{{asset('/public/backEnd/')}}/assets/libs/datatables.net-buttons/js/buttons.html5.min.js"></script>
<script src="{{asset('/public/backEnd/')}}/assets/libs/datatables.net-buttons/js/buttons.flash.min.js"></script>
<script src="{{asset('/public/backEnd/')}}/assets/libs/datatables.net-buttons/js/buttons.print.min.js"></script>
<script src="{{asset('/public/backEnd/')}}/assets/libs/datatables.net-keytable/js/dataTables.keyTable.min.js"></script>
<script src="{{asset('/public/backEnd/')}}/assets/libs/datatables.net-select/js/dataTables.select.min.js"></script>
<script src="{{asset('/public/backEnd/')}}/assets/libs/pdfmake/build/pdfmake.min.js"></script>
<script src="{{asset('/public/backEnd/')}}/assets/libs/pdfmake/build/vfs_fonts.js"></script>
<script src="{{asset('/public/backEnd/')}}/assets/js/pages/datatables.init.js"></script>
<!-- third party js ends -->
@endsection