@extends('backEnd.layouts.app')
@section('title','Refunds')

@section('content')
<div class="row">
  <div class="col-12">
    <div class="d-flex flex-wrap align-items-center justify-content-between gap-2 mb-3">
      <h4 class="mb-0">Refunds</h4>
      <div class="d-flex flex-wrap align-items-center gap-2">
        <a href="{{ route('admin.orders', ['slug' => 'all']) }}" class="btn btn-outline-secondary btn-sm">Orders</a>
        <a href="{{ route('admin.returns.index') }}" class="btn btn-outline-secondary btn-sm">Returns</a>
      </div>
    </div>

    <div class="card">
      <div class="card-body">
        <div class="sticky-top bg-white" style="top: 0; z-index: 9;">
          <div class="py-2">
            <div class="alert alert-info mb-0">Approved returns list. Mark refunded after verifying payment.</div>
          </div>
          <hr class="my-0">
        </div>

        <div class="card-datatable table-responsive">
          <table class="table table-striped w-100 align-middle">
              <thead>
                <tr>
                  <th>Order</th>
                  <th>Invoice</th>
                  <th>Customer</th>
                  <th class="text-end">Refund Amount</th>
                  <th>Status</th>
                  <th class="text-end">Action</th>
                </tr>
              </thead>
              <tbody>
                @forelse($rows as $r)
                  @php
                    $o = $orders[$r->order_id] ?? null;
                  @endphp
                  <tr>
                    <td>#{{ $r->order_id }}</td>
                    <td>{{ optional($o)->invoice_id }}</td>
                    <td>{{ optional(optional($o)->customer)->name }}</td>
                    <td class="text-end">{{ $r->refund_amount }}</td>
                    <td>
                      <span class="badge text-bg-secondary">{{ $r->status }}</span>
                      @if($r->refunded)
                        <span class="badge text-bg-success">Refunded</span>
                      @endif
                    </td>
                    <td class="text-end">
                      @if(!$r->refunded)
                        <form method="POST" action="{{ route('admin.refunds.mark', $r->order_id) }}" class="d-inline">
                          @csrf
                          <input type="hidden" name="refund_amount" value="{{ $r->refund_amount }}" />
                          <button type="submit" class="btn btn-sm btn-primary">Mark Refunded</button>
                        </form>
                      @else
                        <button class="btn btn-sm btn-outline-secondary" disabled>Done</button>
                      @endif
                    </td>
                  </tr>
                @empty
                  <tr>
                    <td colspan="6" class="text-center text-muted">No approved returns found</td>
                  </tr>
                @endforelse
              </tbody>
          </table>
        </div>

        <div class="custom-paginate">
          {{ $rows->links('pagination::bootstrap-4') }}
        </div>
      </div>
    </div>
  </div>
</div>
@endsection
