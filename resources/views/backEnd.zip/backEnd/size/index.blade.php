@extends('backEnd.layouts.murubbi')
@section('title','Size Manage')

@section('content')
<!-- Page Header -->
<div class="d-flex justify-content-between align-items-center mb-6">
  <div>
    <h4 class="fw-bold mb-1">Size Manage</h4>
    <p class="text-muted mb-0">Manage product sizes</p>
  </div>
  <a href="{{route('sizes.create')}}" class="btn btn-primary waves-effect">
    <i class="icon-base ri ri-add-line me-2"></i>Create Size
  </a>
</div>

<div class="card">
            <div class="card-body">
                <div class="table-responsive">
                <table id="datatable-buttons" class="table table-hover">
                    <thead>
                        <tr>
                            <th>SL</th>
                            <th>Size Name</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                
                
                    <tbody>
                        @foreach($show_data as $key=>$value)
                        <tr>
                            <td>{{$loop->iteration}}</td>
                            <td>{{$value->sizeName}}</td>
                            <td>@if($value->status==1)<span class="badge bg-label-success rounded-pill">Active</span> @else <span class="badge bg-label-danger rounded-pill">Inactive</span> @endif</td>
                            <td>
                                <div class="d-flex gap-1">
                                    @if($value->status == 1)
                                    <form method="post" action="{{route('sizes.inactive')}}" class="d-inline"> 
                                    @csrf
                                    <input type="hidden" value="{{$value->id}}" name="hidden_id">       
                                    <button type="button" class="btn btn-sm btn-icon btn-text-warning waves-effect waves-light change-confirm"><i class="icon-base ri ri-thumb-down-line"></i></button></form>
                                    @else
                                    <form method="post" action="{{route('sizes.active')}}" class="d-inline">
                                        @csrf
                                    <input type="hidden" value="{{$value->id}}" name="hidden_id">        
                                    <button type="button" class="btn btn-sm btn-icon btn-text-success waves-effect waves-light change-confirm"><i class="icon-base ri ri-thumb-up-line"></i></button></form>
                                    @endif

                                    <a href="{{route('sizes.edit',$value->id)}}" class="btn btn-sm btn-icon btn-text-primary waves-effect waves-light"><i class="icon-base ri ri-edit-line"></i></a>

                                    <form method="post" action="{{route('sizes.destroy')}}" class="d-inline">        
                                        @csrf
                                    <input type="hidden" value="{{$value->id}}" name="hidden_id">
                                    <button type="submit" class="btn btn-sm btn-icon btn-text-danger waves-effect waves-light delete-confirm"><i class="icon-base ri ri-delete-bin-line"></i></button></form>
                                </div>
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection