@extends('backEnd.layouts.app')
@section('title','Promo Banner Manage')
@section('content')
<div class="row">
    <div class="col-12">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center mb-3 gap-2">
            <h4 class="mb-0">Promo Banner Manage</h4>
            <a href="{{ route('promo_banners.create') }}" class="btn btn-primary">Create</a>
        </div>

        <div class="card">
            <div class="card-body">
                <div class="card-datatable table-responsive mt-3">
                    <table class="table table-striped w-100 align-middle">
                        <thead>
                            <tr>
                                <th style="width:5%">SL</th>
                                <th style="width:18%">Image</th>
                                <th style="width:20%">Title</th>
                                <th style="width:25%">Link</th>
                                <th style="width:8%">Sort</th>
                                <th style="width:10%">Status</th>
                                <th style="width:12%" class="text-end">Action</th>
                            </tr>
                        </thead>

                        <tbody>
                            @foreach($data as $value)
                            <tr>
                                <td>{{ $loop->iteration }}</td>
                                <td>
                                    @php
                                        $imgPath = preg_replace('~^public/~', '', (string) ($value->image ?? ''));
                                        $imgPath = ltrim($imgPath, '/');
                                    @endphp
                                    @if($imgPath)
                                        <img src="{{ asset($imgPath) }}" class="backend-image" alt="" onerror="this.style.display='none'">
                                    @endif
                                </td>
                                <td>{{ $value->title }}</td>
                                <td>{{ $value->link }}</td>
                                <td>{{ $value->sort_order }}</td>
                                <td>
                                    @if((int) $value->status === 1)
                                        <form method="post" action="{{ route('promo_banners.inactive') }}" class="d-inline">
                                            @csrf
                                            <input type="hidden" value="{{ $value->id }}" name="hidden_id">
                                            <label class="switch" title="Active">
                                                <input type="checkbox" class="switch-input js-auto-submit" checked>
                                                <span class="switch-toggle-slider">
                                                    <span class="switch-on"></span>
                                                    <span class="switch-off"></span>
                                                </span>
                                            </label>
                                        </form>
                                    @else
                                        <form method="post" action="{{ route('promo_banners.active') }}" class="d-inline">
                                            @csrf
                                            <input type="hidden" value="{{ $value->id }}" name="hidden_id">
                                            <label class="switch" title="Inactive">
                                                <input type="checkbox" class="switch-input js-auto-submit">
                                                <span class="switch-toggle-slider">
                                                    <span class="switch-on"></span>
                                                    <span class="switch-off"></span>
                                                </span>
                                            </label>
                                        </form>
                                    @endif
                                </td>
                                <td class="text-end">
                                    <div class="d-inline-flex align-items-center gap-2">
                                        <a href="{{ route('promo_banners.edit', $value->id) }}" class="btn btn-icon btn-text-secondary btn-sm" title="Edit" data-bs-toggle="tooltip" data-bs-title="Edit">
                                            <i class="icon-base ri ri-edit-box-line icon-22px"></i>
                                        </a>
                                        <form method="post" action="{{ route('promo_banners.destroy') }}" class="d-inline">
                                            @csrf
                                            <input type="hidden" value="{{ $value->id }}" name="hidden_id">
                                            <button type="submit" class="btn btn-icon btn-text-secondary btn-sm delete-confirm" title="Delete" data-bs-toggle="tooltip" data-bs-title="Delete">
                                                <i class="icon-base ri ri-delete-bin-7-line icon-22px"></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
