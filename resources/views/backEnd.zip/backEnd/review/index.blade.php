@extends('backEnd.layouts.app')
@section('title','All Review')
@section('content')
<div class="row">
    <div class="col-12">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center mb-3 gap-2">
            <h4 class="mb-0">All Review</h4>
            <a href="{{route('reviews.create')}}" class="btn btn-primary">Create</a>
        </div>

        <div class="card">
            <div class="card-body">
                <div class="card-datatable table-responsive">
                    <table id="datatable-buttons" class="table table-striped w-100 align-middle">
                        <thead>
                            <tr>
                                <th style="width:40px;">
                                    <div class="form-check m-0">
                                        <input type="checkbox" class="form-check-input checkall" value="">
                                    </div>
                                </th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Review</th>
                                <th>Ratting</th>
                                <th class="text-end">Action</th>
                            </tr>
                        </thead>
                            <tbody>
                                @foreach($show_data as $key=>$value)
                                <tr>
                                    <td>
                                        <div class="form-check m-0">
                                            <input type="checkbox" class="form-check-input checkbox" value="{{ $value->id }}">
                                        </div>
                                    </td>
                                    <td>{{$value->name}}</td>
                                    <td>{{$value->email}}</td>
                                    <td>{{Str::limit($value->review,50)}}</td>
                                    <td>
                                        @php($rating = (int) ($value->ratting ?? 0))
                                        <span class="d-inline-flex align-items-center gap-1" aria-label="Rating: {{ $rating }}">
                                            @for ($i = 1; $i <= 5; $i++)
                                                @if ($i <= $rating)
                                                    <i class="icon-base ri ri-star-fill text-warning"></i>
                                                @else
                                                    <i class="icon-base ri ri-star-line text-muted"></i>
                                                @endif
                                            @endfor
                                            <span class="text-muted ms-1">({{ $rating }})</span>
                                        </span>
                                    </td>
                                    <td class="text-end">
                                        <div class="d-inline-flex align-items-center gap-2">
                                            @if($value->status == 'active')
                                            <form method="post" action="{{route('reviews.inactive')}}" class="d-inline"> 
                                                @csrf
                                                <input type="hidden" value="{{$value->id}}" name="hidden_id">       
                                                <button type="button" class="btn btn-icon btn-text-secondary btn-sm change-confirm" title="Mark Pending" data-bs-toggle="tooltip" data-bs-title="Mark Pending">
                                                    <i class="icon-base ri ri-thumb-down-line icon-22px"></i>
                                                </button>
                                            </form>
                                            @else
                                            <form method="post" action="{{route('reviews.active')}}" class="d-inline">
                                                @csrf
                                                <input type="hidden" value="{{$value->id}}" name="hidden_id">        
                                                <button type="button" class="btn btn-icon btn-text-secondary btn-sm change-confirm" title="Mark Active" data-bs-toggle="tooltip" data-bs-title="Mark Active">
                                                    <i class="icon-base ri ri-thumb-up-line icon-22px"></i>
                                                </button>
                                            </form>
                                            @endif

                                            <a href="{{route('reviews.edit',$value->id)}}" class="btn btn-icon btn-text-secondary btn-sm" title="Edit" data-bs-toggle="tooltip" data-bs-title="Edit">
                                                <i class="icon-base ri ri-edit-box-line icon-22px"></i>
                                            </a>

                                            <form method="post" action="{{route('reviews.destroy')}}" class="d-inline">        
                                                @csrf
                                                <input type="hidden" value="{{$value->id}}" name="hidden_id">
                                                <button type="submit" class="btn btn-icon btn-text-secondary btn-sm delete-confirm" title="Delete" data-bs-toggle="tooltip" data-bs-title="Delete">
                                                    <i class="icon-base ri ri-delete-bin-7-line icon-22px"></i>
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                                @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
