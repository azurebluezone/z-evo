@extends('backEnd.layouts.app')
@section('title','Banner Create')
@section('content')
<div class="row">
    <div class="col-12">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center mb-3 gap-2">
            <h4 class="mb-0">Banner Create</h4>
            <a href="{{ route('banners.index') }}" class="btn btn-primary">Manage</a>
        </div>

        <div class="card">
            <div class="card-body">
                <form action="{{ route('banners.store') }}" method="POST" class="row g-3" data-parsley-validate="" enctype="multipart/form-data">
                    @csrf

                    <div class="col-12">
                        <label for="title" class="form-label">Title *</label>
                        <input type="text" class="form-control @error('title') is-invalid @enderror" name="title" value="{{ old('title') }}" id="title" required>
                        @error('title')
                            <span class="invalid-feedback" role="alert"><strong>{{ $message }}</strong></span>
                        @enderror
                    </div>

                    <div class="col-12">
                        <label for="link" class="form-label">Link *</label>
                        <input type="text" class="form-control @error('link') is-invalid @enderror" name="link" value="{{ old('link') }}" id="link" required>
                        @error('link')
                            <span class="invalid-feedback" role="alert"><strong>{{ $message }}</strong></span>
                        @enderror
                    </div>

                    <div class="col-12 col-md-6">
                        <label for="media_type" class="form-label">Media Type</label>
                        <select class="form-control @error('media_type') is-invalid @enderror" name="media_type" id="media_type">
                            <option value="image" {{ old('media_type', 'image') === 'image' ? 'selected' : '' }}>Image</option>
                            <option value="video" {{ old('media_type', 'image') === 'video' ? 'selected' : '' }}>Video</option>
                        </select>
                        @error('media_type')
                            <span class="invalid-feedback" role="alert"><strong>{{ $message }}</strong></span>
                        @enderror
                    </div>

                    <div class="col-12" id="imageWrap">
                        <label for="image" class="form-label">Image *</label>
                        <input type="file" class="form-control js-dropify @error('image') is-invalid @enderror" name="image" id="image">
                        @error('image')
                            <span class="invalid-feedback" role="alert"><strong>{{ $message }}</strong></span>
                        @enderror
                    </div>

                    <div class="col-12" id="videoFileWrap" style="display:none;">
                        <label for="video" class="form-label">Video File</label>
                        <input type="file" class="form-control js-dropify @error('video') is-invalid @enderror" name="video" id="video" accept="video/*">
                        @error('video')
                            <span class="invalid-feedback" role="alert"><strong>{{ $message }}</strong></span>
                        @enderror
                    </div>

                    <div class="col-12 col-md-6">
                        <label class="form-label d-block">Status</label>
                        <label class="switch">
                            <input type="checkbox" class="switch-input" value="1" name="status" checked>
                            <span class="switch-toggle-slider">
                                <span class="switch-on"></span>
                                <span class="switch-off"></span>
                            </span>
                        </label>
                        @error('status')
                            <span class="invalid-feedback" role="alert"><strong>{{ $message }}</strong></span>
                        @enderror
                    </div>

                    <div class="col-12">
                        @include('frontend.layouts.partials.seo-fields')
                    </div>

                    <div class="col-12">
                        <button type="submit" class="btn btn-success">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection

@push('script')
<script>
    document.addEventListener('DOMContentLoaded', function () {
        var mediaType = document.getElementById('media_type');
        var imageWrap = document.getElementById('imageWrap');
        var videoFileWrap = document.getElementById('videoFileWrap');
        var imageInput = document.getElementById('image');
        var videoInput = document.getElementById('video');

        function syncMediaFields() {
            var isVideo = mediaType && mediaType.value === 'video';
            if (imageWrap) imageWrap.style.display = isVideo ? 'none' : '';
            if (videoFileWrap) videoFileWrap.style.display = isVideo ? '' : 'none';

            if (imageInput) {
                if (isVideo) {
                    imageInput.removeAttribute('required');
                } else {
                    imageInput.setAttribute('required', 'required');
                }
            }

            if (videoInput) {
                if (isVideo) {
                    videoInput.setAttribute('required', 'required');
                } else {
                    videoInput.removeAttribute('required');
                }
            }
        }

        if (mediaType) {
            mediaType.addEventListener('change', syncMediaFields);
        }

        syncMediaFields();
    });
</script>
@endpush