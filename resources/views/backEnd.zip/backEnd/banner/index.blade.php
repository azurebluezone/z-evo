@extends('backEnd.layouts.app')
@section('title','Banner Manage')
@section('content')
<div class="row">
    <div class="col-12">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center mb-3 gap-2">
            <h4 class="mb-0">Banner Manage</h4>
            <a href="{{ route('banners.create') }}" class="btn btn-primary">Create</a>
        </div>

        <div class="card">
            <div class="card-body">
                <div class="card-datatable table-responsive mt-3">
                    <table class="table table-striped w-100 align-middle">
                        <thead>
                            <tr>
                                <th style="width:5%">SL</th>
                                <th style="width:25%">Category</th>
                                <th style="width:20%">Media</th>
                                <th style="width:10%">Status</th>
                                <th style="width:12%" class="text-end">Action</th>
                            </tr>
                        </thead>

                        <tbody>
                            @foreach($data as $value)
                            <tr>
                                <td>{{ $loop->iteration }}</td>
                                <td>{{ $value->category ? $value->category->name : '' }}</td>
                                <td>
                                    @php
                                        $mediaType = $value->media_type ?? 'image';

                                        $bannerImagePath = preg_replace('~^public/~', '', (string) ($value->image ?? ''));
                                        $bannerImagePath = ltrim($bannerImagePath, '/');

                                        $videoRaw = (string) ($value->video ?? '');
                                        $videoIsUrl = preg_match('~^https?://~i', $videoRaw) === 1;
                                        $videoPath = $videoIsUrl ? $videoRaw : ltrim(preg_replace('~^public/~', '', $videoRaw), '/');
                                        $hasVideo = !empty($videoRaw) && ($videoIsUrl || \Illuminate\Support\Facades\File::exists(public_path($videoPath)));
                                    @endphp

                                    @if($mediaType === 'video' && $hasVideo)
                                        <video muted playsinline preload="metadata" style="display:block;width:140px;height:60px;object-fit:cover;border-radius:6px;">
                                            <source src="{{ $videoIsUrl ? $videoRaw : asset($videoPath) }}" type="video/mp4">
                                        </video>
                                    @elseif(!empty($bannerImagePath))
                                        <img src="{{ asset($bannerImagePath) }}" class="backend-image" alt="">
                                    @endif
                                </td>
                                <td>
                                    @if((int) $value->status === 1)
                                        <form method="post" action="{{ route('banners.inactive') }}" class="d-inline">
                                            @csrf
                                            <input type="hidden" value="{{ $value->id }}" name="hidden_id">
                                            <label class="switch" title="Active">
                                                <input type="checkbox" class="switch-input js-auto-submit" checked>
                                                <span class="switch-toggle-slider">
                                                    <span class="switch-on"></span>
                                                    <span class="switch-off"></span>
                                                </span>
                                            </label>
                                        </form>
                                    @else
                                        <form method="post" action="{{ route('banners.active') }}" class="d-inline">
                                            @csrf
                                            <input type="hidden" value="{{ $value->id }}" name="hidden_id">
                                            <label class="switch" title="Inactive">
                                                <input type="checkbox" class="switch-input js-auto-submit">
                                                <span class="switch-toggle-slider">
                                                    <span class="switch-on"></span>
                                                    <span class="switch-off"></span>
                                                </span>
                                            </label>
                                        </form>
                                    @endif
                                </td>
                                <td class="text-end">
                                    <div class="d-inline-flex align-items-center gap-2">
                                        <a href="{{ route('banners.edit', $value->id) }}" class="btn btn-icon btn-text-secondary btn-sm" title="Edit" data-bs-toggle="tooltip" data-bs-title="Edit">
                                            <i class="icon-base ri ri-edit-box-line icon-22px"></i>
                                        </a>
                                        <form method="post" action="{{ route('banners.destroy') }}" class="d-inline">
                                            @csrf
                                            <input type="hidden" value="{{ $value->id }}" name="hidden_id">
                                            <button type="submit" class="btn btn-icon btn-text-secondary btn-sm delete-confirm" title="Delete" data-bs-toggle="tooltip" data-bs-title="Delete">
                                                <i class="icon-base ri ri-delete-bin-7-line icon-22px"></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection