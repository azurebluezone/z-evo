@extends('backEnd.layouts.app')
@section('title','Permissions Manage')

@section('content')
<div class="row">
    <div class="col-12">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center mb-3 gap-2">
            <h4 class="mb-0">Permissions Manage</h4>

            <a href="{{route('permissions.create')}}" class="btn btn-primary btn-sm">
                <i class="icon-base ri ri-add-line me-1"></i> Create
            </a>
        </div>

        <div class="card">
            <div class="card-body">
                <div class="card-datatable table-responsive">
                    <table class="table table-striped w-100 align-middle">
                        <thead>
                            <tr>
                                <th style="width:8%">SL</th>
                                <th>Name</th>
                                <th style="width:18%">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($show_data as $key=>$value)
                            <tr>
                                <td>{{$loop->iteration}}</td>
                                <td>{{$value->name}}</td>
                                <td>
                                    <div class="d-flex align-items-center gap-2">
                                        <a href="{{route('permissions.edit',$value->id)}}" class="btn btn-icon btn-text-secondary btn-sm" title="Edit" data-bs-toggle="tooltip" data-bs-title="Edit">
                                            <i class="icon-base ri ri-edit-box-line icon-22px"></i>
                                        </a>

                                        <form method="post" action="{{route('permissions.destroy')}}" class="d-inline">
                                            @csrf
                                            <input type="hidden" value="{{$value->id}}" name="hidden_id">
                                            <button type="submit" title="Delete" class="btn btn-icon btn-text-secondary btn-sm delete-confirm" data-bs-toggle="tooltip" data-bs-title="Delete">
                                                <i class="icon-base ri ri-delete-bin-7-line icon-22px"></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div> <!-- end card body-->
        </div> <!-- end card -->
    </div><!-- end col-->
</div>
@endsection