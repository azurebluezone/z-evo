@extends('backEnd.layouts.app')
@section('title','Customer Manage')

@section('content')
<div class="row">
    <div class="col-12">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center mb-3 gap-2">
            <h4 class="mb-0">Customer Manage</h4>

            <form class="d-flex align-items-center gap-2" method="get" action="{{ route('customers.index') }}">
                <input type="text" name="keyword" class="form-control form-control-sm" placeholder="Search phone/name" value="{{ request('keyword') }}" style="min-width: 220px;">
                <button class="btn btn-info btn-sm" type="submit">Search</button>
            </form>
        </div>

        <div class="card">
            <div class="card-body">
                <div class="card-datatable table-responsive">
                    <table class="table table-striped w-100 align-middle">
                    <thead>
                        <tr>
                            <th style="width:5%">SL</th>
                            <th style="width:20%" class="text-nowrap">Name</th>
                            <th style="width:15%" class="text-nowrap">Phone</th>
                            <th style="width:20%" class="text-nowrap">Email</th>
                            <th style="width:10%" class="text-nowrap">Status</th>
                            <th style="width:15%" class="text-nowrap">Action</th>
                        </tr>
                    </thead>
                
                    <tbody>
                        @foreach($show_data as $key=>$value)
                        <tr>
                            <td>{{$loop->iteration}}</td>
                            <td>{{$value->name}}</td>
                            <td>{{$value->phone}}</td>
                            <td>{{$value->email}}</td>
                            <td>@if($value->status=='active')<span class="badge bg-soft-success text-success">Active</span> @else <span class="badge bg-soft-danger text-danger">{{$value->status}}</span> @endif</td>
                            <td>
                                <div class="d-flex align-items-center gap-2">
                                    @if($value->status == 'active')
                                    <form method="post" action="{{route('customers.inactive')}}" class="d-inline"> 
                                    @csrf
                                    <input type="hidden" value="{{$value->id}}" name="hidden_id">       
                                    <label class="switch" title="Active">
                                        <input type="checkbox" class="switch-input js-auto-submit" checked>
                                        <span class="switch-toggle-slider">
                                            <span class="switch-on"></span>
                                            <span class="switch-off"></span>
                                        </span>
                                    </label>
                                    </form>
                                    @else
                                    <form method="post" action="{{route('customers.active')}}" class="d-inline">
                                        @csrf
                                    <input type="hidden" value="{{$value->id}}" name="hidden_id">        
                                    <label class="switch" title="Inactive">
                                        <input type="checkbox" class="switch-input js-auto-submit">
                                        <span class="switch-toggle-slider">
                                            <span class="switch-on"></span>
                                            <span class="switch-off"></span>
                                        </span>
                                    </label>
                                    </form>
                                    @endif

                                    <a href="{{route('customers.edit',$value->id)}}" class="btn btn-icon btn-text-secondary btn-sm" title="Edit" data-bs-toggle="tooltip" data-bs-title="Edit">
                                        <i class="icon-base ri ri-edit-box-line icon-22px"></i>
                                    </a>

                                    <a href="{{route('customers.profile',['id'=>$value->id])}}" class="btn btn-icon btn-text-secondary btn-sm" title="View" data-bs-toggle="tooltip" data-bs-title="View">
                                        <i class="icon-base ri ri-eye-line icon-22px"></i>
                                    </a>

                                    <form method="post" action="{{route('customers.adminlog')}}" class="d-inline" target="_blank">
                                        @csrf
                                    <input type="hidden" value="{{$value->id}}" name="hidden_id">  
                                    <button type="submit" class="btn btn-xs btn-pink waves-effect waves-light" title="Login as customer"><i class="fe-log-in"></i></button></form>
                                </div>
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
                </div>
                <div class="custom-paginate">
                    {{$show_data->links('pagination::bootstrap-4')}}
                </div>
            </div> <!-- end card body-->
        </div> <!-- end card -->
    </div><!-- end col-->
   </div>
</div>
@endsection