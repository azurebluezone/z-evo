@extends('backEnd.layouts.app') 
@section('title','Courier API')
@section('css')
<style>
  .increment_btn,
  .remove_btn {
    margin-top: -17px;
    margin-bottom: 10px;
  }
</style>
<link href="{{asset('backEnd')}}/assets/libs/select2/css/select2.min.css" rel="stylesheet" type="text/css" />
<link href="{{asset('backEnd')}}/assets/libs/summernote/summernote-lite.min.css" rel="stylesheet" type="text/css" />
@endsection @section('content')

<div class="row">
  <div class="col-12">
    <div class="card mb-4">
      <div class="card-body">
        <div class="d-flex align-items-center justify-content-between mb-3">
          <h4 class="mb-0">Steadfast Courier</h4>
        </div>

        <form action="{{route('courierapi.update')}}" method="POST" enctype="multipart/form-data">
          @csrf
          <input type="hidden" name="id" value="{{$steadfast->id}}">

          <div class="row">
            <div class="col-12 col-lg-6 mb-3">
              <label for="api_key" class="form-label">API key *</label>
              <input type="text" class="form-control @error('api_key') is-invalid @enderror" name="api_key" value="{{ $steadfast->api_key}}" id="api_key" required="" />
              @error('api_key')
              <span class="invalid-feedback" role="alert">
                <strong>{{ $message }}</strong>
              </span>
              @enderror
            </div>

            <div class="col-12 col-lg-6 mb-3">
              <label for="secret_key" class="form-label">Secret key *</label>
              <input type="text" class="form-control @error('secret_key') is-invalid @enderror" name="secret_key" value="{{ $steadfast->secret_key }}" id="secret_key" required="" />
              @error('secret_key')
              <span class="invalid-feedback" role="alert">
                <strong>{{ $message }}</strong>
              </span>
              @enderror
            </div>

            <div class="col-12 col-lg-8 mb-3">
              <label for="url_steadfast" class="form-label">URL *</label>
              <input type="text" class="form-control @error('url') is-invalid @enderror" name="url" value="{{ $steadfast->url }}" id="url_steadfast" placeholder="Enter base URL (Example: https://portal.packzy.com/api/v1)" required="" />
              <small class="text-muted"> <strong></strong> </small>
              @error('url')
              <span class="invalid-feedback" role="alert">
                <strong>{{ $message }}</strong>
              </span>
              @enderror
            </div>

            <div class="col-12 col-lg-4 mb-3">
              <label for="status" class="d-block">Status</label>
              <label class="switch switch-square">
                <input type="checkbox" class="switch-input" value="1" @if($steadfast->status==1)checked @endif name="status" />
                <span class="switch-toggle-slider">
                  <span class="switch-on"></span>
                  <span class="switch-off"></span>
                </span>
                <span class="switch-label">Enabled</span>
              </label>
              @error('status')
              <span class="invalid-feedback" role="alert">
                <strong>{{ $message }}</strong>
              </span>
              @enderror
            </div>
          </div>

          <div class="mt-2 d-flex gap-2">
            <button type="submit" class="btn btn-primary">Save</button>
            <button type="button" class="btn btn-outline-info" id="testSteadfastBtn">
              <i class="ri-test-tube-line me-1"></i>Test Connection
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<div class="row">
  <div class="col-12">
    <div class="card mb-4">
      <div class="card-body">
        <div class="d-flex align-items-center justify-content-between mb-3">
          <h4 class="mb-0">Pathao Courier</h4>
        </div>

        <form action="{{route('courierapi.update')}}" method="POST" enctype="multipart/form-data">
          @csrf
          <input type="hidden" name="id" value="{{ $pathao->id}}">

          <div class="row">
            <div class="col-12 col-lg-8 mb-3">
              <label for="url_pathao" class="form-label">URL *</label>
              <input type="text" class="form-control @error('url') is-invalid @enderror" name="url" value="{{ $pathao->url}}" id="url_pathao" placeholder="Enter base URL (Sandbox: https://courier-api-sandbox.pathao.com | Live: https://api-hermes.pathao.com)" required="" />
              <small class="text-muted"> <strong></strong> </small>
              @error('url')
              <span class="invalid-feedback" role="alert">
                <strong>{{ $message }}</strong>
              </span>
              @enderror
            </div>

            <div class="col-12 col-lg-4 mb-3">
              <label for="status" class="d-block">Status</label>
              <label class="switch switch-square">
                <input type="checkbox" class="switch-input" value="1" @if($pathao->status==1)checked @endif name="status" />
                <span class="switch-toggle-slider">
                  <span class="switch-on"></span>
                  <span class="switch-off"></span>
                </span>
                <span class="switch-label">Enabled</span>
              </label>
              @error('status')
              <span class="invalid-feedback" role="alert">
                <strong>{{ $message }}</strong>
              </span>
              @enderror
            </div>

            <div class="col-12 col-lg-6 mb-3">
              <label for="pathao_client_id" class="form-label">Client ID</label>
              <input type="text" class="form-control" name="client_id" value="{{ $pathao->client_id ?? '' }}" id="pathao_client_id" placeholder="Example: 7N1aMJQbWm" />
            </div>

            <div class="col-12 col-lg-6 mb-3">
              <label for="pathao_client_secret" class="form-label">Client Secret</label>
              <input type="text" class="form-control" name="client_secret" value="{{ $pathao->client_secret ?? '' }}" id="pathao_client_secret" placeholder="Example: wRcaibZkUdSNz2EI9ZyuXLlNrnAv0TdPUPXMnD39" />
            </div>

            <div class="col-12 col-lg-6 mb-3">
              <label for="pathao_username" class="form-label">Username</label>
              <input type="text" class="form-control" name="username" value="{{ $pathao->username ?? '' }}" id="pathao_username" placeholder="Example: test@pathao.com" />
            </div>

            <div class="col-12 col-lg-6 mb-3">
              <label for="pathao_password" class="form-label">Password</label>
              <input type="text" class="form-control" name="password" value="{{ $pathao->password ?? '' }}" id="pathao_password" placeholder="Example: lovePathao" />
              <small class="text-muted"> <strong></strong> </small>
            </div>

            <div class="col-12 col-lg-6 mb-3">
              <label for="token" class="form-label">Token</label>
              <input type="text" class="form-control @error('token') is-invalid @enderror" name="token" value="{{ $pathao->token}}" id="token" placeholder="Auto generated (or paste manually)" />
              @error('token')
              <span class="invalid-feedback" role="alert">
                <strong>{{ $message }}</strong>
              </span>
              @enderror
            </div>
          </div>

          <div class="mt-2 d-flex gap-2">
            <button type="submit" class="btn btn-primary">Save</button>
            <button type="button" class="btn btn-outline-info" id="testPathaoBtn">
              <i class="ri-test-tube-line me-1"></i>Test Connection
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<div class="row">
  <div class="col-12">
    <div class="card mb-4">
      <div class="card-body">
        <div class="d-flex align-items-center justify-content-between mb-3">
          <h4 class="mb-0">Sync Orders</h4>
        </div>

        <form>
          <div class="row">
            <div class="col-12 col-lg-6 mb-3">
              <label for="syncLimit" class="form-label">Sync Limit</label>
              <input type="number" class="form-control" name="syncLimit" id="syncLimit" value="100" />
            </div>
          </div>

          <div class="mt-2">
            <button type="button" id="syncOrdersBtn" class="btn btn-primary">Sync Orders</button>
          </div>
        </form>

        <div id="syncResults"></div>
      </div>
    </div>
  </div>
</div>

@endsection @section('script')
<script src="{{asset('backEnd/')}}/assets/libs/parsleyjs/parsley.min.js"></script>
<script src="{{asset('backEnd/')}}/assets/js/pages/form-validation.init.js"></script>
<script src="{{asset('backEnd/')}}/assets/libs/select2/js/select2.min.js"></script>
<script src="{{asset('backEnd/')}}/assets/js/pages/form-advanced.init.js"></script>
<!-- Plugins js -->
<script src="{{asset('backEnd/')}}/assets/libs//summernote/summernote-lite.min.js"></script>
<script>
  $(document).ready(function () {
    // Test SteadFast Connection
    $('#testSteadfastBtn').on('click', function(e) {
      e.preventDefault();
      var $btn = $(this);
      var apiKey = $('#api_key').val();
      var secretKey = $('#secret_key').val();
      var url = $('#url_steadfast').val();
      
      if (!apiKey || !secretKey) {
        toastr.error('Please enter API Key and Secret Key');
        return;
      }
      
      $btn.prop('disabled', true).html('<i class="ri-loader-4-line spin me-1"></i>Testing...');
      
      $.ajax({
        url: '{{ route("admin.courier.test.steadfast") }}',
        method: 'POST',
        data: {
          _token: '{{ csrf_token() }}',
          api_key: apiKey,
          secret_key: secretKey,
          url: url
        },
        success: function(res) {
          if (res.success) {
            toastr.success(res.message + (res.balance ? ' (Balance: ৳' + res.balance + ')' : ''));
          } else {
            toastr.error(res.message);
          }
        },
        error: function() {
          toastr.error('Connection test failed');
        },
        complete: function() {
          $btn.prop('disabled', false).html('<i class="ri-test-tube-line me-1"></i>Test Connection');
        }
      });
    });

    // Test Pathao Connection
    $('#testPathaoBtn').on('click', function(e) {
      e.preventDefault();
      var $btn = $(this);
      var clientId = $('#pathao_client_id').val();
      var clientSecret = $('#pathao_client_secret').val();
      var username = $('#pathao_username').val();
      var password = $('#pathao_password').val();
      var url = $('#url_pathao').val();
      
      if (!clientId || !clientSecret || !username || !password) {
        toastr.error('Please enter all Pathao credentials');
        return;
      }
      
      $btn.prop('disabled', true).html('<i class="ri-loader-4-line spin me-1"></i>Testing...');
      
      $.ajax({
        url: '{{ route("admin.courier.test.pathao") }}',
        method: 'POST',
        data: {
          _token: '{{ csrf_token() }}',
          client_id: clientId,
          client_secret: clientSecret,
          username: username,
          password: password,
          url: url
        },
        success: function(res) {
          if (res.success) {
            toastr.success(res.message + (res.token_received ? ' (Token received)' : ''));
            if (res.token) {
              $('#token').val(res.token);
            }
          } else {
            toastr.error(res.message);
          }
        },
        error: function() {
          toastr.error('Connection test failed');
        },
        complete: function() {
          $btn.prop('disabled', false).html('<i class="ri-test-tube-line me-1"></i>Test Connection');
        }
      });
    });

    // Sync Orders with Courier
    $('#syncOrdersBtn').on('click', function() {
      var $btn = $(this);
      var limit = $('#syncLimit').val();
      
      $btn.prop('disabled', true).html('<i class="ri-loader-4-line spin me-1"></i>Syncing...');
      
      $.ajax({
        url: '{{ route("admin.courier.sync.orders") }}',
        method: 'POST',
        data: {
          _token: '{{ csrf_token() }}',
          limit: limit
        },
        success: function(res) {
          if (res.status === 'completed') {
            toastr.success('Synced ' + res.processed + ' orders successfully');
            if (res.results && res.results.length > 0) {
              var html = '<div class="table-responsive mt-3"><table class="table table-sm table-striped"><thead><tr><th>Order</th><th>Phone</th><th>Risk</th><th>Score</th></tr></thead><tbody>';
              res.results.forEach(function(item) {
                var badgeClass = item.risk_label === 'high_risk' ? 'bg-danger' : item.risk_label === 'risky' ? 'bg-warning' : 'bg-success';
                html += '<tr><td>' + item.invoice_id + '</td><td>' + item.phone + '</td><td><span class="badge ' + badgeClass + '">' + item.risk_label + '</span></td><td>' + (item.success_rate || 'N/A') + '%</td></tr>';
              });
              html += '</tbody></table></div>';
              $('#syncResults').html(html);
            }
          } else {
            toastr.error('Sync failed');
          }
        },
        error: function() {
          toastr.error('Sync failed');
        },
        complete: function() {
          $btn.prop('disabled', false).html('<i class="ri-refresh-line me-1"></i>Sync Orders');
        }
      });
    });
  });
</script>
@endsection