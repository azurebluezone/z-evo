@extends('backEnd.layouts.app')
@section('title','Flash Sale Create')
@section('content')
<div class="row">
    <div class="col-12">
        <div class="d-flex flex-wrap align-items-center justify-content-between gap-2 mb-3">
            <h4 class="mb-0">Flash Sale Create</h4>
            <a href="{{ route('flash-sales.index') }}" class="btn btn-outline-secondary">Manage</a>
        </div>

        <div class="card">
            <div class="card-body">
                <form action="{{ route('flash-sales.store') }}" method="post" enctype="multipart/form-data" class="row g-3">
                    @csrf

                    <div class="col-md-6">
                        <label class="form-label">Title *</label>
                        <input type="text" name="title" value="{{ old('title') }}" class="form-control @error('title') is-invalid @enderror" required>
                        @error('title')<div class="invalid-feedback">{{ $message }}</div>@enderror
                    </div>

                    <div class="col-md-6">
                        <label class="form-label">Banner Link</label>
                        <input type="text" name="banner_link" value="{{ old('banner_link') }}" class="form-control @error('banner_link') is-invalid @enderror" placeholder="https://...">
                        @error('banner_link')<div class="invalid-feedback">{{ $message }}</div>@enderror
                    </div>

                    <div class="col-md-6">
                        <label class="form-label">Start Time</label>
                        <input type="datetime-local" name="start_time" value="{{ old('start_time') }}" class="form-control @error('start_time') is-invalid @enderror">
                        @error('start_time')<div class="invalid-feedback">{{ $message }}</div>@enderror
                    </div>

                    <div class="col-md-6">
                        <label class="form-label">End Time</label>
                        <input type="datetime-local" name="end_time" value="{{ old('end_time') }}" class="form-control @error('end_time') is-invalid @enderror">
                        @error('end_time')<div class="invalid-feedback">{{ $message }}</div>@enderror
                    </div>

                    <div class="col-md-6">
                        <label class="form-label">Banner Image</label>
                        <input type="file" name="banner_image" class="form-control @error('banner_image') is-invalid @enderror">
                        @error('banner_image')<div class="invalid-feedback">{{ $message }}</div>@enderror
                    </div>

                    <div class="col-md-6">
                        <label class="form-label d-block">Status</label>
                        <label class="switch switch-square">
                            <input type="checkbox" class="switch-input" name="status" value="1" checked>
                            <span class="switch-toggle-slider">
                                <span class="switch-on"><i class="icon-base ri ri-check-line"></i></span>
                                <span class="switch-off"><i class="icon-base ri ri-close-line"></i></span>
                            </span>
                        </label>
                    </div>

                    <div class="col-12">
                        <label class="form-label">Products</label>
                        <select name="product_ids[]" class="form-select js-select2" multiple size="6">
                            @foreach($products as $p)
                                <option value="{{ $p->id }}">{{ $p->name }}</option>
                            @endforeach
                        </select>
                        <small class="text-muted d-block mt-1">Hold Ctrl/Cmd to select multiple</small>
                        <div class="form-text">Select products in the order you want. You can edit later.</div>
                    </div>

                    <div class="col-12">
                        <button type="submit" class="btn btn-success">Submit</button>
                    </div>
                </form>
            </div>
        </div>

    </div>
</div>
@endsection
