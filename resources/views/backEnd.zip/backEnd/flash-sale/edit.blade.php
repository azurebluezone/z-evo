@extends('backEnd.layouts.app')
@section('title','Flash Sale Edit')
@section('content')
<div class="row">
    <div class="col-12">
        <div class="d-flex flex-wrap align-items-center justify-content-between gap-2 mb-3">
            <h4 class="mb-0">Flash Sale Edit</h4>
            <a href="{{ route('flash-sales.index') }}" class="btn btn-outline-secondary">Manage</a>
        </div>

        <div class="card">
            <div class="card-body">
                <form action="{{ route('flash-sales.update') }}" method="post" enctype="multipart/form-data" class="row g-3">
                    @csrf
                    <input type="hidden" name="id" value="{{ $flash_sale->id }}">

                    <div class="col-md-6">
                        <label class="form-label">Title *</label>
                        <input type="text" name="title" value="{{ old('title', $flash_sale->title) }}" class="form-control @error('title') is-invalid @enderror" required>
                        @error('title')<div class="invalid-feedback">{{ $message }}</div>@enderror
                    </div>

                    <div class="col-md-6">
                        <label class="form-label">Banner Link</label>
                        <input type="text" name="banner_link" value="{{ old('banner_link', $flash_sale->banner_link) }}" class="form-control @error('banner_link') is-invalid @enderror" placeholder="https://...">
                        @error('banner_link')<div class="invalid-feedback">{{ $message }}</div>@enderror
                    </div>

                    <div class="col-md-6">
                        <label class="form-label">Start Time</label>
                        <input type="datetime-local" name="start_time" value="{{ old('start_time', $flash_sale->start_time ? $flash_sale->start_time->format('Y-m-d\TH:i') : '') }}" class="form-control @error('start_time') is-invalid @enderror">
                        @error('start_time')<div class="invalid-feedback">{{ $message }}</div>@enderror
                    </div>

                    <div class="col-md-6">
                        <label class="form-label">End Time</label>
                        <input type="datetime-local" name="end_time" value="{{ old('end_time', $flash_sale->end_time ? $flash_sale->end_time->format('Y-m-d\TH:i') : '') }}" class="form-control @error('end_time') is-invalid @enderror">
                        @error('end_time')<div class="invalid-feedback">{{ $message }}</div>@enderror
                    </div>

                    <div class="col-md-6">
                        <label class="form-label">Banner Image</label>
                        <input type="file" name="banner_image" class="form-control @error('banner_image') is-invalid @enderror">
                        @error('banner_image')<div class="invalid-feedback">{{ $message }}</div>@enderror
                        @if(!empty($flash_sale->banner_image))
                            @php
                                $bannerPath = preg_replace('~^public/~', '', (string) ($flash_sale->banner_image ?? ''));
                                $bannerPath = ltrim($bannerPath, '/');
                            @endphp
                            @if($bannerPath)
                            <div class="mt-2">
                                <img src="{{ asset($bannerPath) }}" alt="banner" style="max-height: 80px;" onerror="this.style.display='none'">
                            </div>
                            @endif
                        @endif
                    </div>

                    <div class="col-md-6">
                        <label class="form-label d-block">Status</label>
                        <label class="switch">
                            <input type="checkbox" class="switch-input" name="status" value="1" {{ $flash_sale->status ? 'checked' : '' }}>
                            <span class="switch-toggle-slider">
                                <span class="switch-on"></span>
                                <span class="switch-off"></span>
                            </span>
                        </label>
                    </div>

                    <div class="col-12">
                        <label class="form-label">Products</label>
                        <select name="product_ids[]" class="form-select" multiple size="6">
                            @foreach($products as $p)
                                @if($p->status == 1 && !str_contains(strtolower($p->name), 'test'))
                                    <option value="{{ $p->id }}" {{ in_array($p->id, $selected_product_ids ?? []) ? 'selected' : '' }}>{{ $p->name }}</option>
                                @endif
                            @endforeach
                        </select>
                        <small class="text-muted d-block mt-1">Hold Ctrl/Cmd to select multiple</small>
                        <div class="form-text">Products are saved in the selected order.</div>
                    </div>

                    <div class="col-12">
                        <button type="submit" class="btn btn-success">Submit</button>
                    </div>
                </form>
            </div>
        </div>

    </div>
</div>
@endsection
