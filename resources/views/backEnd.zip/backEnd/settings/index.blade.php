@extends('backEnd.layouts.app')
@section('title','General Setting Manage')

@section('css')
<style>
    /* DataTable styles from admin template */
    table.dataTable {
        width: 100% !important;
        border-collapse: separate;
        border-spacing: 0;
    }
    table.dataTable thead th {
        font-weight: 600;
        text-transform: uppercase;
        font-size: 0.75rem;
        letter-spacing: 0.5px;
        border-bottom: 1px solid #e9ecef;
        padding: 0.75rem;
    }
    table.dataTable tbody td {
        padding: 0.75rem;
        vertical-align: middle;
    }
</style>
@endsection

@section('content')
<div class="container-fluid">
    
    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <div class="page-title-right">
                   
                </div>
                <h4 class="page-title">General Setting Manage</h4>
            </div>
        </div>
    </div>       
    <!-- end page title --> 
   <div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <table id="datatable-buttons" class="table table-striped dt-responsive nowrap w-100">
                    <thead>
                        <tr>
                            <th>SL</th>
                            <th>Name</th>
                            <th>White Logo</th>
                            <th>Dark Logo</th>
                            <th>Favicon</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                
                
                    <tbody>
                        @foreach($show_data as $key=>$value)
                        <tr>
                            <td>{{$loop->iteration}}</td>
                            <td>{{$value->name}}</td>
                            <td>
                                @php
                                    $whiteLogoPath = preg_replace('~^public/~', '', (string) ($value->white_logo ?? ''));
                                    $whiteLogoPath = ltrim($whiteLogoPath, '/');
                                @endphp
                                @if($whiteLogoPath)
                                    <img src="{{ asset($whiteLogoPath) }}" class="backend-image" alt="" onerror="this.style.display='none'">
                                @endif
                            </td>
                            <td>
                                @php
                                    $darkLogoPath = preg_replace('~^public/~', '', (string) ($value->dark_logo ?? ''));
                                    $darkLogoPath = ltrim($darkLogoPath, '/');
                                @endphp
                                @if($darkLogoPath)
                                    <img src="{{ asset($darkLogoPath) }}" class="backend-image" alt="" onerror="this.style.display='none'">
                                @endif
                            </td>
                            <td>
                                @php
                                    $faviconPath = preg_replace('~^public/~', '', (string) ($value->favicon ?? ''));
                                    $faviconPath = ltrim($faviconPath, '/');
                                @endphp
                                @if($faviconPath)
                                    <img src="{{ asset($faviconPath) }}" class="backend-image" alt="" onerror="this.style.display='none'">
                                @endif
                            </td>
                            <td>@if($value->status==1)<span class="badge bg-soft-success text-success">Active</span> @else <span class="badge bg-soft-danger text-danger">Inactive</span> @endif</td>
                            <td>
                                <div class="button-list">
                                    @if($value->status == 1)
                                    <form method="post" action="{{route('settings.inactive')}}" class="d-inline"> 
                                    @csrf
                                    <input type="hidden" value="{{$value->id}}" name="hidden_id">       
                                    <button type="button" class="btn btn-xs  btn-secondary waves-effect waves-light change-confirm"><i class="fe-thumbs-down"></i></button></form>
                                    @else
                                    <form method="post" action="{{route('settings.active')}}" class="d-inline">
                                        @csrf
                                    <input type="hidden" value="{{$value->id}}" name="hidden_id">        
                                    <button type="button" class="btn btn-xs  btn-success waves-effect waves-light change-confirm"><i class="fe-thumbs-up"></i></button></form>
                                    @endif

                                    <a href="{{route('settings.edit',$value->id)}}" class="btn btn-xs btn-primary waves-effect waves-light"><i class="fe-edit-1"></i></a>
                                    </div>
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
 
            </div> <!-- end card body-->
        </div> <!-- end card -->
    </div><!-- end col-->
   </div>
</div>
@endsection


@section('script')
<script>
    // Simple DataTable initialization using available admin assets
    $(document).ready(function() {
        if ($.fn.DataTable) {
            $('#datatable-buttons').DataTable({
                responsive: true,
                pageLength: 25,
                order: []
            });
        }
    });
</script>
@endsection