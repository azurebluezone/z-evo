@extends('backEnd.layouts.app')
@section('title','Website SEO')

@section('content')
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <div class="d-flex align-items-center justify-content-between mb-3">
                    <h4 class="mb-0">Website SEO</h4>
                </div>

                <form action="{{ route('admin.website-setup.seo.update') }}" method="POST" enctype="multipart/form-data">
                    @csrf

                    @php
                        $model = $settings;
                    @endphp
                    @include('frontend.layouts.partials.seo-fields')

                    <div class="mt-2">
                        <button type="submit" class="btn btn-primary">Save</button>
                    </div>
                </form>

            </div>
        </div>
    </div>
</div>
@endsection
