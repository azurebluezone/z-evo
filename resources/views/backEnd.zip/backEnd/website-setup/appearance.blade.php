@extends('backEnd.layouts.app')
@section('title','Website Appearance')

@section('content')
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <div class="d-flex align-items-center justify-content-between mb-3">
                    <h4 class="mb-0">Website Appearance</h4>
                </div>

                <form action="{{ route('admin.website-setup.appearance.update') }}" method="POST" enctype="multipart/form-data">
                    @csrf

                    <div class="row">
                        <div class="col-lg-6 mb-3">
                            <label class="form-label">Primary Color</label>
                            <input type="text" name="primary_color" class="form-control" value="{{ old('primary_color', $settings->primary_color ?? '') }}" placeholder="#f3532b">
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label class="form-label">Secondary Color</label>
                            <input type="text" name="secondary_color" class="form-control" value="{{ old('secondary_color', $settings->secondary_color ?? '') }}" placeholder="#111827">
                        </div>

                        <div class="col-lg-4 mb-3">
                            <label class="form-label">Call Button Number</label>
                            <input type="text" name="support_phone" class="form-control" value="{{ old('support_phone', $settings->support_phone ?? '') }}" placeholder="01XXXXXXXXX">
                        </div>

                        <div class="col-lg-4 mb-3">
                            <label class="form-label">Messenger Link</label>
                            <input type="text" name="messenger_link" class="form-control" value="{{ old('messenger_link', $settings->messenger_link ?? '') }}" placeholder="https://m.me/yourpage">
                        </div>

                        <div class="col-lg-4 mb-3">
                            <label class="form-label">WhatsApp Number</label>
                            <input type="text" name="whatsapp_number" class="form-control" value="{{ old('whatsapp_number', $settings->whatsapp_number ?? '') }}" placeholder="8801XXXXXXXXX">
                        </div>

                        <div class="col-lg-6 mb-3">
                            <label class="form-label">Frontend Empty/Fallback Image</label>
                            <input type="file" name="frontend_empty_image" class="form-control" accept="image/*">
                            @php
                                $fallbackImage = $settings->frontend_empty_image ?? 'assets/images/empty.png';
                                $fallbackImage = preg_replace('~^public/~', '', (string) $fallbackImage);
                                $fallbackImage = ltrim($fallbackImage, '/');
                                if (empty($fallbackImage) || !\Illuminate\Support\Facades\File::exists(public_path($fallbackImage))) {
                                    $fallbackImage = 'assets/images/empty.png';
                                }
                            @endphp
                            <div class="mt-2">
                                <img src="{{ asset($fallbackImage) }}" alt="Fallback" style="max-width: 220px; height: auto; border: 1px solid #eee; border-radius: 6px;">
                            </div>
                        </div>
                    </div>

                    <div class="mt-2">
                        <button type="submit" class="btn btn-primary">Save</button>
                    </div>
                </form>

            </div>
        </div>
    </div>
</div>
@endsection
