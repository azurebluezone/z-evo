@extends('backEnd.layouts.app')
@section('title','Create Notification Template')

@section('content')
<div class="container-xxl flex-grow-1 container-p-y">
  <div class="row">
    <div class="col-12">
      <div class="d-flex flex-wrap align-items-center justify-content-between gap-2 mb-3">
        <h4 class="mb-0">Create Template</h4>
        <a href="{{ route('admin.notification-templates.index') }}" class="btn btn-outline-secondary btn-sm">Back</a>
      </div>

      <div class="card">
        <div class="card-body">
          <form method="post" action="{{ route('admin.notification-templates.store') }}">
            @csrf

            <div class="mb-3">
              <label class="form-label">Name</label>
              <input type="text" name="name" class="form-control" value="{{ old('name') }}" required>
            </div>

            <div class="mb-3">
              <label class="form-label">Title</label>
              <input type="text" name="title" class="form-control" value="{{ old('title') }}" required>
            </div>

            <div class="mb-3">
              <label class="form-label">Body</label>
              <textarea name="body" class="form-control" rows="6" required>{{ old('body') }}</textarea>
            </div>

            <div class="form-check mb-3">
              <input class="form-check-input" type="checkbox" name="is_active" id="is_active" checked>
              <label class="form-check-label" for="is_active">Active</label>
            </div>

            <button type="submit" class="btn btn-primary">Save</button>
          </form>
        </div>
      </div>

    </div>
  </div>
</div>
@endsection
