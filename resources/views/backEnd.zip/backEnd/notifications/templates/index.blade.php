@extends('backEnd.layouts.app')
@section('title','Notification Templates')

@section('content')
<div class="row">
  <div class="col-12">
    <div class="d-flex flex-wrap align-items-center justify-content-between gap-2 mb-3">
      <h4 class="mb-0">Notification Templates</h4>
      <a href="{{ route('admin.notification-templates.create') }}" class="btn btn-primary btn-sm">
        <i class="icon-base ri ri-add-line me-1"></i> Add New
      </a>
    </div>

    <div class="card">
      <div class="card-body">
        <div class="card-datatable table-responsive">
            <table class="table table-striped table-sm w-100 align-middle">
              <thead>
                <tr>
                  <th style="width:60px" class="text-center">#</th>
                  <th style="width:22%">Name</th>
                  <th>Title</th>
                  <th style="width:90px" class="text-center">Active</th>
                  <th style="width:56px" class="text-end"></th>
                </tr>
              </thead>
              <tbody>
                @forelse($templates as $tpl)
                  <tr>
                    <td class="text-center">{{ ($templates->firstItem() ?? 0) + $loop->index }}</td>
                    <td>
                      <div class="fw-medium" style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">{{ $tpl->name }}</div>
                    </td>
                    <td>
                      <div style="overflow:hidden;display:-webkit-box;-webkit-line-clamp:1;-webkit-box-orient:vertical;">{{ $tpl->title }}</div>
                    </td>
                    <td class="text-center">
                      <form method="post" action="{{ route('admin.notification-templates.toggle', $tpl->id) }}" class="d-inline">
                        @csrf
                        <button type="submit" class="btn btn-sm {{ $tpl->is_active ? 'btn-success' : 'btn-outline-secondary' }}">{{ $tpl->is_active ? 'Yes' : 'No' }}</button>
                      </form>
                    </td>
                    <td class="text-end">
                      <div class="dropdown">
                        <button type="button" class="btn btn-icon btn-text-secondary btn-sm dropdown-toggle hide-arrow" style="padding: .25rem; width: 32px; height: 32px;" data-bs-toggle="dropdown" aria-expanded="false" title="Actions">
                          <i class="icon-base ri ri-more-2-fill"></i>
                        </button>
                        <div class="dropdown-menu dropdown-menu-end">
                          <a class="dropdown-item" href="{{ route('admin.notification-templates.edit', $tpl->id) }}">
                            <i class="ri-edit-box-line me-2"></i>Edit
                          </a>
                          <div class="dropdown-divider"></div>
                          <form method="post" action="{{ route('admin.notification-templates.destroy', $tpl->id) }}" class="d-inline">
                            @csrf
                            <button type="submit" class="dropdown-item text-danger delete-confirm">
                              <i class="ri-delete-bin-7-line me-2"></i>Delete
                            </button>
                          </form>
                        </div>
                      </div>
                    </td>
                  </tr>
                @empty
                  <tr>
                    <td colspan="5" class="text-center text-muted py-4">No templates found</td>
                  </tr>
                @endforelse
              </tbody>
            </table>
          </div>

          <div class="mt-3">
            {{ $templates->links() }}
          </div>
        </div>
      </div>

  </div>
</div>
@endsection
