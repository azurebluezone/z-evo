@extends('backEnd.layouts.app')
@section('title','Category Manage')

@section('content')
<div class="container-xxl flex-grow-1 container-p-y">
    <div class="row">
        <div class="col-12">
            <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center mb-3 gap-2">
                <h4 class="mb-0">Category Manage</h4>
                <div class="d-flex flex-wrap align-items-center gap-2">
                    <form id="categoriesBulkDeleteForm" method="post" action="{{ route('categories.bulk-destroy') }}" class="d-inline">
                        @csrf
                        <button type="submit" class="btn btn-outline-danger btn-sm delete-confirm" title="Delete selected categories">
                            Delete Selected
                        </button>
                    </form>

                    <form id="categoriesHomePageSetOnlyForm" method="post" action="{{ route('categories.home-page-set-only') }}" class="d-inline">
                        @csrf
                        <button type="submit" class="btn btn-outline-warning btn-sm delete-confirm" title="Set exactly 2 categories as Home Page">
                            Set Home (2 Only)
                        </button>
                    </form>

                    <form method="post" action="{{ route('settings.toggle-top-categories-section') }}" class="d-inline">
                        @csrf
                        <label class="switch" title="Home Page Categories Section">
                            <input
                                type="checkbox"
                                class="switch-input js-auto-submit"
                                {{ (isset($generalSetting) && (int) $generalSetting->home_page_top_categories_section === 1) ? 'checked' : '' }}
                            >

                            <span class="switch-toggle-slider">
                                <span class="switch-on"></span>
                                <span class="switch-off"></span>
                            </span>
                            <span class="switch-label">Home</span>
                        </label>
                    </form>

                    <a href="{{ route('categories.create') }}" class="btn btn-primary">Create</a>
                </div>
            </div>

            <div class="card">
                <div class="card-body">
                    <div class="card-datatable table-responsive mt-3">
                        <table class="table table-striped w-100 align-middle">
                            <thead>
                                <tr>
                                    <th style="width:40px;">

                                        <div class="form-check m-0">
                                            <input type="checkbox" class="form-check-input checkall" value="">
                                        </div>
                                    </th>
                                    <th style="width:30%">Name</th>
                                    <th style="width:15%">Image</th>
                                    <th style="width:10%">Home </th>
                                    <th style="width:10%">Status</th>

                                    <th style="width:12%" class="text-end">Action</th>
                                </tr>
                            </thead>

                            <tbody>
                                @foreach($data as $key=>$value)
                                <tr>
                                    <td>
                                        <div class="form-check m-0">
                                            <input type="checkbox" class="form-check-input checkbox" name="ids[]" value="{{ $value->id }}" form="categoriesBulkDeleteForm">
                                            <input type="checkbox" class="d-none checkbox" name="ids[]" value="{{ $value->id }}" form="categoriesHomePageSetOnlyForm">
                                        </div>
                                    </td>
                                    <td>
                                        @if ($value->front_view == 1)
                                        <span class="btn btn-dark">{{$value->name}}</span>
                                        @else
                                        <span>{{$value->name}}</span>

                                        @endif
                                    </td>
                                    <td>
                                        @php
                                            $catImg = $value->image ?? null;
                                            $catImgPath = $catImg ? preg_replace('~^public/~', '', $catImg) : null;
                                            $catImgPath = $catImgPath ? ltrim($catImgPath, '/') : null;
                                            $fallbackImg = $generalSetting->frontend_empty_image ?? 'assets/images/empty.png';
                                            $fallbackImg = preg_replace('~^public/~', '', $fallbackImg);
                                            $fallbackImg = ltrim($fallbackImg, '/');
                                        @endphp
                                        <img
                                            src="{{ $catImgPath && file_exists(public_path($catImgPath)) ? asset($catImgPath) : asset($fallbackImg) }}"
                                            class="backend-image"
                                            alt="{{ $value->name }}"
                                            onerror="this.src='{{ asset('assets/images/empty.png') }}'">
                                    </td>
                                    <td>
                                        @if(isset($value->home_page) && (int) $value->home_page === 1)
                                            <form method="post" action="{{ route('categories.home-page-off') }}" class="d-inline">
                                                @csrf
                                                <input type="hidden" value="{{ $value->id }}" name="hidden_id">
                                                <label class="switch" title="Shown on home page">
                                                    <input type="checkbox" class="switch-input js-auto-submit" checked>
                                                    <span class="switch-toggle-slider">
                                                        <span class="switch-on"></span>
                                                        <span class="switch-off"></span>
                                                    </span>
                                                </label>
                                            </form>
                                        @else
                                            <form method="post" action="{{ route('categories.home-page-on') }}" class="d-inline">
                                                @csrf
                                                <input type="hidden" value="{{ $value->id }}" name="hidden_id">
                                                <label class="switch" title="Hidden from home page">
                                                    <input type="checkbox" class="switch-input js-auto-submit">
                                                    <span class="switch-toggle-slider">
                                                        <span class="switch-on"></span>
                                                        <span class="switch-off"></span>
                                                    </span>
                                                </label>
                                            </form>
                                        @endif
                                    </td>
                                    <td>
                                        @if((int) $value->status === 1)
                                            <form method="post" action="{{ route('categories.inactive') }}" class="d-inline">
                                                @csrf
                                                <input type="hidden" value="{{ $value->id }}" name="hidden_id">
                                                <label class="switch" title="Active">
                                                    <input type="checkbox" class="switch-input js-auto-submit" checked>
                                                    <span class="switch-toggle-slider">
                                                        <span class="switch-on"></span>
                                                        <span class="switch-off"></span>
                                                    </span>
                                                </label>
                                            </form>
                                        @else
                                            <form method="post" action="{{ route('categories.active') }}" class="d-inline">
                                                @csrf
                                                <input type="hidden" value="{{ $value->id }}" name="hidden_id">
                                                <label class="switch" title="Inactive">
                                                    <input type="checkbox" class="switch-input js-auto-submit">
                                                    <span class="switch-toggle-slider">
                                                        <span class="switch-on"></span>
                                                        <span class="switch-off"></span>
                                                    </span>
                                                </label>
                                            </form>
                                        @endif
                                    </td>
                                    <td class="text-end">
                                        <div class="d-inline-flex align-items-center gap-2">
                                            <a href="{{ route('categories.edit', $value->id) }}" class="btn btn-icon btn-text-secondary btn-sm" title="Edit" data-bs-toggle="tooltip" data-bs-title="Edit">
                                                <i class="icon-base ri ri-edit-box-line icon-22px"></i>
                                            </a>

                                            <form method="post" action="{{ route('categories.destroy') }}" class="d-inline">
                                                @csrf
                                                <input type="hidden" value="{{ $value->id }}" name="hidden_id">
                                                <button type="submit" class="btn btn-icon btn-text-secondary btn-sm delete-confirm" title="Delete" data-bs-toggle="tooltip" data-bs-title="Delete">
                                                    <i class="icon-base ri ri-delete-bin-7-line icon-22px"></i>
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection