@extends('backEnd.layouts.app')
@section('title','Category Create')
@section('content')
<div class="container-xxl flex-grow-1 container-p-y">
    <div class="row">
        <div class="col-12">
            <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center mb-3 gap-2">
                <h4 class="mb-0">Category Create</h4>
                <a href="{{ route('categories.index') }}" class="btn btn-primary">Manage</a>
            </div>

            <div class="card">
                <div class="card-body">
                    <form action="{{ route('categories.store') }}" method="POST" class="row g-3" data-parsley-validate="" enctype="multipart/form-data">
                        @csrf

                        <div class="col-12">
                            <label for="name" class="form-label">Name *</label>
                            <input type="text" class="form-control @error('name') is-invalid @enderror" name="name" value="{{ old('name') }}" id="name" required="">
                            @error('name')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>

                        <div class="col-12">
                            <label for="image" class="form-label">Image *</label>
                            <input type="file" class="form-control js-dropify @error('image') is-invalid @enderror" name="image" id="image">
                            @error('image')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>

                        @include('frontend.layouts.partials.seo-fields')

                        <div class="col-12 col-md-6">
                            <label class="form-label d-block">Status</label>
                            <label class="switch">
                                <input type="checkbox" value="1" name="status" checked>
                                <span class="switch-toggle-slider">
                                    <span class="switch-on"></span>
                                    <span class="switch-off"></span>
                                </span>
                            </label>
                            @error('status')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>

                        <div class="col-12 col-md-6">
                            <label class="form-label d-block">Front View</label>
                            <label class="switch">
                                <input type="checkbox" value="1" name="front_view">
                                <span class="switch-toggle-slider">
                                    <span class="switch-on"></span>
                                    <span class="switch-off"></span>
                                </span>
                            </label>
                            @error('front_view')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>

                        <div class="col-12">
                            <button type="submit" class="btn btn-success">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection