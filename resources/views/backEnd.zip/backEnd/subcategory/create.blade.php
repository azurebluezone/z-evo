@extends('backEnd.layouts.app')
@section('title','Subategory Create')
@section('content')
<div class="row">
    <div class="col-12">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center mb-3 gap-2">
            <h4 class="mb-0">Subcategory Create</h4>
            <a href="{{ route('subcategories.index') }}" class="btn btn-primary">Manage</a>
        </div>

        <div class="card">
            <div class="card-body">
                <form action="{{ route('subcategories.store') }}" method="POST" class="row g-3" data-parsley-validate="" enctype="multipart/form-data">
                    @csrf

                    <div class="col-12">
                        <label for="category_id" class="form-label">Category *</label>
                        <select class="form-select @error('category_id') is-invalid @enderror" id="category_id" name="category_id" required>
                            <option value="">Choose..</option>
                            @foreach($categories as $category)
                                <option value="{{ $category->id }}" {{ (old('category_id') == $category->id) ? 'selected' : '' }}>{{ $category->name }}</option>
                            @endforeach
                        </select>
                        @error('category_id')
                            <span class="invalid-feedback" role="alert"><strong>{{ $message }}</strong></span>
                        @enderror
                    </div>

                    <div class="col-12">
                        <label for="subcategoryName" class="form-label">Subcategory Name *</label>
                        <input type="text" class="form-control @error('subcategoryName') is-invalid @enderror" name="subcategoryName" value="{{ old('subcategoryName') }}" id="subcategoryName" required>
                        @error('subcategoryName')
                            <span class="invalid-feedback" role="alert"><strong>{{ $message }}</strong></span>
                        @enderror
                    </div>

                    @php
                        $model = new App\Models\Subcategory();
                    @endphp
                    @include('frontend.layouts.partials.seo-fields')

                    <div class="col-12 col-md-6">
                        <label class="form-label d-block">Status</label>
                        <label class="switch">
                            <input type="checkbox" value="1" name="status" checked>
                            <span class="switch-toggle-slider">
                                <span class="switch-on"></span>
                                <span class="switch-off"></span>
                            </span>
                        </label>
                        @error('status')
                            <span class="invalid-feedback" role="alert"><strong>{{ $message }}</strong></span>
                        @enderror
                    </div>

                    <div class="col-12">
                        <button type="submit" class="btn btn-success">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection