@extends('backEnd.layouts.app')
@section('title','Subcategory Manage')

@section('content')
<div class="row">
    <div class="col-12">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center mb-3 gap-2">
            <h4 class="mb-0">Subcategory Manage</h4>
            <div class="d-flex flex-wrap align-items-center gap-2">
                <form id="subcategoriesBulkDeleteForm" method="post" action="{{ route('subcategories.bulk-destroy') }}" class="d-inline">
                    @csrf
                    <button type="submit" class="btn btn-outline-danger btn-sm delete-confirm" title="Delete selected subcategories">
                        Delete Selected
                    </button>
                </form>

                <a href="{{ route('subcategories.create') }}" class="btn btn-primary">Create</a>
            </div>
        </div>

        <div class="card">
            <div class="card-body">
                <div class="card-datatable table-responsive mt-3">
                    <table class="table table-striped w-100 align-middle">
                        <thead>
                            <tr>
                                <th style="width:40px;">
                                    <div class="form-check m-0">
                                        <input type="checkbox" class="form-check-input checkall" value="">
                                    </div>
                                </th>
                                <th style="width:5%">SL</th>
                                <th style="width:25%">Category</th>
                                <th style="width:30%">Name</th>
                                <th style="width:10%">Status</th>
                                <th style="width:12%" class="text-end">Action</th>
                            </tr>
                        </thead>

                        <tbody>
                            @foreach($data as $key=>$value)
                            <tr>
                                <td>
                                    <div class="form-check m-0">
                                        <input type="checkbox" class="form-check-input checkbox" name="ids[]" value="{{ $value->id }}" form="subcategoriesBulkDeleteForm">
                                    </div>
                                </td>
                                <td>{{$loop->iteration}}</td>
                                <td>{{ $value->category ? $value->category->name : '' }}</td>
                                <td>{{ $value->subcategoryName }}</td>
                                <td>
                                    @if((int) $value->status === 1)
                                        <form method="post" action="{{ route('subcategories.inactive') }}" class="d-inline">
                                            @csrf
                                            <input type="hidden" value="{{ $value->id }}" name="hidden_id">
                                            <label class="switch switch-square" title="Active">
                                                <input type="checkbox" class="switch-input js-auto-submit" checked>
                                                <span class="switch-toggle-slider">
                                                    <span class="switch-on"><i class="icon-base ri ri-check-line"></i></span>
                                                    <span class="switch-off"><i class="icon-base ri ri-close-line"></i></span>
                                                </span>
                                            </label>
                                        </form>
                                    @else
                                        <form method="post" action="{{ route('subcategories.active') }}" class="d-inline">
                                            @csrf
                                            <input type="hidden" value="{{ $value->id }}" name="hidden_id">
                                            <label class="switch switch-square" title="Inactive">
                                                <input type="checkbox" class="switch-input js-auto-submit">
                                                <span class="switch-toggle-slider">
                                                    <span class="switch-on"><i class="icon-base ri ri-check-line"></i></span>
                                                    <span class="switch-off"><i class="icon-base ri ri-close-line"></i></span>
                                                </span>
                                            </label>
                                        </form>
                                    @endif
                                </td>
                                <td class="text-end">
                                    <div class="d-inline-flex align-items-center gap-2">
                                        <a href="{{ route('subcategories.edit', $value->id) }}" class="btn btn-icon btn-text-secondary btn-sm" title="Edit" data-bs-toggle="tooltip" data-bs-title="Edit">
                                            <i class="icon-base ri ri-edit-box-line icon-22px"></i>
                                        </a>
                                        <form method="post" action="{{ route('subcategories.destroy') }}" class="d-inline">
                                            @csrf
                                            <input type="hidden" value="{{ $value->id }}" name="hidden_id">
                                            <button type="submit" class="btn btn-icon btn-text-secondary btn-sm delete-confirm" title="Delete" data-bs-toggle="tooltip" data-bs-title="Delete">
                                                <i class="icon-base ri ri-delete-bin-7-line icon-22px"></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection