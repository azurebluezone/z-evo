@extends('backEnd.layouts.app')
@section('title','Attribute Values')

@section('content')
<div class="container-fluid">
  <div class="row">
    <div class="col-12">
      <div class="page-title-box d-flex align-items-center justify-content-between">
        <div>
          <h4 class="page-title mb-0">Values: {{ $attribute->name }}</h4>
          <div class="text-muted">{{ $attribute->slug }}</div>
        </div>
        <a href="{{ route('admin.attributes.index') }}" class="btn btn-sm btn-secondary">Back to Attributes</a>
      </div>
    </div>
  </div>

  <div class="row">
    <div class="col-12">
      <div class="card">
        <div class="card-body">
          <form method="POST" action="{{ route('admin.attributes.values.store', $attribute->id) }}">
            @csrf
            <div class="row">
              <div class="col-md-4 mb-3">
                <label class="form-label">Value</label>
                <input type="text" name="value" class="form-control @error('value') is-invalid @enderror" value="{{ old('value') }}" required />
                @error('value')
                  <div class="invalid-feedback">{{ $message }}</div>
                @enderror
              </div>
              <div class="col-md-2 mb-3">
                <label class="form-label">Code (Optional)</label>
                <input type="text" name="code" class="form-control @error('code') is-invalid @enderror" value="{{ old('code') }}" />
                @error('code')
                  <div class="invalid-feedback">{{ $message }}</div>
                @enderror
              </div>
              <div class="col-md-2 mb-3">
                <label class="form-label">Multiplier (Optional)</label>
                <input type="number" name="multiplier" class="form-control @error('multiplier') is-invalid @enderror" value="{{ old('multiplier') }}" min="1" />
                @error('multiplier')
                  <div class="invalid-feedback">{{ $message }}</div>
                @enderror
              </div>
              <div class="col-md-2 mb-3">
                <label class="form-label">Base Unit (Optional)</label>
                <input type="text" name="base_unit" class="form-control @error('base_unit') is-invalid @enderror" value="{{ old('base_unit') }}" />
                @error('base_unit')
                  <div class="invalid-feedback">{{ $message }}</div>
                @enderror
              </div>
              <div class="col-md-2 mb-3">
                <label class="form-label">Sort</label>
                <input type="number" name="sort_order" class="form-control @error('sort_order') is-invalid @enderror" value="{{ old('sort_order','0') }}" min="0" />
                @error('sort_order')
                  <div class="invalid-feedback">{{ $message }}</div>
                @enderror
              </div>
            </div>

            <div class="mt-2">
              <button type="submit" class="btn btn-success">Add Value</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
  @if(($attribute->kind ?? 'custom') === 'system')
  <div class="row">
    <div class="col-12">
      <div class="alert alert-secondary">
        This is a system attribute. Seeded values are locked for consistency, but you can add new values.
      </div>
    </div>
  </div>
  @endif

  <div class="row">
    <div class="col-12">
      <div class="card">
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-striped table-bordered mb-0">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Value</th>
                  <th>Code</th>
                  <th>Multiplier</th>
                  <th>Base Unit</th>
                  <th>Type</th>
                  <th>Status</th>
                  <th class="text-end">Action</th>
                </tr>
              </thead>
              <tbody>
                @foreach($values as $v)
                <tr>
                  <td>{{ $v->id }}</td>
                  <td>{{ $v->value }}</td>
                  <td>{{ $v->code }}</td>
                  <td>{{ $v->multiplier }}</td>
                  <td>{{ $v->base_unit }}</td>
                  <td>
                    @if(($v->kind ?? 'custom') === 'system')
                      <span class="badge bg-secondary">System</span>
                    @else
                      <span class="badge bg-info">Custom</span>
                    @endif
                  </td>
                  <td>
                    @if((int)($v->status ?? 1) === 1)
                      <span class="badge bg-success">Active</span>
                    @else
                      <span class="badge bg-secondary">Inactive</span>
                    @endif
                  </td>
                  <td class="text-end">
                    @if(($v->kind ?? 'custom') !== 'system')
                      <form action="{{ route('admin.attributes.values.destroy', [$attribute->id, $v->id]) }}" method="POST" class="d-inline" onsubmit="return confirm('Are you sure you want to delete this value?');">
                        @csrf
                        <button type="submit" class="btn btn-sm btn-outline-danger">Delete</button>
                      </form>
                    @endif
                  </td>
                </tr>
                @endforeach
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <div class="card mt-3">
        <div class="card-body text-muted">
          For courier pricing, use multiplier + base_unit to normalize user input.
        </div>
      </div>

    </div>
  </div>
</div>
@endsection
