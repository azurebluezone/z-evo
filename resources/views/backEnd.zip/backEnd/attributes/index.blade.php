@extends('backEnd.layouts.app')
@section('title','Attributes')

@section('content')
<div class="container-fluid">
  <div class="row">
    <div class="col-12">
      <div class="page-title-box d-flex align-items-center justify-content-between">
        <h4 class="page-title mb-0">Attributes</h4>
        <a href="{{ route('admin.attributes.create') }}" class="btn btn-sm btn-primary">Create Attribute</a>
      </div>
    </div>
  </div>

  <div class="row">
    <div class="col-12">
      <div class="card">
        <div class="card-body">
          <div class="card-datatable table-responsive">
            <table class="table table-striped table-bordered mb-0">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Name</th>
                  <th>Slug</th>
                  <th>Type</th>
                  <th>Status</th>
                  <th class="text-end">Action</th>
                </tr>
              </thead>
              <tbody>
                @foreach($attributes as $a)
                <tr>
                  <td>{{ $a->id }}</td>
                  <td>{{ $a->name }}</td>
                  <td>{{ $a->slug }}</td>
                  <td>
                    @if(($a->kind ?? 'custom') === 'system')
                      <span class="badge bg-secondary">System</span>
                    @else
                      <span class="badge bg-info">Custom</span>
                    @endif
                  </td>
                  <td>
                    @if((int)($a->status ?? 1) === 1)
                      <span class="badge bg-success">Active</span>
                    @else
                      <span class="badge bg-secondary">Inactive</span>
                    @endif
                  </td>
                  <td class="text-end">
                    <a href="{{ route('admin.attributes.values', $a->id) }}" class="btn btn-sm btn-outline-secondary">Values</a>
                    @if(($a->kind ?? 'custom') !== 'system')
                      <a href="{{ route('admin.attributes.edit', $a->id) }}" class="btn btn-sm btn-outline-primary">Edit</a>
                      <form action="{{ route('admin.attributes.destroy', $a->id) }}" method="POST" class="d-inline" onsubmit="return confirm('Are you sure you want to delete this attribute?');">
                        @csrf
                        <button type="submit" class="btn btn-sm btn-outline-danger">Delete</button>
                      </form>
                    @endif
                  </td>
                </tr>
                @endforeach
              </tbody>
            </table>
          </div>

          <div class="mt-3">
            {{ $attributes->links() }}
          </div>
        </div>
      </div>

      <div class="card mt-3">
        <div class="card-body text-muted">
          System attributes are pre-seeded (e.g. weight/volume units) and are locked to prevent spelling or keyboard inconsistencies.
        </div>
      </div>

    </div>
  </div>
</div>
@endsection
