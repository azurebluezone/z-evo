@extends('backEnd.layouts.app')
@section('title','Brand Manage')

@section('content')
<div class="row">
    <div class="col-12">
        <div class="d-flex flex-wrap align-items-center justify-content-between gap-2 mb-3">
            <h4 class="mb-0">Brand Manage</h4>
            <div class="d-flex flex-wrap align-items-center gap-2">
                @if(isset($generalSetting) && $generalSetting->home_page_brands_section == 1)
                <form method="post" action="{{route('settings.toggle-brands-section')}}" class="d-inline">
                    @csrf
                    <button type="button" class="btn btn-success change-confirm" title="Brands section is visible on home page">
                        Hide Brands Section
                    </button>
                </form>
                @else
                <form method="post" action="{{route('settings.toggle-brands-section')}}" class="d-inline">
                    @csrf
                    <button type="button" class="btn btn-warning change-confirm" title="Brands section is hidden from home page">
                        Show Brands Section
                    </button>
                </form>
                @endif
                <a href="{{route('brands.create')}}" class="btn btn-primary">Create</a>
            </div>
        </div>

        <div class="card">
            <div class="card-body">
                <div class="card-datatable table-responsive">
                    <table class="table table-striped w-100 align-middle">
                        <thead>
                            <tr>
                                <th style="width:5%">SL</th>
                                <th style="width:25%">Name</th>
                                <th style="width:15%">Image</th>
                                <th style="width:10%">Status</th>
                                <th style="width:15%">Action</th>
                            </tr>
                        </thead>
                
                        <tbody>
                            @foreach($data as $key=>$value)
                            <tr>
                                <td>{{$loop->iteration}}</td>
                                <td>{{$value->name}}</td>
                                <td>
                                    @php
                                        $brandImg = $value->image ?? null;
                                        $brandImgPath = $brandImg ? preg_replace('~^public/~', '', $brandImg) : null;
                                        $brandImgPath = $brandImgPath ? ltrim($brandImgPath, '/') : null;
                                        $fallbackImg = $generalSetting->frontend_empty_image ?? 'assets/images/empty.png';
                                        $fallbackImg = preg_replace('~^public/~', '', $fallbackImg);
                                        $fallbackImg = ltrim($fallbackImg, '/');
                                    @endphp
                                    <img
                                        src="{{ $brandImgPath && file_exists(public_path($brandImgPath)) ? asset($brandImgPath) : asset($fallbackImg) }}"
                                        class="backend-image"
                                        alt="{{$value->name}}"
                                        onerror="this.src='{{ asset('assets/images/empty.png') }}'">
                                </td>
                                <td>@if($value->status==1)<span class="badge bg-label-success rounded-pill">Active</span> @else <span class="badge bg-label-danger rounded-pill">Inactive</span> @endif</td>
                                <td>
                                    <div class="d-flex align-items-center gap-2">
                                        @if($value->status == 1)
                                        <form method="post" action="{{route('brands.inactive')}}" class="d-inline"> 
                                        @csrf
                                        <input type="hidden" value="{{$value->id}}" name="hidden_id">       
                                        <label class="switch" title="Active">
                                            <input type="checkbox" class="switch-input js-auto-submit" checked>
                                            <span class="switch-toggle-slider">
                                                <span class="switch-on"></span>
                                                <span class="switch-off"></span>
                                            </span>
                                        </label>
                                        </form>
                                        @else
                                        <form method="post" action="{{route('brands.active')}}" class="d-inline">
                                            @csrf
                                        <input type="hidden" value="{{$value->id}}" name="hidden_id">        
                                        <label class="switch" title="Inactive">
                                            <input type="checkbox" class="switch-input js-auto-submit">
                                            <span class="switch-toggle-slider">
                                                <span class="switch-on"></span>
                                                <span class="switch-off"></span>
                                            </span>
                                        </label>
                                        </form>
                                        @endif

                                        <a href="{{route('brands.edit',$value->id)}}" class="btn btn-icon btn-text-secondary btn-sm" title="Edit" data-bs-toggle="tooltip" data-bs-title="Edit">
                                            <i class="icon-base ri ri-edit-box-line icon-22px"></i>
                                        </a>

                                        <form method="post" action="{{route('brands.destroy')}}" class="d-inline">        
                                            @csrf
                                            <input type="hidden" value="{{$value->id}}" name="hidden_id">
                                            <button type="submit" class="btn btn-icon btn-text-secondary btn-sm delete-confirm" title="Delete" data-bs-toggle="tooltip" data-bs-title="Delete">
                                                <i class="icon-base ri ri-delete-bin-7-line icon-22px"></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div> <!-- end card body-->
        </div> <!-- end card -->
    </div><!-- end col-->
   </div>
</div>
@endsection


@section('script')
@endsection