@extends('backEnd.layouts.app')
@section('title','Inventory / Stock')

@section('content')
<div class="container-fluid">
  <div class="row">
    <div class="col-12">
      <div class="d-flex flex-wrap align-items-center justify-content-between gap-2 mb-3">
        <h4 class="mb-0">Inventory / Stock</h4>
        <a href="{{ route('admin.inventory.adjustment') }}" class="btn btn-primary">Adjustment</a>
      </div>
    </div>
  </div>

  @php
    $kpiTotal = isset($variants) ? (int) $variants->total() : 0;
    $kpiLow = 0;
    $kpiOut = 0;
    if (isset($variants)) {
      foreach ($variants as $vv) {
        $av = (int) ($vv->available ?? 0);
        if ($av <= 0) { $kpiOut++; }
        if ($av > 0 && $av <= 2) { $kpiLow++; }
      }
    }
  @endphp

  <div class="row">
    <div class="col-12">
      <div class="card mb-3">
        <div class="card-widget-separator-wrapper">
          <div class="card-body card-widget-separator">
            <div class="row gy-4 gy-sm-1">
              <div class="col-sm-6 col-lg-4">
                <div class="d-flex justify-content-between align-items-start card-widget-1 border-end pb-4 pb-sm-0">
                  <div>
                    <h4 class="mb-0">{{ $kpiTotal }}</h4>
                    <p class="mb-0">Total Variants</p>
                  </div>
                  <div class="avatar me-sm-6">
                    <span class="avatar-initial rounded-3 text-heading">
                      <i class="icon-base ri ri-stack-line icon-26px"></i>
                    </span>
                  </div>
                </div>
                <hr class="d-none d-sm-block d-lg-none me-6">
              </div>
              <div class="col-sm-6 col-lg-4">
                <div class="d-flex justify-content-between align-items-start card-widget-2 border-end pb-4 pb-sm-0">
                  <div>
                    <h4 class="mb-0">{{ $kpiLow }}</h4>
                    <p class="mb-0">Low Stock (1-2)</p>
                  </div>
                  <div class="avatar me-lg-6">
                    <span class="avatar-initial rounded-3 text-heading">
                      <i class="icon-base ri ri-alert-line icon-26px"></i>
                    </span>
                  </div>
                </div>
                <hr class="d-none d-sm-block d-lg-none">
              </div>
              <div class="col-sm-6 col-lg-4">
                <div class="d-flex justify-content-between align-items-start">
                  <div>
                    <h4 class="mb-0">{{ $kpiOut }}</h4>
                    <p class="mb-0">Out of Stock</p>
                  </div>
                  <div class="avatar">
                    <span class="avatar-initial rounded-3 text-heading">
                      <i class="icon-base ri ri-close-circle-line icon-26px"></i>
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="row">
    <div class="col-12">
      <div class="card">
        <div class="card-body">
          <div class="card-datatable table-responsive">
            <table class="table table-striped table-bordered mb-0">
              <thead>
                <tr>
                  <th class="d-none d-lg-table-cell">Variant ID</th>
                  <th class="d-none d-md-table-cell">SKU</th>
                  <th>Variant</th>
                  <th class="d-none d-sm-table-cell">Product</th>
                  <th class="text-end">On Hand</th>
                  <th class="text-end d-none d-md-table-cell">Reserved</th>
                  <th class="text-end">Available</th>
                </tr>
              </thead>
              <tbody>
                @forelse($variants as $v)
                  @php $isLow = (int) ($v->available ?? 0) > 0 && (int) ($v->available ?? 0) <= 2; @endphp
                  @php $isOut = (int) ($v->available ?? 0) <= 0; @endphp
                  <tr class="{{ $isLow ? 'table-danger' : '' }} {{ $isOut ? 'table-warning' : '' }}">
                    <td class="d-none d-lg-table-cell">{{ $v->id }}</td>
                    <td class="d-none d-md-table-cell">{{ $v->sku }}</td>
                    <td>{{ $v->title }}</td>
                    <td class="d-none d-sm-table-cell">{{ $v->product_name }}</td>
                    <td class="text-end">{{ $v->on_hand }}</td>
                    <td class="text-end d-none d-md-table-cell">{{ $v->reserved }}</td>
                    <td class="text-end fw-semibold {{ $isLow ? 'text-danger' : '' }}">{{ $v->available }}</td>
                  </tr>
                @empty
                  <tr>
                    <td colspan="7" class="text-center text-muted">No variants found</td>
                  </tr>
                @endforelse
              </tbody>
            </table>
          </div>

          <div class="mt-3">
            {{ $variants->links() }}
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
@endsection
