@extends('backEnd.layouts.app')
@section('title','Inventory Adjustment')

@section('content')
<div class="container-fluid">
  <div class="row">
    <div class="col-12">
      <div class="d-flex flex-wrap align-items-center justify-content-between gap-2 mb-3">
        <h4 class="mb-0">Inventory Adjustment</h4>
        <a href="{{ route('admin.inventory.index') }}" class="btn btn-outline-secondary">Back to Stock</a>
      </div>
    </div>
  </div>

  <div class="row">
    <div class="col-12">
      <div class="card mb-3">
        <div class="card-widget-separator-wrapper">
          <div class="card-body card-widget-separator">
            <div class="row gy-3">
              <div class="col-12">
                <div class="d-flex justify-content-between align-items-start">
                  <div>
                    <h6 class="mb-1">What this does</h6>
                    <div class="text-muted">
                      Writes an <b>ADJUSTMENT</b> row to <code>inventory_movements</code>, updates <code>variant_stocks</code>, and syncs legacy <code>products.stock</code>.
                    </div>
                  </div>
                  <div class="avatar">
                    <span class="avatar-initial rounded-3 text-heading">
                      <i class="icon-base ri ri-file-list-3-line icon-26px"></i>
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="card">
        <div class="card-body">
          <form method="POST" action="{{ route('admin.inventory.adjustment.store') }}">
            @csrf

            <div class="row g-3">
              <div class="col-12">
                <label class="form-label">Variant</label>
                <select name="variant_id" class="form-select @error('variant_id') is-invalid @enderror" required>
                  <option value="">Select variant</option>
                  @foreach($variants as $v)
                    <option value="{{ $v->id }}" {{ old('variant_id') == $v->id ? 'selected' : '' }}>
                      #{{ $v->id }} — {{ $v->sku }} — {{ $v->product_name }}{{ $v->title ? ' / ' . $v->title : '' }}
                    </option>
                  @endforeach
                </select>
                @error('variant_id')
                  <div class="invalid-feedback">{{ $message }}</div>
                @enderror
              </div>

              <div class="col-12 col-md-4">
                <label class="form-label">Movement Type</label>
                <select name="type" class="form-select @error('type') is-invalid @enderror" required>
                  <option value="ADJUSTMENT" {{ old('type', 'ADJUSTMENT') === 'ADJUSTMENT' ? 'selected' : '' }}>Adjustment</option>
                  <option value="RECEIVE" {{ old('type') === 'RECEIVE' ? 'selected' : '' }}>Receive</option>
                  <option value="DAMAGE" {{ old('type') === 'DAMAGE' ? 'selected' : '' }}>Damage</option>
                  <option value="LOST" {{ old('type') === 'LOST' ? 'selected' : '' }}>Lost</option>
                </select>
                @error('type')
                  <div class="invalid-feedback">{{ $message }}</div>
                @enderror
              </div>

              <div class="col-12 col-md-4">
                <label class="form-label">Qty Delta</label>
                <input type="number" name="qty_delta" class="form-control @error('qty_delta') is-invalid @enderror" value="{{ old('qty_delta') }}" required />
                @error('qty_delta')
                  <div class="invalid-feedback">{{ $message }}</div>
                @enderror
                <div class="form-text">Use positive to add stock, negative to reduce.</div>
              </div>

              <div class="col-12 col-md-4">
                <label class="form-label">Note (Optional)</label>
                <input type="text" name="note" class="form-control @error('note') is-invalid @enderror" value="{{ old('note') }}" />
                @error('note')
                  <div class="invalid-feedback">{{ $message }}</div>
                @enderror
              </div>
            </div>

            <div class="mt-2">
              <button type="submit" class="btn btn-success">Apply Adjustment</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
@endsection
