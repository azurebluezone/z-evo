<footer class="footer bg-light">
    <div class="container-fluid d-flex flex-md-row flex-column justify-content-between align-items-md-center gap-1 container-p-x py-4">
        <div>
            <a href="{{ route('dashboard') }}" class="footer-brand fw-bold">{{ $generalsetting->name ?? config('app.name', 'Z-Evo-Commerce') }}</a>
            &#169; {{ date('Y') }}
        </div>
        <div class="d-flex flex-column flex-sm-row">
            <a href="https://developerszone.info/" class="footer-link me-6" target="_blank">Support</a>
            <a href="javascript:void(0)" class="footer-link me-6">Help</a>
            <a href="javascript:void(0)" class="footer-link me-6">Contact</a>
            <a href="javascript:void(0)" class="footer-link">Terms &amp; Conditions</a>
        </div>
    </div>
</footer>