<div class="row g-3">
    <div class="col-md-6">
        <div class="mb-3">
            <label for="meta_title" class="form-label">Meta Title</label>
            <input type="text" 
                   name="seo_meta[meta_title]" 
                   id="meta_title" 
                   class="form-control" 
                   value="{{ old('seo_meta.meta_title', isset($model) && $model->seoMeta ? $model->seoMeta->meta_title : '') }}"
                   maxlength="60"
                   placeholder="e.g. Premium Wireless Bluetooth Headphones">
            <div class="form-text"></div>
        </div>
    </div>
    
    <div class="col-md-6">
        <div class="mb-3">
            <label for="meta_keywords" class="form-label">Meta Keywords</label>
            <input type="text" 
                   name="seo_meta[meta_keywords]" 
                   id="meta_keywords" 
                   class="form-control" 
                   value="{{ old('seo_meta.meta_keywords', isset($model) && $model->seoMeta ? $model->seoMeta->meta_keywords : '') }}"
                   placeholder="e.g. headphones, bluetooth, wireless">
            <div class="form-text"></div>
        </div>
    </div>
    
    <div class="col-md-12">
        <div class="mb-3">
            <label for="meta_description" class="form-label">Meta Description</label>
            <textarea name="seo_meta[meta_description]" 
                      id="meta_description" 
                      class="form-control" 
                      rows="2" 
                      maxlength="160"
                      placeholder="e.g. High-quality Bluetooth headphones with noise cancellation">{{ old('seo_meta.meta_description', isset($model) && $model->seoMeta ? $model->seoMeta->meta_description : '') }}</textarea>
            <div class="form-text"></div>
        </div>
    </div>
    
    <div class="col-md-6">
        <div class="mb-0">
            <label for="robots" class="form-label">Robots</label>
            <select name="seo_meta[robots]" id="robots" class="form-select">
                <option value="index,follow" {{ (old('seo_meta.robots', (isset($model) && $model->seoMeta ? $model->seoMeta->robots : 'index,follow')) == 'index,follow') ? 'selected' : '' }}>Index, Follow</option>
                <option value="noindex,follow" {{ (old('seo_meta.robots', (isset($model) && $model->seoMeta ? $model->seoMeta->robots : '')) == 'noindex,follow') ? 'selected' : '' }}>No Index, Follow</option>
                <option value="index,nofollow" {{ (old('seo_meta.robots', (isset($model) && $model->seoMeta ? $model->seoMeta->robots : '')) == 'index,nofollow') ? 'selected' : '' }}>Index, No Follow</option>
                <option value="noindex,nofollow" {{ (old('seo_meta.robots', (isset($model) && $model->seoMeta ? $model->seoMeta->robots : '')) == 'noindex,nofollow') ? 'selected' : '' }}>No Index, No Follow</option>
            </select>
        </div>
    </div>
    
    <div class="col-md-6">
        <div class="mb-0">
            <label for="canonical_url" class="form-label">Canonical URL</label>
            <input type="url" 
                   name="seo_meta[canonical_url]" 
                   id="canonical_url" 
                   class="form-control" 
                   value="{{ old('seo_meta.canonical_url', isset($model) && $model->seoMeta ? $model->seoMeta->canonical_url : '') }}"
                   placeholder="https://example.com/page">
        </div>
    </div>
</div>
