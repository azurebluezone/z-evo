<!-- Fonts -->
<link rel="preconnect" href="https://fonts.googleapis.com" />
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet" />

<!-- Fonts Icons -->
<link rel="preload" as="style" href="{{ asset('admin/build/iconify-CUE6U6uZ.css') }}" />
<link rel="stylesheet" href="{{ asset('admin/build/iconify-CUE6U6uZ.css') }}" class="" />

<link rel="stylesheet" href="{{ asset('admin/build/editor-DomTqdbp.css') }}">

<link rel="stylesheet" href="{{ asset('admin/build/flatpickr-B792qU_v.css') }}" class="" />
<link rel="stylesheet" href="{{ asset('admin/build/dropzone-BDlt4BNV.css') }}" class="" />
<link rel="stylesheet" href="{{ asset('admin/build/tagify-CiyL6FGt.css') }}" class="" />
<link rel="stylesheet" href="{{ asset('admin/build/katex-C5aPEGkQ.css') }}" class="" />

<!-- BEGIN: Vendor CSS-->
<link rel="preload" as="style" href="{{ asset('admin/build/node-waves-CNx6tA5W.css') }}" />
<link rel="stylesheet" href="{{ asset('admin/build/node-waves-CNx6tA5W.css') }}" class="" />
<link rel="preload" as="style" href="{{ asset('admin/build/pickr-themes-CFnMLNHJ.css') }}" />
<link rel="stylesheet" href="{{ asset('admin/build/pickr-themes-CFnMLNHJ.css') }}" class="" />

<!-- Core CSS -->
<link rel="preload" as="style" href="{{ asset('admin/build/core-i1SQTzbd.css') }}" />
<link rel="preload" as="style" href="{{ asset('admin/build/demo-CWktWidu.css') }}" />
<link rel="preload" as="style" href="{{ asset('admin/build/perfect-scrollbar-CfyPsj0y.css') }}" />
<link rel="stylesheet" href="{{ asset('admin/build/core-i1SQTzbd.css') }}" class="template-customizer-core-css" />
<link rel="stylesheet" href="{{ asset('admin/build/demo-CWktWidu.css') }}" class="" />
<link rel="stylesheet" href="{{ asset('admin/build/perfect-scrollbar-CfyPsj0y.css') }}" class="" />
<link rel="stylesheet" href="{{ asset('admin/build/select2-D9WTPIs0.css') }}" class="" />

<!-- Vendor Styles -->
<link rel="preload" as="style" href="{{ asset('admin/build/typeahead-C3JXAIIl.css') }}" />
<link rel="stylesheet" href="{{ asset('admin/build/typeahead-C3JXAIIl.css') }}" class="" />
<link rel="preload" as="style" href="{{ asset('admin/build/apex-charts-DKh_wHnT.css') }}" />
<link rel="preload" as="style" href="{{ asset('admin/build/swiper-BvLUe4Et.css') }}" />
<link rel="stylesheet" href="{{ asset('admin/build/apex-charts-DKh_wHnT.css') }}" class="" />
<link rel="stylesheet" href="{{ asset('admin/build/swiper-BvLUe4Et.css') }}" class="" />

<!-- Page Styles -->
<link rel="preload" as="style" href="{{ asset('admin/build/cards-statistics-Clvkd2dH.css') }}" />
<link rel="stylesheet" href="{{ asset('admin/build/cards-statistics-Clvkd2dH.css') }}" class="" />

<!-- Template Customizer -->
<link rel="preload" as="style" href="{{ asset('admin/build/template-customizer-CyQME3xr.css') }}" />
<link rel="stylesheet" href="{{ asset('admin/build/template-customizer-CyQME3xr.css') }}" />

<!-- Page Customizer -->
<link rel="preload" as="style" href="{{ asset('admin/build/typography-BwT_wJQU.css') }}" />
<link rel="stylesheet" href="{{ asset('admin/build/typography-BwT_wJQU.css') }}" class="" />

<style>
  img.backend-image {
    width: 40px;
    height: 40px;
    object-fit: cover;
    border-radius: 8px;
  }

  /* Fallback image styling for broken images */
  img.backend-image[src=""],
  img.backend-image:not([src]) {
    background: #f3f4f6 url('{{ asset('assets/images/empty.png') }}') center/contain no-repeat;
  }

  .card-datatable thead th {
    white-space: nowrap;
  }

  .qty-cart .quantity {
    display: inline-flex;
    align-items: stretch;
    gap: 0;
  }

  .qty-cart .quantity button {
    width: 28px;
    height: 28px;
    line-height: 28px;
    padding: 0;
  }

  .qty-cart .quantity input {
    height: 28px;
    padding: 0 6px;
  }

  label.switch {
    cursor: pointer;
  }

  label.switch .switch-label {
    pointer-events: none;
  }

  label.switch .switch-toggle-slider,
  label.switch .switch-on,
  label.switch .switch-off {
    pointer-events: none;
  }

  i.btn.btn-success.waves-input-wrapper,
  i.btn.btn-success.waves-input-wrapper.waves-effect,
  i.btn.btn-success.waves-input-wrapper.waves-effect.waves-light {
    color: #000 !important;
  }

  i.btn.btn-success.waves-input-wrapper > input.waves-button-input,
  i.btn.btn-success.waves-input-wrapper.waves-effect > input.waves-button-input,
  i.btn.btn-success.waves-input-wrapper.waves-effect.waves-light > input.waves-button-input {
    color: #000 !important;
  }
</style>

<!-- Helpers -->
<script type="module" src="{{ asset('admin/build/helpers-CG2EpDwl.js') }}"></script>

<link rel="modulepreload" href="{{ asset('admin/build/_commonjsHelpers-D6-XlEtG.js') }}" />
<link rel="modulepreload" href="{{ asset('admin/build/jquery-NjmgXMI-.js') }}" />
<link rel="modulepreload" href="{{ asset('admin/build/jquery-BQXThELV.js') }}" />

<link rel="modulepreload" href="{{ asset('admin/build/template-customizer-DFKqtbIV.js') }}" />

