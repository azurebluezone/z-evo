<nav class="layout-navbar container-xxl navbar-detached navbar navbar-expand-xl align-items-center bg-navbar-theme" id="layout-navbar">
    <div class="layout-menu-toggle navbar-nav align-items-xl-center me-4 me-xl-0 d-xl-none">
        <a class="nav-item nav-link px-0 me-xl-6" href="javascript:void(0)">
            <i class="icon-base ri ri-menu-line icon-22px"></i>
        </a>
    </div>

    <div class="navbar-nav-right d-flex align-items-center justify-content-end" id="navbar-collapse">
        
        <!-- Search -->
        <div class="navbar-nav align-items-center">
            <div class="nav-item navbar-search-wrapper mb-0">
                <a class="nav-item nav-link search-toggler px-0" href="javascript:void(0);">
                    <span class="d-inline-block text-body-secondary fw-normal" id="autocomplete"></span>
                </a>
            </div>
        </div>
        <!-- /Search -->

        <ul class="navbar-nav flex-row align-items-center ms-md-auto">
                        <!-- Visit Icons -->
            <li class="nav-item me-3">
                <a class="nav-link btn btn-icon btn-text-secondary rounded-pill" href="{{ url('/') }}" target="_blank" data-bs-toggle="tooltip" data-bs-placement="top" title="Visit Main Home Page">
                    <i class="icon-base ri ri-home-line icon-22px"></i>
                </a>
            </li>
            <li class="nav-item me-4 me-xl-1">
                <a class="nav-link btn btn-icon btn-text-secondary rounded-pill" href="{{ url('/home') }}" target="_blank" data-bs-toggle="tooltip" data-bs-placement="top" title="Visit Home Page">
                    <i class="icon-base ri ri-arrow-right-up-line icon-22px"></i>
                </a>
            </li>
            <!--/ Visit Icons -->

            <!-- Notifications -->
            <li class="nav-item dropdown-notifications navbar-dropdown dropdown me-4 me-xl-1">
                <a class="nav-link dropdown-toggle hide-arrow btn btn-icon btn-text-secondary rounded-pill" href="javascript:void(0);" data-bs-toggle="dropdown" data-bs-auto-close="outside" aria-expanded="false">
                    <i class="icon-base ri ri-notification-2-line icon-22px"></i>
                    <span class="position-absolute top-0 start-50 translate-middle-y badge badge-dot bg-danger mt-2 border"></span>
                </a>
                <ul class="dropdown-menu dropdown-menu-end py-0">
                    <li class="dropdown-menu-header border-bottom py-50">
                        <div class="dropdown-header d-flex align-items-center py-2">
                            <h6 class="mb-0 me-auto">Notification</h6>
                            <div class="d-flex align-items-center h6 mb-0">
                                <span class="badge rounded-pill bg-label-primary fs-xsmall me-2">8 New</span>
                                <a href="javascript:void(0)" class="dropdown-notifications-all p-2" data-bs-toggle="tooltip" data-bs-placement="top" title="Mark all as read">
                                    <i class="icon-base ri ri-mail-open-line text-heading"></i>
                                </a>
                            </div>
                        </div>
                    </li>
                    <!-- Notification items -->
                </ul>
            </li>
            <!--/ Notifications -->


            <!-- User -->
            <li class="nav-item navbar-dropdown dropdown-user dropdown">
                <a class="nav-link dropdown-toggle hide-arrow" href="javascript:void(0);" data-bs-toggle="dropdown">
                    <div class="avatar avatar-online">
                        @php
                            $userImg = Auth::user()->image ?? null;
                            $userImgPath = $userImg ? preg_replace('~^public/~', '', $userImg) : null;
                            $userImgPath = $userImgPath ? ltrim($userImgPath, '/') : null;
                            $fallbackImg = $generalsetting->frontend_empty_image ?? 'assets/images/empty.png';
                            $fallbackImg = preg_replace('~^public/~', '', $fallbackImg);
                            $fallbackImg = ltrim($fallbackImg, '/');
                        @endphp
                        <img src="{{ $userImgPath && file_exists(public_path($userImgPath)) ? asset($userImgPath) : asset($fallbackImg) }}" alt="avatar" class="rounded-circle" onerror="this.src='{{ asset('assets/images/empty.png') }}'" />
                    </div>
                </a>
                <ul class="dropdown-menu dropdown-menu-end mt-3 py-2">
                    <li>
                        <a class="dropdown-item" href="{{ route('dashboard') }}">
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0 me-2">
                                    <div class="avatar avatar-online">
                                        @php
                                            $userImgDropdown = Auth::user()->image ?? null;
                                            $userImgDropdownPath = $userImgDropdown ? preg_replace('~^public/~', '', $userImgDropdown) : null;
                                            $userImgDropdownPath = $userImgDropdownPath ? ltrim($userImgDropdownPath, '/') : null;
                                            $fallbackImgDropdown = $generalsetting->frontend_empty_image ?? 'assets/images/empty.png';
                                            $fallbackImgDropdown = preg_replace('~^public/~', '', $fallbackImgDropdown);
                                            $fallbackImgDropdown = ltrim($fallbackImgDropdown, '/');
                                        @endphp
                                        <img src="{{ $userImgDropdownPath && file_exists(public_path($userImgDropdownPath)) ? asset($userImgDropdownPath) : asset($fallbackImgDropdown) }}" alt="alt" class="w-px-40 h-auto rounded-circle" onerror="this.src='{{ asset('assets/images/empty.png') }}'" />
                                    </div>
                                </div>
                                <div class="flex-grow-1">
                                    <h6 class="mb-0 small">{{ Auth::user()->name }}</h6>
                                    <small class="text-body-secondary">Admin</small>
                                </div>
                            </div>
                        </a>
                    </li>
                    <li><div class="dropdown-divider"></div></li>
                    <li>
                        <a class="dropdown-item" href="{{ route('change_password') }}">
                            <i class="icon-base ri ri-settings-4-line icon-22px me-3"></i>
                            <span class="align-middle">Change Password</span>
                        </a>
                    </li>
                    <li><div class="dropdown-divider"></div></li>
                    <li>
                        <div class="d-grid px-4 pt-2 pb-1">
                            <a class="btn btn-sm btn-danger d-flex" href="{{ route('logout') }}" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                <small class="align-middle">Logout</small>
                                <i class="icon-base ri ri-logout-box-r-line ms-2 icon-16px"></i>
                            </a>
                        </div>
                        <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                            @csrf
                        </form>
                    </li>
                </ul>
            </li>
            <!--/ User -->
        </ul>
    </div>
</nav>