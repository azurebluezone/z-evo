<!-- Core JS -->
<script type="module" src="{{ asset('admin/build/jquery-Bou6iJJX.js') }}"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script type="module" src="{{ asset('admin/build/popper-MwzM93Hw.js') }}"></script>
<script type="module" src="{{ asset('admin/build/bootstrap-DJKADUhV.js') }}"></script>
<script type="module" src="{{ asset('admin/build/node-waves-DPhnNaCB.js') }}"></script>
<script type="module" src="{{ asset('admin/build/autocomplete-js-BLOBBNGz.js') }}"></script>

<!-- Select2 from local build -->
<script type="module" src="{{ asset('admin/build/select2-DpKWvWmx.js') }}"></script>
<!-- Include Scripts for customizer, helper, analytics, config -->
<!-- laravel style -->

<!-- Template customizer & Theme config files MUST be included after core stylesheets and helpers.js in the <head> -->
<script type="module" src="{{ asset('admin/build/template-customizer-DFKqtbIV.js') }}"></script>

<!-- Config: Mandatory theme config file contain global vars & default theme options -->
<script type="module" src="{{ asset('admin/build/config-BoP0Nie5.js') }}"></script>

<!-- Flatpickr (Date Picker) - Load before main -->
<script type="module" src="{{ asset('admin/build/flatpickr-BpVSFDNE.js') }}"></script>

<!-- Dropzone (File Upload) - Load before main -->
<script type="module" src="{{ asset('admin/build/dropzone-C47UNKrz.js') }}"></script>

<!-- Native Select initialization (Select2 removed for template consistency) -->

<!-- Initialize Template Customizer -->
<script type="module">
document.addEventListener('DOMContentLoaded', function () {
    if (window.TemplateCustomizer) {
        try {
            const appliedSkin = document.documentElement.getAttribute('data-skin') || "default";
            window.templateCustomizer = new TemplateCustomizer({
                defaultTextDir: "ltr",
                defaultTheme: "light",
                defaultSkin: appliedSkin,
                defaultSemiDark: true,
                defaultShowDropdownOnHover: "1",
                displayCustomizer: "1",
                lang: 'en',
                controls: ["color", "theme", "skins", "semiDark", "layoutCollapsed", "layoutNavbarOptions", "headerType", "contentLayout", "rtl"],
            });
        } catch (error) {
            console.warn('Template customizer initialization error:', error);
        }
    }
});
</script>

<!-- Vendors JS -->
<script type="module" src="{{ asset('admin/build/pickr-71-TLRtn.js') }}"></script>
<script type="module" src="{{ asset('admin/build/perfect-scrollbar-D2XDwrzR.js') }}"></script>
<script type="module" src="{{ asset('admin/build/hammer-DLEdXtvS.js') }}"></script>
<script type="module" src="{{ asset('admin/build/menu-Cc3Gq5JA.js') }}"></script>
<script type="module" src="{{ asset('admin/build/apexcharts-DQTXqG1-.js') }}"></script>
<script type="module" src="{{ asset('admin/build/swiper-BkuLhYW5.js') }}"></script>

<link rel="modulepreload" href="{{ asset('admin/build/flatpickr-BpVSFDNE.js') }}" />
<link rel="modulepreload" href="{{ asset('admin/build/dropzone-C47UNKrz.js') }}" />
<link rel="modulepreload" href="{{ asset('admin/build/tagify-CCqYaU3z.js') }}" />
<link rel="modulepreload" href="{{ asset('admin/build/katex-CeYKIl92.js') }}" />
<link rel="modulepreload" href="{{ asset('admin/build/quill-CeAyyUnh.js') }}" />

<script type="module" src="{{ asset('admin/build/tagify-CCqYaU3z.js') }}"></script>
<script type="module" src="{{ asset('admin/build/katex-CeYKIl92.js') }}"></script>
<script type="module" src="{{ asset('admin/build/quill-CeAyyUnh.js') }}"></script>

<!-- Optional Plugins (globally available) -->
<script type="module" src="{{ asset('admin/build/jquery-repeater-B6krBLuh.js') }}"></script>
<link rel="modulepreload" href="{{ asset('admin/build/app-ecommerce-product-add-DfByvOgY.js') }}" />

<link rel="modulepreload" href="{{ asset('admin/build/dashboards-analytics-CVGa2SfZ.js') }}" />

<!-- Theme JS -->
<script type="module" src="{{ asset('admin/build/main-Dm8hpeLP.js') }}"></script>

<!-- app JS -->
<script type="module" src="{{ asset('admin/build/app-T1DpEqax.js') }}"></script>
<link rel="modulepreload" href="{{ asset('admin/build/app-l0sNRNKZ.js') }}" />

<script>
  (function () {
    if (!window.Swal || !window.Swal.fire) return;

    function toast(icon, title, text) {
      try {
        window.Swal.fire({
          toast: true,
          position: 'top-end',
          showConfirmButton: false,
          timer: 3500,
          timerProgressBar: true,
          icon: icon,
          title: title,
          text: text || undefined
        });
      } catch (e) {
        // ignore
      }
    }

    var bag = {
      success: @json(session('success')),
      error: @json(session('error')),
      warning: @json(session('warning')),
      info: @json(session('info')),
      processing: @json(session('processing'))
    };

    if (bag.success) toast('success', 'Success', bag.success);
    if (bag.error) toast('error', 'Error', bag.error);
    if (bag.warning) toast('warning', 'Warning', bag.warning);
    if (bag.info) toast('info', 'Info', bag.info);
    if (bag.processing) toast('info', 'Processing', bag.processing);

    var validationErrors = @json($errors->all());
    if (Array.isArray(validationErrors) && validationErrors.length) {
      toast('error', 'Validation error', validationErrors[0]);
    }
  })();
</script>

<script>
  document.addEventListener('DOMContentLoaded', function () {
    if (!window.jQuery) return;
    var $ = window.jQuery;
    if (!$.fn || typeof $.fn.select2 !== 'function') return;
    if (!$('.js-select2').length) return;

    try {
      $('.js-select2').each(function () {
        var $el = $(this);
        if ($el.data('select2')) return;
        $el.select2({
          width: '100%'
        });
      });
    } catch (e) {
      // ignore
    }
  });
</script>

<script>
  (function () {
    if (!window.Swal || !window.Swal.fire) return;

    var toastrMessages = @json(session('toastr::messages', []));
    if (!Array.isArray(toastrMessages) || toastrMessages.length < 1) return;

    var mapIcon = {
      success: 'success',
      error: 'error',
      warning: 'warning',
      info: 'info'
    };

    toastrMessages.forEach(function (m) {
      if (!m) return;
      var icon = mapIcon[m.type] || 'info';
      var title = (m.title || '').toString().trim();
      var message = (m.message || '').toString();
      var Toast = window.Swal.mixin({
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 3000,
        timerProgressBar: true
      });
      Toast.fire({
        icon: icon,
        title: title ? (title + ': ' + message) : message
      });
    });
  })();
</script>

<script>
  document.addEventListener('DOMContentLoaded', function () {
    var fallbackSrc = @json(asset($generalsetting->frontend_empty_image ?? 'assets/images/empty.png'));
    if (!fallbackSrc) return;

    function setFallback(imgEl) {
      if (!imgEl || imgEl.dataset && imgEl.dataset.fallbackApplied === '1') return;
      if (imgEl.dataset) imgEl.dataset.fallbackApplied = '1';
      imgEl.src = fallbackSrc;
    }

    document.querySelectorAll('img').forEach(function (img) {
      if (!img) return;

      img.addEventListener('error', function () {
        setFallback(img);
      });

      var src = (img.getAttribute('src') || '').trim();
      if (!src) {
        setFallback(img);
      }
    });
  });
</script>

<script>
  document.addEventListener('DOMContentLoaded', function () {
    if (!window.jQuery) return;
    var $ = window.jQuery;
    if (!$.fn || typeof $.fn.repeater !== 'function') return;
    if (!$('.form-repeater').length) return;

    try {
      $('.form-repeater').each(function () {
        var $form = $(this);
        if ($form.data('repeater-initialized') === 1) return;
        $form.repeater({
          show: function () {
            $(this).slideDown();
          },
          hide: function (deleteElement) {
            $(this).slideUp(deleteElement);
          }
        });
        $form.data('repeater-initialized', 1);
      });
    } catch (e) {
      // ignore
    }
  });
</script>

<script>
  document.addEventListener('change', function (e) {
    var target = e && e.target;
    if (!target) return;
    if (!(target.classList && target.classList.contains('js-auto-submit'))) return;
    var form = target.closest('form');
    if (form) form.submit();
  });
</script>

<script>
  (function () {
    function getConfirmForm(target) {
      if (!target) return null;
      return target.closest('form');
    }

    document.addEventListener('click', function (e) {
      var printBtn = e.target.closest('.js-print');
      if (printBtn) {
        e.preventDefault();
        if (typeof window.print === 'function') {
          window.print();
        }
      }
    });

    document.addEventListener('click', function (e) {
      var deleteBtn = e.target.closest('.delete-confirm');
      if (deleteBtn) {
        e.preventDefault();
        var form = getConfirmForm(deleteBtn);

        if (!window.Swal || !window.Swal.fire) {
          if (form) form.submit();
          return;
        }

        window.Swal.fire({
          title: 'Are you sure?',
          text: 'If you delete this, it will be gone forever.',
          icon: 'warning',
          showCancelButton: true,
          confirmButtonText: 'Delete',
          cancelButtonText: 'Cancel',
          buttonsStyling: true,
          reverseButtons: true
        }).then(function (result) {
          if (result && result.isConfirmed && form) {
            form.submit();
          }
        });
      }

      var changeBtn = e.target.closest('.change-confirm');
      if (!changeBtn && e.target && e.target.closest) {
        var changeLabel = e.target.closest('label.switch');
        if (changeLabel) {
          var changeInput = changeLabel.querySelector('input.change-confirm');
          if (changeInput) {
            changeBtn = changeInput;
          }
        }
      }
      if (changeBtn) {
        e.preventDefault();
        var form2 = getConfirmForm(changeBtn);

        if (!window.Swal || !window.Swal.fire) {
          if (form2) form2.submit();
          return;
        }

        window.Swal.fire({
          title: 'Confirm change?',
          text: 'This action will modify the record.',
          icon: 'question',
          showCancelButton: true,
          confirmButtonText: 'Confirm',
          cancelButtonText: 'Cancel',
          buttonsStyling: true,
          reverseButtons: true
        }).then(function (result) {
          if (result && result.isConfirmed && form2) {
            form2.submit();
          }
        });
      }
    });

    window.showSuccessAlert = function (title, message) {
      if (window.Swal && window.Swal.fire) {
        window.Swal.fire({ title: title, text: message, icon: 'success' });
      }
    };

    window.showErrorAlert = function (title, message) {
      if (window.Swal && window.Swal.fire) {
        window.Swal.fire({ title: title, text: message, icon: 'error' });
      }
    };

    window.showWarningAlert = function (title, message) {
      if (window.Swal && window.Swal.fire) {
        window.Swal.fire({ title: title, text: message, icon: 'warning' });
      }
    };

    window.showInfoAlert = function (title, message) {
      if (window.Swal && window.Swal.fire) {
        window.Swal.fire({ title: title, text: message, icon: 'info' });
      }
    };
  })();
</script>

<script>
  (function () {
    document.addEventListener('DOMContentLoaded', function () {
      if (window.bootstrap) {
        document.querySelectorAll('[data-bs-toggle="tooltip"]').forEach(function (el) {
          try {
            new window.bootstrap.Tooltip(el);
          } catch (e) {
            // ignore
          }
        });

        document.querySelectorAll('[data-bs-toggle="popover"]').forEach(function (el) {
          try {
            new window.bootstrap.Popover(el, {
              trigger: 'focus',
              container: 'body'
            });
          } catch (e) {
            // ignore
          }
        });
      }

      if (window.flatpickr) {
        document.querySelectorAll('.js-flatpickr-date').forEach(function (el) {
          window.flatpickr(el, { dateFormat: 'Y-m-d' });
        });
        document.querySelectorAll('.js-flatpickr-time').forEach(function (el) {
          window.flatpickr(el, { enableTime: true, noCalendar: true, dateFormat: 'H:i' });
        });
        document.querySelectorAll('.js-flatpickr-datetime').forEach(function (el) {
          window.flatpickr(el, { enableTime: true, dateFormat: 'Y-m-d H:i' });
        });
        document.querySelectorAll('.js-flatpickr-range').forEach(function (el) {
          window.flatpickr(el, { mode: 'range', dateFormat: 'Y-m-d' });
        });
      }

      if (window.Quill) {
        document.querySelectorAll('.js-quill-editor').forEach(function (el) {
          if (el.__quill) return;
          var toolbarSelector = el.getAttribute('data-quill-toolbar');
          var hasToolbar = toolbarSelector && document.querySelector(toolbarSelector);
          el.__quill = new window.Quill(el, {
            theme: 'snow',
            placeholder: el.getAttribute('data-quill-placeholder') || 'Type something...',
            modules: hasToolbar ? { toolbar: toolbarSelector } : undefined
          });
        });
      }

      // Native multiple select - no Select2 needed
      // Select2 removed for template consistency

      // Tagify for meta keywords (if present)
      (function initMetaKeywordsTagify() {
        var el = document.getElementById('meta_keywords');
        if (!el) return;
        if (el.__tagify) return;
        if (!window.Tagify) return;
        try {
          el.__tagify = new window.Tagify(el, {
            delimiters: ',',
            dropdown: { enabled: 0 }
          });
        } catch (e) {
          // ignore
        }
      })();

      // Product create/edit helpers (guarded)
      // Runs only when product forms exist.
      (function initProductPages() {
        var form = document.getElementById('productForm') || document.getElementById('productEditForm');
        if (!form) return;

        // Quill editor init for product description (uses #full-editor + hidden #description)
        var editorEl = document.getElementById('full-editor');
        var descriptionInput = document.getElementById('description');
        if (editorEl && descriptionInput && window.Quill) {
          if (!editorEl.__quill) {
            var quill = new window.Quill(editorEl, {
              theme: 'snow',
              modules: {
                toolbar: [
                  [{ font: [] }, { size: [] }],
                  ['bold', 'italic', 'underline', 'strike'],
                  [{ color: [] }, { background: [] }],
                  [{ script: 'super' }, { script: 'sub' }],
                  [{ header: 1 }, { header: 2 }, 'blockquote', 'code-block'],
                  [{ list: 'ordered' }, { list: 'bullet' }, { indent: '-1' }, { indent: '+1' }],
                  [{ direction: 'rtl' }, { align: [] }],
                  ['link', 'image', 'video', 'formula'],
                  ['clean']
                ]
              }
            });
            editorEl.__quill = quill;

            if (descriptionInput.value) {
              quill.root.innerHTML = descriptionInput.value;
            }

            function uploadQuillImage(file) {
              var formData = new FormData();
              formData.append('image', file);

              var tokenEl = document.querySelector('meta[name="csrf-token"]');
              var token = tokenEl ? tokenEl.getAttribute('content') : '';

              return fetch("{{ route('admin.quill.upload') }}", {
                method: 'POST',
                headers: {
                  'X-CSRF-TOKEN': token,
                  'Accept': 'application/json'
                },
                body: formData
              }).then(function (res) {
                if (!res.ok) {
                  throw new Error('Upload failed');
                }
                return res.json();
              });
            }

            try {
              quill.getModule('toolbar').addHandler('image', function () {
                var input = document.createElement('input');
                input.setAttribute('type', 'file');
                input.setAttribute('accept', 'image/*');
                input.click();

                input.onchange = function () {
                  if (!input.files || !input.files[0]) return;
                  var file = input.files[0];

                  uploadQuillImage(file)
                    .then(function (data) {
                      var range = quill.getSelection(true);
                      quill.insertEmbed(range.index, 'image', data.url);
                      quill.setSelection(range.index + 1);
                    })
                    .catch(function () {
                      if (window.Swal && window.Swal.fire) {
                        window.Swal.fire({
                          toast: true,
                          position: 'top-end',
                          showConfirmButton: false,
                          timer: 3000,
                          timerProgressBar: true,
                          icon: 'error',
                          title: 'Image upload failed'
                        });
                      }
                    });
                };
              });
            } catch (e) {
              // ignore
            }

            form.addEventListener('submit', function (e) {
              descriptionInput.value = quill.root.innerHTML;
              var plain = (quill.getText ? quill.getText() : '').trim();
              if (!plain) {
                e.preventDefault();
                try { descriptionInput.classList.add('is-invalid'); } catch (err) {}
                if (window.Swal && window.Swal.fire) {
                  window.Swal.fire({
                    toast: true,
                    position: 'top-end',
                    showConfirmButton: false,
                    timer: 3000,
                    timerProgressBar: true,
                    icon: 'error',
                    title: 'Description is required'
                  });
                }
              }
            });
          }
        }

        // Dynamic image inputs (edit page)
        if (window.jQuery) {
          window.jQuery(document).on('click', '.btn-increment', function () {
            var html = window.jQuery('.clone').html();
            if (!html) return;
            window.jQuery('.increment').after(html);
          });

          window.jQuery(document).on('click', '.remove-image', function () {
            window.jQuery(this).closest('.control-group').remove();
          });

          window.jQuery(document).on('click', '.increment .btn-danger', function () {
            window.jQuery(this).closest('.control-group').remove();
          });

          // Category -> Subcategory -> Childcategory
          window.jQuery(document).on('change', '#category_id', function () {
            var ajaxId = window.jQuery(this).val();
            if (!ajaxId) {
              window.jQuery('#subcategory_id').empty();
              window.jQuery('#childcategory_id').empty();
              return;
            }

            window.jQuery.ajax({
              type: 'GET',
              url: "{{ url('ajax-product-subcategory') }}" + '?category_id=' + ajaxId,
              success: function (res) {
                var sub = window.jQuery('#subcategory_id');
                sub.empty();
                sub.append('<option value="">Select..</option>');
                if (res) {
                  window.jQuery.each(res, function (key, value) {
                    sub.append('<option value="' + key + '">' + value + '</option>');
                  });
                }
                sub.trigger('change');
              }
            });
          });

          window.jQuery(document).on('change', '#subcategory_id', function () {
            var ajaxId = window.jQuery(this).val();
            if (!ajaxId) {
              window.jQuery('#childcategory_id').empty();
              return;
            }

            window.jQuery.ajax({
              type: 'GET',
              url: "{{ url('ajax-product-childcategory') }}" + '?subcategory_id=' + ajaxId,
              success: function (res) {
                var child = window.jQuery('#childcategory_id');
                child.empty();
                child.append('<option value="">Select..</option>');
                if (res) {
                  window.jQuery.each(res, function (key, value) {
                    child.append('<option value="' + key + '">' + value + '</option>');
                  });
                }
                child.trigger('change');
              }
            });
          });
        }

        // Variants generator (create page)
        (function initVariantGenerator() {
          if (!window.jQuery) return;
          var $ = window.jQuery;
          if (!$('#variant_attributes').length || !$('#variants_table').length) return;

          var attrsJsonEl = document.getElementById('variant_attributes_json');
          var valuesJsonEl = document.getElementById('variant_attribute_values_json');
          if (!attrsJsonEl || !valuesJsonEl) return;

          var attributes = [];
          var attributeValues = [];
          try {
            attributes = JSON.parse(attrsJsonEl.value || '[]');
            attributeValues = JSON.parse(valuesJsonEl.value || '[]');
          } catch (e) {
            return;
          }

          var valuesByAttributeId = {};
          attributeValues.forEach(function (v) {
            if (!valuesByAttributeId[v.attribute_id]) valuesByAttributeId[v.attribute_id] = [];
            valuesByAttributeId[v.attribute_id].push(v);
          });

          function escapeHtml(str) {
            if (str === null || str === undefined) return '';
            return String(str)
              .replace(/&/g, '&amp;')
              .replace(/</g, '&lt;')
              .replace(/>/g, '&gt;')
              .replace(/"/g, '&quot;')
              .replace(/'/g, '&#039;');
          }

          function cartesian(arrays) {
            return arrays.reduce(function (a, b) {
              var ret = [];
              a.forEach(function (x) {
                b.forEach(function (y) {
                  ret.push(x.concat([y]));
                });
              });
              return ret;
            }, [[]]);
          }

          function buildValueSelectors(selectedAttributeIds) {
            var container = $('#variant_attribute_values_container');
            container.empty();

            selectedAttributeIds.forEach(function (attrId) {
              var attr = attributes.find(function (a) { return String(a.id) === String(attrId); });
              if (!attr) return;

              var options = (valuesByAttributeId[attr.id] || []).map(function (v) {
                return '<option value="' + v.id + '">' + escapeHtml(v.value) + '</option>';
              }).join('');

              var html = ''
                + '<div class="row g-3 mb-2">'
                + '  <div class="col-md-6">'
                + '    <label class="form-label">' + escapeHtml(attr.name) + ' Values</label>'
                + '    <select class="form-control variant-values" multiple size="4" data-attribute-id="' + attr.id + '" data-attribute-slug="' + escapeHtml(attr.slug) + '">' 
                + options
                + '    </select>'
                + '  </div>'
                + '</div>';

              container.append(html);
            });

            // Auto-select first available value for each attribute selector
            // so that user can click "Generate Variants" immediately.
            container.find('select.variant-values').each(function () {
              var $el = $(this);
              var current = $el.val() || [];
              if (current.length) return;
              var firstVal = $el.find('option').first().val();
              if (firstVal) {
                $el.val([firstVal]);
              }
            });

            // Native multiple select - no Select2 needed
            // When values change, regenerate variants (repeater-like UX)
            container.off('change.variant-values').on('change.variant-values', '.variant-values', function () {
              generateVariants();
            });
          }

          function generateVariants() {
            var selectedAttributeIds = $('#variant_attributes').val() || [];
            if (!selectedAttributeIds.length) {
              $('#variants_table').hide();
              $('#variants_container').empty();
              return;
            }

            var selectedValuesByAttr = [];
            var selectedAttrMeta = [];

            $('.variant-values').each(function () {
              var attrId = $(this).data('attribute-id');
              var attrSlug = $(this).data('attribute-slug');
              var attr = attributes.find(function (a) { return String(a.id) === String(attrId); });
              var valIds = $(this).val() || [];

              if (valIds.length) {
                var vals = valIds.map(function (vid) {
                  var v = (valuesByAttributeId[attrId] || []).find(function (x) { return String(x.id) === String(vid); });
                  return { id: vid, value: v ? v.value : vid };
                });

                selectedValuesByAttr.push(vals);
                var safeSlug = (attrSlug !== undefined && attrSlug !== null && String(attrSlug).trim() !== '')
                  ? String(attrSlug)
                  : (attr && attr.slug ? String(attr.slug) : String(attrId));
                var safeName = (attr && attr.name) ? String(attr.name) : safeSlug;
                selectedAttrMeta.push({ id: attrId, slug: safeSlug, name: safeName });
              }
            });

            if (!selectedValuesByAttr.length) {
              $('#variants_table').hide();
              $('#variants_container').empty();
              return;
            }

            var combos = cartesian(selectedValuesByAttr);
            var container = $('#variants_container');
            container.empty();

            combos.forEach(function (combo) {
              var labelParts = [];

              combo.forEach(function (val, idx) {
                var meta = selectedAttrMeta[idx];
                labelParts.push(meta.name + ': ' + val.value);
              });

              var label = labelParts.join(' / ');

              var attrsText = {};
              var attrsIds = {};
              combo.forEach(function (val, idx) {
                var meta = selectedAttrMeta[idx];
                var key = (meta && meta.slug) ? String(meta.slug) : String(meta && meta.name ? meta.name : idx);
                attrsText[key] = val.value;
                attrsIds[key] = val.id;
              });

              var block = ''
                + '<tr>'
                + '  <td>'
                + '    <div class="fw-semibold">' + escapeHtml(label) + '</div>'
                + '    <input type="hidden" name="variant_attrs_ids[]" value="' + escapeHtml(JSON.stringify(attrsIds)) + '" />'
                + '    <input type="hidden" name="variant_attrs_text[]" value="' + escapeHtml(JSON.stringify(attrsText)) + '" />'
                + '  </td>'
                + '  <td><input type="number" min="0" name="variant_purchase_price[]" class="form-control" /></td>'
                + '  <td>'
                + '    <input type="number" min="0" name="variant_sale_price[]" class="form-control" />'
                + '    <input type="hidden" name="variant_price_override[]" value="" />'
                + '  </td>'
                + '  <td><input type="number" min="0" name="variant_discount_price[]" class="form-control" /></td>'
                + '  <td><input type="file" name="variant_image[]" class="form-control" /></td>'
                + '  <td>'
                + '    <input type="number" min="0" name="variant_initial_stock[]" class="form-control" value="0" />'
                + '    <input type="hidden" name="variant_weight_gram[]" value="" />'
                + '  </td>'
                + '</tr>';

              container.append(block);
            });

            $('#variants_table').show();
          }

          function onAttributesChanged() {
            var selectedAttributeIds = $('#variant_attributes').val() || [];
            buildValueSelectors(selectedAttributeIds);
            $('#variants_table').hide();
            $('#variants_container').empty();
          }

          $('#variant_attributes').on('change', onAttributesChanged);
          $('#btn_generate_variants').on('click', function () {
            generateVariants();
          });
        })();
      })();

      // Ensure clicking on the switch UI toggles the underlying checkbox
      // (prevents cases where label gets clicked but input does not change).
      document.addEventListener('click', function (e) {
        var el = e && e.target ? e.target : null;
        if (!el || !el.closest) return;
        var label = el.closest('label.switch');
        if (!label) return;
        // If click is directly on checkbox, let it behave normally.
        if (el.tagName && String(el.tagName).toLowerCase() === 'input') return;
        var input = label.querySelector('input[type="checkbox"]');
        if (!input || input.disabled) return;
        input.checked = !input.checked;
        input.dispatchEvent(new Event('change', { bubbles: true }));
      });
    });
  })();
</script>
